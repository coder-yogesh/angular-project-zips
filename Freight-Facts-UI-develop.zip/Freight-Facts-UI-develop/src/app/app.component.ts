import { Component } from '@angular/core';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { SpinnerState } from './store/state/spinner.state';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'FreightFacts';

  loading$: Observable<boolean>;

  constructor(
    private store: Store<{ spinner: SpinnerState }>,
    private router: Router
  ) {
    this.loading$ = this.store.pipe(select((state) => state.spinner.isLoading));
    window.addEventListener('storage', (event) => {
      if (event.storageArea == localStorage) {
        const token = localStorage.getItem('token');

        if (token) {
          this.router.navigateByUrl('/freightfacts/dashboard');
        } else {
          this.router.navigate(['/auth/signIn']);
        }
      }
    });
  }
}
