import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}
  canActivate(
    route: ActivatedRouteSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
      if (localStorage.getItem('token')) {
        const userRole = JSON.parse(localStorage.getItem('Roles'));
        const orgRole = userRole.orgnizations.OrgRole;
        const { roles } = route.data;
        if (roles && !roles.includes(userRole.AppRole) && !roles.includes(orgRole)) {
          this.router.navigate(['/unauthorized']);
          return false;
        }
        return true;
      } else {
         this.router.navigate(['/auth/signIn']);
        return false;
      }
  }
}
