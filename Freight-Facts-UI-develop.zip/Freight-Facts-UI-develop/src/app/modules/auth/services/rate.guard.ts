import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  UrlTree,
} from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root',
})
export class RateGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}
  canActivate(
    route: ActivatedRouteSnapshot
  ):
    | Observable<boolean | UrlTree>
    | Promise<boolean | UrlTree>
    | boolean
    | UrlTree {
    if (localStorage.getItem('token')) {
      const userRole = JSON.parse(localStorage.getItem('Roles'));
      const { roles } = route.data;
      if (roles && !roles.includes(userRole.AppRole)) {
        this.router.navigate(['/unauthorized']);
        return false;
      }
      this.router.navigate(['/freightfacts/dashboard']);
      return false;
    } else {
      return true;
    }
  }
}
