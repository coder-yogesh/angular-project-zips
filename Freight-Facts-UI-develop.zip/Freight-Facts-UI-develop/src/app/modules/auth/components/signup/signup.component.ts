import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import { inputValidations, patterntValidations } from 'src/app/core/common/utils';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent {
  emailValidatePattern = regularExpressions.emailExp;
  // phonenumberValidatePattern = regularExpressions.phonenumberExp;
  signUpForm = this.fb.group({
    fullName: ['', Validators.required],
    contactEmail: [
      '',
      [Validators.required, Validators.pattern(this.emailValidatePattern)],
    ],
    phonenumber: [ '',Validators.required],
    password: ['', Validators.required]
  });
  constructor(private fb: FormBuilder) {}
  inputValidationsErrors = (signUpForm: FormGroup, type: string) => {
    // Check for validation errors
    return inputValidations(signUpForm, type);
  };
  inputEmailPatternValidationsErrors = (userForm: FormGroup, type: string) => {
    return patterntValidations(userForm, type);
  };
  PhNumberPatternValidationsErrors = (userForm: FormGroup, type: string) => {
    return patterntValidations(userForm, type);
  };
  submit() {
    console.log('submit', this.signUpForm.value);
  }
}
