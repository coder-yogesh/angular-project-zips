import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { inputValidations, patterntValidations } from 'src/app/core/common/utils';
import { AuthService } from '../../services/auth.service';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import { LoginResponse } from '../../interfaces/auth-interface';
import { regularExpressions } from 'src/app/core/common/regularexpressions';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent {
  processing = false;
  message: string;
  hasError: boolean;
  emailValidationPattern = regularExpressions.emailExp;
  userForm = this.fb.group({
    username: [
      '',
      [Validators.required, Validators.pattern(this.emailValidationPattern)],
    ],
    // username: ['', Validators.required],
    password: ['', Validators.required],
  });
  loading: boolean;
  orgName:any;
  carrierName:any;
  orgNameGet: string;
  carrierNameGet: string;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private store: Store<{ spinner: SpinnerState }>,

    private toaster: ToastrService,
    private authservice: AuthService
  ) {
    const token = localStorage.getItem('token');

    if (token) {
      this.router.navigateByUrl('/freightfacts/dashboard');
    } else {
      this.router.navigate(['/auth/signIn']);
    }
  }

  inputValidationsErrors = (userForm: FormGroup, type: string) => {
    // Check for validation errors
    return inputValidations(userForm, type);
  };
  //email pattern validation
  inputEmailPatternValidationsErrors = (
    userForm: FormGroup,
    type: string
  ) => {
    return patterntValidations(userForm, type);
  };

  login(): void {

    // Login the user
    if (
      this.userForm.controls.username.value &&
      this.userForm.controls.password.value
    ) {
      const userDetails = {
        username: this.userForm.controls.username.value.trim(),
        password: this.userForm.controls.password.value.trim(),
      };

      this.store.dispatch(showSpinner());

      this.authservice.signIn(userDetails).subscribe((res: LoginResponse) => {
        const {
          user: {
            organizations,
            firstName,
            appRole: { name: appRoleName },
          },
          accessToken,
          refreshToken,
        } = res.data;
        this.orgName =  localStorage.setItem('orgNames', res.data.user.organizations[0]?.organizationResponse?.name || '');
        // this.orgNameGet = localStorage.getItem('orgNames')
        // this.carrierName = localStorage.setItem('carrierName',res.data.user.organizations[0]?.organizationResponse?.type?.name || '');
        // this.carrierNameGet = localStorage.getItem('carrierName')
        // console.log("orgName", this.orgNameGet)
        // console.log("carrierName", this.carrierNameGet)


        this.store.dispatch(hideSpinner());

        localStorage.setItem('token', accessToken);
        localStorage.setItem('refreshToken', refreshToken);

        const Roles = {
          AppRole: appRoleName,
          orgnizations: {
            id: organizations[0]?.organizationResponse?.id || '',
            OrgRole: organizations[0]?.organizationRoleDTO?.name || '',
            OrgType: organizations[0]?.organizationResponse?.type?.name || '',
            OrgName: organizations[0]?.organizationResponse?.name || '',

            
          },
        };

        localStorage.setItem('Roles', JSON.stringify(Roles));
        localStorage.setItem('UserName', firstName);
        // localStorage.setItem('orgNames', res.data.user.organizations[0]?.organizationResponse?.name || '');
        // localStorage.setItem('carrierName', res.data.user.organizations[0]?.organizationResponse?.type?.name || '');
        if (appRoleName === 'User' && organizations.length === 0) {
          this.router.navigateByUrl('/unauthorized');
        } else {
            this.router.navigateByUrl('/freightfacts/dashboard');
          }

        this.toaster.success(`${res.message}`, '');
      });
    }
  }

  onKeyUpPassword(e) {
    if (e.key == 'Enter') {
      this.login();
    }
  }
}