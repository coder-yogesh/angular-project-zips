import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { inputValidations, passwordAndConfirmPasswordValidation, passwordValidation } from 'src/app/core/common/utils';
import { AuthService } from '../../services/auth.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.scss']
})
export class SetPasswordComponent implements OnInit {
  constructor (
    private fb: FormBuilder,
    private route: Router,
    private authService: AuthService,
    private toaster: ToastrService,
  ) {}
  changePasswordForm = this.fb.group({
    newPassword: ['', Validators.required],
    confirmPassword: ['', Validators.required],
  });
  passwordToken: string;
  inputValidationsErrors = (changePasswordForm: FormGroup, type: string) => {
    // Check for validation errors
    return inputValidations(changePasswordForm, type);
  };
  // password and confirm password validation
  confirmPasswordValidation = (
    changePasswordForm: FormGroup,
    passwordFieldName: string,
    confirmPasswordFieldName: string
  ) => {
    return passwordAndConfirmPasswordValidation(
      changePasswordForm,
      passwordFieldName,
      confirmPasswordFieldName
    );
  };
  checkPasswordValidation(form, type) {
    return passwordValidation(form, type);
  }
  
  submitPassword() {
    this.authService.setPassword(this.changePasswordForm.value, this.passwordToken).subscribe((res: any) => {
      if (res.success) {
        localStorage.clear();
        this.toaster.success(`${res.data}`, '');
        this.route.navigate(['/auth/signIn']);
      } else {
        this.toaster.error(`${res.message}`, '');
        // this.route.navigate(['/auth/signIn']);
      }
    });
  }
  removeSpaces(event: KeyboardEvent): void {
    if (event.key === ' ') {
      event.preventDefault();
    }
  }
  ngOnInit(): void {
      localStorage.clear();
      this.passwordToken = this.route.url.slice(18);
  }
}
