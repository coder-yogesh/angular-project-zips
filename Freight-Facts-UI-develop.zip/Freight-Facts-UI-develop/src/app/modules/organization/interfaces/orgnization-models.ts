export interface OrgmetaData {
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  totalRecords: number;
}
export interface applicationRole {
  id: number;
  name: string;
}

export interface orgRole {
  id: number;
  name: string;
}

export interface userResponse {
  success: boolean;
  message: string;
  data: {
    organizationMembers: orgMembers[];
    metaData: OrgmetaData;
  };
}

export interface getAllOrgTypesResponse{
  success: boolean,
  message: null,
  data: orgType[]
}

export interface orgType{
    id: number,
    name: string
}



export interface associatedOrganizationListResponse{
  success: boolean,
  message: null,
  data: {
      organizations:organization[] ,
      metaData: OrgmetaData
  }
}

export interface organization{
        id: number,
        logo : any
        name: string,
        code: string,
        contactEmail: string,
        type: orgType
        
}
export interface associatedOrganizationReturnResponse{
  id: number,
  name: string,
  code: string,
  contactEmail: string,
  type: string
}
export interface organizationListReturnResponse{
  id: number,
  name: string,
  code: string,
  contactEmail: string,
  organizationType:number | string
}

export interface orgMembers {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  organizationRole: orgRole | null;
  applicationRole: applicationRole | null;
  profilePicture:string | null
}

export interface associatedOrgCreateResponse{
  success: boolean,
  message: string,
  data: {
      id: number,
      logo : any
      name: string,
      code: string,
      contactEmail: string,
      type: orgType
  }
}
export interface usersDataReturnResponse {
  id: number;
  name: string;
  firstName: string;
  lastname: string;
  email: string;
  role: string;
}

export interface createUserResponse {
  success: boolean;
  message: string;
  data: {
    id: number;
    firstName: string;
    lastname: string;
    email: string;
    organizationRole: orgRole | null;
    applicationRole: applicationRole | null;
  };
}

export interface deleteUserResponse {
  success: boolean;
  message: string;
  data: null;
}


export interface orgRolesResponse {
  success: boolean;
  message: null;
  data: orgRole[];
}

export interface orgRole {
  id: number;
  name: string;
}

interface Role {
  id: number;
  name: string;
}

export interface RoleDataResponse {
  success: boolean;
  message: null;
  data: Role[];
}


// export interface OrganizationModels {
//   id?: number;
//   name: string;
//   code: string;
//   contactEmail: string;
//   organizationType:  number | string;
//   deletedAt? : null | string
// }

// export interface organizationTypeModel{
//   id: number,
//   name: string | null,
// }


// export interface organizationResponseModel{
//   message: string,
//   success: boolean
//   data: Array<OrganizationModels>,
// }