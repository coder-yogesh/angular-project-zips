// all rule set
export interface allRuleSet {
  success: boolean;
  message: string;
  data: {
    baseRateConfigs: RateSetting[];
    calendarRateConfigs: {
      configurations: Configuration[];
      id: number;
      rule: Rule;
      ruleSetId: number;
      createdAt: string | null;
      updatedAt: string | null;
    };
    baseRateConstraintConfigs: AssignmentRule[];
    primaryBaseRateConfigs: AdjustmentRule[];
    shipperRateConfigs: [];
    finalRateConfigs: [];
  };
}

//base rate url model
export interface baserateruleModel {
  success: boolean;
  message: string;
  data: RateSetting;
}
//rate setting
export interface RateSetting {
  id: number;
  ruleAssignmentId: number;
  rateSettings: RateSettingItem[];
  equipments: number[];
  applicableForRateType: string;
  rateOperatorId: number;
}

export interface RateSettingItem {
  id: number;
  rateSourceId: number;
  rateField: string;
  weightage: number;
  duration: number;
}

// primary config primary base rate adjustment

export interface primaryBaseRateAdjustmentModel {
  success: boolean;
  message: string;
  data: AdjustmentRule;
}

export interface AdjustmentRule {
  id: number;
  ruleAssignmentId: number;
  adjustmentValue: number;
  equipmentTypes: number[];
}

//primary config base rate constraint

export interface baseRateConstraintModel {
  success: boolean;
  message: string;
  data: AssignmentRule;
}

export interface AssignmentRule {
  id: number;
  ruleAssignmentId: number;
  targetPay: number;
  maxPay: number;
  status: string;
  equipmentTypes: EquipmentType;
}

export interface EquipmentType {
  id: number;
  label: string;
  disabled: boolean;
}

export interface AdjustmentTypes {
  name: string;
  id: number;
}

export interface ShipperSellPriceSavedAdjestment {
  adjustmentType: AdjustmentTypes;
  equipmentType: EquipmentType;
  id: number;
  value: number;
}
export interface savedAdjustments {
  id: number;
  equipmentType: EquipmentType;
  target: number;
  max: number;
}

// service models

export interface RulesetName {
  name: string;
  description: string;
  organizationId: number;
}
// configure adjustment

// export interface configAdjustmentModel {
//   success: boolean;
//   message: string;
//   data: {
//     configurations: Configuration[];
//     id: number;
//     ruleAssignmentId: number;
//     targetPay: number;
//     maxPay: number;
//     status: string;
//     equipmentTypes: equipmentType;
//   }

// export interface equipmentType{
//   id: number;
//   label: string;
//   disabled: boolean;
// }
// export interface NewFormData{

//     id: number;
//     equipmentTypes:equipmentType ;
//     targetPay: number;
//     maxPay: number;

// }

export interface configAdjustmentModel {
  success: boolean;
  message: string;
  data: {
    configurations: Configuration[];
    id: number;
    rule: Rule;
    ruleSetId: number;
    createdAt: string | null;
    updatedAt: string | null;
  };
}
export interface Configuration {
  id: number;
  ruleAssignmentId: number;
  rateOperatorId: number;
  adjustmentValue: number;
  description: string | null;
  applyFrom: string | null;
  applyTo: string | null;
  dayOfWeek: number;
  calendarAdjustmentRuleType: number;
  calendarAdjustmentStopType: number;
  createdUserId: number;
  createdAt: string | null;
  updatedAt: string | null;
  status: number;
  equipmentTypes: number[];
}

export interface Rule {
  id: number;
  code: string;
  name: string;
  description: string;
}

//deletion of rules

export interface deleteRuleSet {
  success: boolean;
  message: string;
  data?: null;
}

// accessorial
export interface AccessorialData {
  success: boolean;
  message: string;
  data: Accessorial[];
}

interface Accessorial {
  id: number;
  name: string;
  code: string;
  createdUser: User;
  updatedUser: User | null;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
}

interface User {
  createdUser: null;
  updatedUser: null;
  createdAt: string;
  updatedAt: string;
  firstName: string;
  lastName: string;
  userName: string;
  email: string;
  emailVerified: boolean;
  id: number;
}

//shipper
export interface shipperSellprice {
  success: boolean;
  message: string;
  data: MyData;
}

interface MyData {
  id: number;
  ruleAssignmentId: number;
  adjustmentValue: number;
  operatorId: number;
  rateEquipmentTypes: number[];
}

export interface AccessorialAdjData {
  success: boolean;
  message: string;
  data: AccessorialAdj;
}

interface AccessorialAdj {
  id: number;
  accessorialId: number;
  adjustmentValue: number;
  operatorId: number;
  ruleAssignmentId: number;
  equipmentTypes: number[];
}

export interface FianlConstrainData {
  success: boolean;
  message: string;
  data: FinalConstarinAdj;
}
// final constrain
export interface FinalConstarinAdj {
  id: number;
  ruleAssignmentId: number;
  targetPay: number;
  maxBuy: number;
  maxMileage: number;
  minMileage: number;
  equipmentTypes: EquipmentType;
}

export interface LoginData {
  data: {
    access_token: string;
    expires_in: number;
    refresh_expires_in: number;
    refresh_token: string;
    scope: string;
    session_state: string;
    token_type: string;
  };
  message: string;
  success: boolean;
}

export interface ShipperSellPriceResponse {
  adjustmentValue: number;
  id: number;
  operatorId: number;
  rateEquipmentTypes: EquipmentType;
  ruleAssignmentId: number;
}

export interface StatusForCompleted {
  dayOfTheWeek: boolean;
  date: boolean;
  sameDayPickup: boolean;
  accessorial: boolean;
}
export class metaData {
  pageNumber: number;
  pageSize: number;
  pageCount: number;
  recordCount: number;
}

export interface RateProviderResponse {
  success: boolean;
  message: string;
  data: {
    dat: boolean;
    sonar: boolean;
    truckstop: boolean;
  };
}
