
 export const shipperOrganizationTableConfig = {
    columns: [
      {
        field: 'name',
        header: 'Organization Name',
        pipe: 'titleCase',
        
      },
      { field: 'code', header: 'Code', pipe: 'null' },
      { field: 'contactEmail', header: 'Contact Email', pipe: 'null' },
    //   { field: 'organizationType', header: 'Organization Type', pipe: 'null' },
      {
        header: 'Actions',
        type: 'actions',
        actions: [
          {
            type: 'edit',
            text: 'Edit',
            icon: 'pi pi-pencil',
          },
          {
            type: 'delete',
            text: 'Delete',
            icon: 'pi pi-trash',
          },
        ],
      },
    ],
  };
