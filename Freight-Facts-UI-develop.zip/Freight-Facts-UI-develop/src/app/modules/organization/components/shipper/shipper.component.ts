import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { ToastrService } from 'ngx-toastr';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { Store } from '@ngrx/store';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import {
  inputValidations,
  patterntValidations,
} from 'src/app/core/common/utils';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import { shipperOrganizationTableConfig } from './shipper-table-config.component';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/modules/auth/services/auth.service';
import debounce from 'lodash/debounce';
import { OrganizationService } from '../../services/organization.service';
import {
  getAllOrgTypesResponse,
  orgType,
  associatedOrganizationListResponse,
  OrgmetaData,
  associatedOrgCreateResponse,
  deleteUserResponse,
} from '../../interfaces/orgnization-models';

@Component({
  selector: 'app-shipper',
  templateUrl: './shipper.component.html',
  styleUrls: ['./shipper.component.scss'],
})
export class ShipperComponent {
  shipperOrganizationForm: FormGroup;
  dialogHeader: string;
  showShipperOrganizationModal = false;
  shipperOrganizations: any = [];
  deleteEventModal = false;
  emailValidationPattern = regularExpressions.emailExp;
  shipperOrganizationTableConfig: object = shipperOrganizationTableConfig;
  organizationTypes: orgType[] = [];
  parentOrganizationId: number;
  routerUrl: any;
  associatedOrgId: number;
  roleFromLocalStorage: any;
  metaDataInfo: OrgmetaData;
  paginationInfo: any = {
    page: 0,
    rows: 5,
  };
  showShipperOrganization = true;
  debouncedSearchOrganization: any;
  selectedImageUrl: any = null;
  imageAsFile: any = null;
  emailFirstLetter: string;
  userName: string = 'John Hall';
  loading:boolean
  constructor(
    private fb: FormBuilder,

    private orgService: OrganizationService,
    private toasterService: ToastrService,
    private store: Store<{ spinner: SpinnerState }>,
    private router: Router
  ) {
    this.shipperOrganizationForm = this.fb.group({
      id: [null],
      name: [null, [Validators.required, Validators.maxLength(50)]],
      code: [null, [Validators.required, Validators.maxLength(10)]],
      contactEmail: [
        null,
        [
          Validators.required,
          Validators.pattern(this.emailValidationPattern),
          Validators.maxLength(50),
        ],
      ],
      organizationType: [null],
      search: [null],
    });
    this.routerUrl = this.router.url.split('/');
    this.parentOrganizationId = parseInt(
      this.routerUrl[this.routerUrl.length - 1]
    );

    this.debouncedSearchOrganization = debounce(this.searchOrganization, 300);
  }

  ngOnInit() {
    this.getOrganizationTypes();
    this.orgService.errorLoader.subscribe((res) => {
      if(res){
        this.loading=false
      }
    });
    const {
      AppRole: appRoleName,
      orgnizations: {
        id: organizationId,
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    if (isNaN(this.parentOrganizationId)) {
      this.parentOrganizationId = organizationId;
    } else {
      this.parentOrganizationId;
    }

    this.roleFromLocalStorage = appRoleName;
    this.showCreateShipperOrgBtn(appRoleName, organizationRoleName);
  }

  onCodeChange(event) {
    const pattern = /^[A-Za-z0-9]*$/;
    event.target.value = pattern.test(event.target.value)
      ? event.target.value
      : this.shipperOrganizationForm.get('code').value?.slice(0, -1);
  }

  //  show create user button based on roles

  showCreateShipperOrgBtn(appRoleName, organizationRoleName) {
    switch (appRoleName) {
      case 'Admin':
        this.showShipperOrganization = true;
        this.showActionHeaders();
        return;
      case 'Member':
        this.showShipperOrganization = false;
        this.showActionHeaders();
        return;
      case 'User':
        switch (organizationRoleName) {
          case 'Owner':
            this.showShipperOrganization = true;
            this.showActionHeaders();
            return;
          case 'Pricing Admin':
            this.showShipperOrganization = true;
            this.showActionHeaders();
            return;
          case 'Member':
            this.showShipperOrganization = false;
            this.showActionHeaders();
            return;
          default:
            this.showShipperOrganization = false;
            this.showActionHeaders();
        }

        break;
      default:
        this.showShipperOrganization = false;
        break;
    }
  }
  // show action headers for table
  showActionHeaders() {
    // Modify the table configuration based on showActionsHeader
    this.shipperOrganizationTableConfig = this.showShipperOrganization
      ? shipperOrganizationTableConfig
      : {
          ...shipperOrganizationTableConfig,
          columns: shipperOrganizationTableConfig.columns.filter(
            (column) => column.header !== 'Actions'
          ),
        };
    return;
  }
  //searching shipperOrganization

  searchOrganization() {
    const searchedText = this.shipperOrganizationForm.value.search;
    const orgInfo = {
      parentOrgId: this.parentOrganizationId,
      type: 'shipper',
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
      search: searchedText,
    };

    if (searchedText) {
      this.orgService
        .getAssociatedOrganizationSearchList(orgInfo)
        .subscribe((res: associatedOrganizationListResponse) => {
          this.shipperOrganizations = res.data.organizations;
          this.metaDataInfo = res?.data?.metaData;
        });
    } else {
      this.getShipperOrganizationList();
    }
  }

  onSearchInputChange() {
    this.debouncedSearchOrganization();
  }
  //get all organization Types{
  getOrganizationTypes() {
    this.store.dispatch(showSpinner());
    this.orgService
      .getAllOrganizationTypes()
      .subscribe((res: getAllOrgTypesResponse) => {
        this.organizationTypes = res?.data.map((item) => {
          return {
            id: item.id,
            name: item.name,
          };
        });
        this.getShipperOrganizationList();
        //this.toasterService.success(res?.message);
        this.store.dispatch(hideSpinner());
      });
  }

  //get shipperOrganization
  getShipperOrganizationList() {
    this.store.dispatch(showSpinner());
    const orgInfo = {
      parentOrgId: this.parentOrganizationId,
      type: 'shipper',
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
    };
    this.orgService.getAssociatedOrganizationList(orgInfo).subscribe(
      (res: associatedOrganizationListResponse) => {
        if (res?.data?.organizations.length > 0) {
          this.shipperOrganizations = res?.data.organizations.map((item) => {
            
            return {
              id: item.id,
              name: item.name,
              code: item.code,
              contactEmail: item.contactEmail,
              organizationType: item.type.name,
              logoUrl:item.logo
            };
          });
          this.metaDataInfo = res?.data.metaData;
        } else {
          this.shipperOrganizations = [];
        }
        // this.toasterService.success(res?.message);
        this.store.dispatch(hideSpinner());
      },
      () => {
        this.shipperOrganizations = [];
      }
    );
  }

  //show modal
  createshipperOrganizationModal() {
    this.showShipperOrganizationModal = true;
    this.dialogHeader = 'Create Shipper';
    this.shipperOrganizationForm.reset();
    this.selectedImageUrl = null;
    this.imageAsFile = null;
  }
  //create Organization
  createShipperOrganization(id) {
    const { name, code, contactEmail } = this.shipperOrganizationForm.value;
    const orgTypeId :any =this.organizationTypes.find((item) => item.name === 'Shipper')?.id
    const orgFormData=new FormData()
     orgFormData.append('id',id)
     orgFormData.append('name',name)
     orgFormData.append('code',code)
     orgFormData.append('contactEmail',contactEmail)
     orgFormData.append('type',orgTypeId)
     orgFormData.append('logo',this.imageAsFile)
    this.store.dispatch(showSpinner());
    this.loading=true
    this.orgService
      .createAssociation(this.parentOrganizationId, orgFormData)
      .subscribe((res: associatedOrgCreateResponse) => {
        
        const responseData = {
          id: res?.data.id,
          name: res?.data.name,
          code: res?.data.code,
          contactEmail: res?.data.contactEmail,
          organizationType: res?.data.type.name,
        };
        if (id == null) {
          this.shipperOrganizations.unshift(responseData);

          this.getShipperOrganizationList();
        } else {
          this.getShipperOrganizationList();
        }
        this.close();
        this.toasterService.success(res?.message);
        this.store.dispatch(hideSpinner());
        this.loading=false
        this.showShipperOrganizationModal = false;
      });
  }
  //edit modal
  editOrganization(data) {
   
    this.dialogHeader = 'Edit Shipper';
    this.showShipperOrganizationModal = true;
    this.selectedImageUrl=data.logoUrl == "null" ? null : data.logoUrl
    this.shipperOrganizationForm.patchValue({
      id: data.id,
      name: data.name,
      code: data.code,
      contactEmail: data.contactEmail,
    });
  }

  //close modal
  close() {
    this.showShipperOrganizationModal = false;
    this.selectedImageUrl=null
    // this.shipperOrganizationForm.reset();
  }

  //pattern validation
  inputValidationsErrors = (form: FormGroup, type: string) => {
    return inputValidations(form, type);
  };
  //email pattern validation
  inputEmailPatternValidationsErrors = (
    shipperOrganizationForm: FormGroup,
    type: string
  ) => {
    return patterntValidations(shipperOrganizationForm, type);
  };

  //delete organization
  deleteOrganization(data) {
    this.deleteEventModal = true;
    this.associatedOrgId = data.id;
  }
  //close delete modal
  closeModal() {
    this.deleteEventModal = false;
  }

  //delete
  confirmDeleteShipperorganization() {
    this.store.dispatch(showSpinner());
    this.orgService
      .deleteAssociation(this.parentOrganizationId, this.associatedOrgId)
      .subscribe((res: deleteUserResponse) => {
        this.deleteEventModal = false;
        this.toasterService.success(res?.message);
        this.getShipperOrganizationList();
        this.store.dispatch(hideSpinner());
      });
  }

  // checking if any changes happend in form to active update or save
  checkChanges(form) {
    return this.shipperOrganizations.some(
      (a) =>
        a.name === form.value.name &&
        a.code === form.value.code &&
        a.contactEmail === form.value.contactEmail &&
        a.logoUrl=== this.selectedImageUrl
    );
  }

     // select image from file manager
     onFileSelected(file: File) {
      this.imageAsFile = file;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedImageUrl = e.target.result;
      };
  
      reader.readAsDataURL(file);
    }
  actionFromTable(value): void {
    switch (value.type) {
      case 'edit':
        this.editOrganization(value.data);
        return;
      case 'delete':
        this.deleteOrganization(value.data);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.getShipperOrganizationList();
        return;
    }
  }
}
