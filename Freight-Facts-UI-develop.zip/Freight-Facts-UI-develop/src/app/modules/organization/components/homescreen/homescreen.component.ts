import { Component, OnInit  } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/modules/auth/services/auth.service';

@Component({
  selector: 'app-homescreen',
  templateUrl: './homescreen.component.html',
  styleUrls: ['./homescreen.component.scss']
})
export class HomescreenComponent implements OnInit {
  userName ="";
  constructor (private authService: AuthService, private router: Router) {}
  ngOnInit() {
    this.userName = localStorage.getItem('UserName');
    this.authService.getUserProfile().subscribe()
    const {
      AppRole: appRoleName,
      orgnizations: {
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    if (appRoleName === 'Admin' && !organizationTypeName) {
      this.router.navigate(['/freightfacts/dashboard']);
    }
  }
}
