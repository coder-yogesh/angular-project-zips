import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { ToastrService } from 'ngx-toastr';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { Store } from '@ngrx/store';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import {
  patterntValidations,
  inputValidations,
} from 'src/app/core/common/utils';
import { carrierOrganizationTableConfig } from './carrier-table-config.component';
import { Router } from '@angular/router';
import debounce from 'lodash/debounce';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import { OrganizationService } from '../../services/organization.service';
import {
  OrgmetaData,
  associatedOrgCreateResponse,
  associatedOrganizationListResponse,
  deleteUserResponse,
  getAllOrgTypesResponse,
} from '../../interfaces/orgnization-models';
@Component({
  selector: 'app-carrier',
  templateUrl: './carrier.component.html',
  styleUrls: ['./carrier.component.scss'],
})
export class CarrierComponent {
  carrierOrganizationForm: FormGroup;
  dialogHeader: string;
  showCarrierOrganizationModal = false;
  carrierOrganizations: any = [];
  deleteEventModal = false;
  associatedOrgId: number;
  emailValidationPattern = regularExpressions.emailExp;
  carrierOrganizationTableConfig: object = carrierOrganizationTableConfig;
  organizationTypes = [];
  parentOrganizationId: number;
  roleFromLocalStorage: string;
  routerUrl: Array<string>;
  paginationInfo: any = {
    page: 0,
    rows: 5,
  };
  showCreateCarrier = true;
  metaDataInfo: OrgmetaData;
  debouncedSearchOrganization: any;
  selectedImageUrl: any = null;
  imageAsFile: any = null;
  emailFirstLetter: string;
  userName: string = 'John Hall';
  loading:boolean
  constructor(
    private fb: FormBuilder,
    private service: OrganizationService,
    private toasterService: ToastrService,
    private store: Store<{ spinner: SpinnerState }>,
    private router: Router
  ) {
    this.carrierOrganizationForm = this.fb.group({
      id: [null],
      name: [null, Validators.required],
      code: [null, Validators.required],
      contactEmail: [
        null,
        [Validators.required, Validators.pattern(this.emailValidationPattern)],
      ],
      organizationType: [null],
      search: [null],
    });

    this.routerUrl = this.router.url.split('/');
    this.parentOrganizationId = parseInt(
      this.routerUrl[this.routerUrl.length - 1]
    );
    this.debouncedSearchOrganization = debounce(this.searchOrganization, 300);
  }

  ngOnInit() {

    this.getOrganizationTypes();
    this.service.errorLoader.subscribe((res) => {
      if(res){
        this.loading=false
      }
    });
    const {
      AppRole: appRoleName,
      orgnizations: {
        id: organizationId,
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    if (isNaN(this.parentOrganizationId)) {
      this.parentOrganizationId = organizationId;
    } else {
      this.parentOrganizationId;
    }

    this.roleFromLocalStorage = appRoleName;
    this.showCreateCarrierBtn(appRoleName, organizationRoleName);
  }

  onCodeChange(event) {
    const pattern = /^[A-Za-z0-9]*$/;
    event.target.value = pattern.test(event.target.value)
      ? event.target.value
      : this.carrierOrganizationForm.get('code').value?.slice(0, -1);
  }

  //  show create carrier button based on roles

  showCreateCarrierBtn(appRoleName, organizationRoleName) {
    switch (appRoleName) {
      case 'Admin':
        this.showCreateCarrier = true;
        this.showActionHeaders();
        return;
      case 'Member':
        this.showCreateCarrier = false;
        this.showActionHeaders();
        return;
      case 'User':
        switch (organizationRoleName) {
          case 'Owner':
            this.showCreateCarrier = true;
            this.showActionHeaders();
            return;
          case 'Pricing Admin':
            this.showCreateCarrier = true;
            this.showActionHeaders();
            return;
          case 'Member':
            this.showCreateCarrier = false;
            this.showActionHeaders();
            return;
          default:
            this.showCreateCarrier = false;
            this.showActionHeaders();
        }

        break;
      default:
        this.showCreateCarrier = false;
        this.showActionHeaders();
        break;
    }
  }
  // show action headers for table
  showActionHeaders() {
    // Modify the table configuration based on showActionsHeader
    this.carrierOrganizationTableConfig = this.showCreateCarrier
      ? carrierOrganizationTableConfig
      : {
          ...carrierOrganizationTableConfig,
          columns: carrierOrganizationTableConfig.columns.filter(
            (column) => column.header !== 'Actions'
          ),
        };
    return;
  }
  //searching carrierOrganization
  searchOrganization() {
    const searchedText = this.carrierOrganizationForm.value.search;
    const orgInfo = {
      parentOrgId: this.parentOrganizationId,
      type: 'carrier',
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
      search: searchedText,
    };
    if (searchedText) {
      this.service
        .getAssociatedOrganizationSearchList(orgInfo)
        .subscribe((res: associatedOrganizationListResponse) => {
          this.carrierOrganizations = res.data.organizations;
          this.metaDataInfo = res?.data?.metaData;
        });
    } else {
      this.getCarrierOrganizationList();
    }
  }
  onSearchInputChange() {
    this.debouncedSearchOrganization();
  }
  //get all organization Types{
  getOrganizationTypes() {
    this.store.dispatch(showSpinner());
    this.service
      .getAllOrganizationTypes()
      .subscribe((res: getAllOrgTypesResponse) => {
        this.organizationTypes = res?.data.map((item) => {
          return {
            id: item.id,
            name: item.name,
          };
        });
        this.getCarrierOrganizationList();
        //this.toasterService.success(res?.message);
        this.store.dispatch(hideSpinner());
      });
  }

  //get carrierOrganization
  getCarrierOrganizationList() {
    this.store.dispatch(showSpinner());
    const orgInfo = {
      parentOrgId: this.parentOrganizationId,
      type: 'carrier',
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
    };
    this.service.getAssociatedOrganizationList(orgInfo).subscribe(
      (res: associatedOrganizationListResponse) => {
        if (res?.data?.organizations.length > 0) {
          this.carrierOrganizations = res?.data?.organizations.map((item) => {
            return {
              id: item.id,
              name: item.name,
              code: item.code,
              contactEmail: item.contactEmail,
              organizationType: item.type.name,
              logoUrl:item.logo
            };
          });
          this.metaDataInfo = res?.data.metaData;
        } else {
          this.carrierOrganizations = [];
        }

        this.store.dispatch(hideSpinner());
      },
      () => {
        this.carrierOrganizations = [];
      }
    );
  }

  //show modal
  createCarrierOrganizationModal() {
    this.showCarrierOrganizationModal = true;
    this.dialogHeader = 'Create Carrier';
    this.carrierOrganizationForm.reset();
    this.selectedImageUrl = null;
    this.imageAsFile = null;
  }
  //create Organization
  createCarrierOrganization(id) {
    
    const { name, code, contactEmail } = this.carrierOrganizationForm.value;
    const org = {
      id: id,
      name: name,
      code: code,
      contactEmail: contactEmail,
      type: this.organizationTypes.find((item) => item.name === 'Carrier').id,
    };
    const orgTypeId :any =this.organizationTypes.find((item) => item.name === 'Carrier').id
    const orgFormData=new FormData()
     orgFormData.append('id',id)
     orgFormData.append('name',name)
     orgFormData.append('code',code)
     orgFormData.append('contactEmail',contactEmail)
     orgFormData.append('type',orgTypeId)
     orgFormData.append('logo',this.imageAsFile)
    this.store.dispatch(showSpinner());
    this.loading=true
    this.service
      .createAssociation(this.parentOrganizationId, orgFormData)
      .subscribe((res: associatedOrgCreateResponse) => {
        const responseData = {
          id: res?.data.id,
          name: res?.data.name,
          code: res?.data.code,
          contactEmail: res?.data.contactEmail,
          organizationType: res?.data.type.name,
        };
        if (id == null) {
          this.carrierOrganizations.unshift(responseData);

          this.getCarrierOrganizationList();
        } else {
          this.getCarrierOrganizationList();
        }
        this.close();
        this.toasterService.success(res?.message);
        this.loading=false
        this.store.dispatch(hideSpinner());
        this.showCarrierOrganizationModal = false;
      });
  }
  //edit modal
  editOrganization(data) {
    this.dialogHeader = 'Edit Carrier';
    this.showCarrierOrganizationModal = true;
    this.selectedImageUrl=data.logoUrl == "null" ? null : data.logoUrl
    this.carrierOrganizationForm.patchValue({
      id: data.id,
      name: data.name,
      code: data.code,
      contactEmail: data.contactEmail,
    });
  }

  //close modal
  close() {
    this.showCarrierOrganizationModal = false;
    // this.carrierOrganizationForm.reset();
    this.selectedImageUrl=null
  }

  //pattern validation
  inputValidationsErrors = (form: FormGroup, type: string) => {
    return inputValidations(form, type);
  };
  //email pattern validation
  inputEmailPatternValidationsErrors = (
    carrierOrganizationForm: FormGroup,
    type: string
  ) => {
    return patterntValidations(carrierOrganizationForm, type);
  };

  //delete organization
  deleteOrganization(data) {
    this.deleteEventModal = true;
    this.associatedOrgId = data.id;
  }
  //close delete modal
  closeModal() {
    this.deleteEventModal = false;
  }

  //delete
  confirmDeleteCarrierorganization() {
    this.store.dispatch(showSpinner());
    this.service
      .deleteAssociation(this.parentOrganizationId, this.associatedOrgId)
      .subscribe((res: deleteUserResponse) => {
        this.deleteEventModal = false;
        this.toasterService.success(res?.message);
        this.getCarrierOrganizationList();
        this.store.dispatch(hideSpinner());
      });
  }

  // checking if any changes happend in form to active update or save
  checkChanges(form) {
    return this.carrierOrganizations.some(
      (a) =>
        a.name === form.value.name &&
        a.code === form.value.code &&
        a.contactEmail === form.value.contactEmail &&
        a.logoUrl=== this.selectedImageUrl
    );
  }

     // select image from file manager
     onFileSelected(file: File) {
      this.imageAsFile = file;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedImageUrl = e.target.result;
      };
  
      reader.readAsDataURL(file);
    }

  actionFromTable(value): void {
    switch (value.type) {
      case 'edit':
        this.editOrganization(value.data);
        return;
      case 'delete':
        this.deleteOrganization(value.data);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.getCarrierOrganizationList();
        return;
    }
  }
}
