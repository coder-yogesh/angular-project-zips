import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { tableConfig } from './usersConfig';
import {
  inputValidations,
  patterntValidations,
  passwordAndConfirmPasswordValidation,
  userNameValidations,
  passwordValidation,
  ruleSetNameValidations,
} from 'src/app/core/common/utils';
import { regularExpressions } from 'src/app/core/common/regularexpressions';

import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import {
  showSpinner,
  hideSpinner,
} from 'src/app/store/actions/spinner.actions';
import * as _ from 'lodash';
import { OrganizationService } from '../../services/organization.service';
import {
  userResponse,
  createUserResponse,
  deleteUserResponse,
  orgRolesResponse,
  orgRole,
  usersDataReturnResponse,
  OrgmetaData,
} from '../../interfaces/orgnization-models';
import { UserProfileInfoService } from 'src/app/shared/services/user-profile-info.service';
import { AuthService } from 'src/app/modules/auth/services/auth.service';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
})
export class UsersComponent implements OnInit {
  usersForm: FormGroup;
  header: string;
  showUserModal = false;
  Data: any = [];
  usersData: usersDataReturnResponse[] = [];
  buttoName: string;
  userId: number;
  deleteEventModal = false;
  deleteId: number;
  userRoleData: orgRole[];
  tableConfig: object;
  emailValidationPattern = regularExpressions.emailExp;
  orgId: number;
  roleFromLocalStorage: string;
  metaDataInfo: OrgmetaData;
  PageNumber = 0;
  pageSize = 5;
  search = '';
  showCreateUser = false;
  selectedImageUrl: any = null;
  imageAsFile: any = null;
  emailFirstLetter: string;
  userName = 'John Hall';
  loading:boolean;
  constructor(
    private fb: FormBuilder,
    private toastr: ToastrService,
    private service: OrganizationService,
    private userService : UserProfileInfoService,
    private authService: AuthService,
    private store: Store<{ spinner: SpinnerState }>
  ) {
    this.usersForm = this.fb.group({
      id: [''],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: [
        '',
        [Validators.required, Validators.pattern(this.emailValidationPattern)],
      ],
      userRole: [null, [Validators.required]],
      // password: [''],
      // confirmPassword: [''],
      search: [null],
    });
    this.searchUser = _.debounce(this.searchUser, 300);
  }

  ngOnInit(): void {
    this.getuserRolesData();
    this.service.errorLoader.subscribe((res) => {
      if(res){
        this.loading=false
      }
    }); 
    this.orgId = parseInt(window.location.href.split('/').pop());

    const {
      AppRole: appRoleName,
      orgnizations: { id: organizationId, OrgRole: organizationRoleName, OrgType: organizationTypeName },
    } = JSON.parse(localStorage.getItem('Roles'));
    if (isNaN(this.orgId)) {
      this.orgId = organizationId;
    } else {
      this.orgId;
    }
    this.getuserData({
      pageNumber: this.PageNumber,
      pageSize: this.pageSize,
      search: this.search,
    });
    this.roleFromLocalStorage = appRoleName;
    this.showCreateUserBtn(appRoleName, organizationRoleName, organizationTypeName);
  }
  //  show create user button based on roles

  showCreateUserBtn(appRoleName, organizationRoleName, organizationTypeName) {
    switch (appRoleName) {
      case 'Admin':
        this.showCreateUser = true;
        this.showActionHeaders();
        return;
      case 'User':
        switch (organizationRoleName) {
          case 'Admin':
            switch (organizationTypeName) {
              case 'Carrier':
                this.showCreateUser = true;
                this.showActionHeaders();
                return;
              case 'Shipper':  
                this.showCreateUser = true;
                this.showActionHeaders();
                return;
              case '3PL':
                this.showCreateUser = true;
                this.showActionHeaders();
                return;
            }
        }

        break;
      default:
        this.showCreateUser = false;
        break;
    }
  }
  // show action headers for table
  showActionHeaders() {
    // Modify the table configuration based on showActionsHeader
    this.tableConfig = this.showCreateUser
      ? tableConfig
      : {
          ...tableConfig,
          columns: tableConfig.columns.filter(
            (column) => column.header !== 'Actions'
          ),
        };
    return;
  }
  //show modal
  createUserModal() {
    this.showUserModal = true;
    this.header = 'Create User';
    this.buttoName = 'Create';
    this.usersForm.reset();
    this.selectedImageUrl = null;
    this.imageAsFile = null;
    // Set the password field as required for creating a new user
    // this.usersForm.get('password').setValidators([Validators.required]);
    // this.usersForm.get('password').updateValueAndValidity();
    // this.usersForm.get('confirmPassword').setValidators([Validators.required]);
    // this.usersForm.get('confirmPassword').updateValueAndValidity();
  }

  //submit accessoral
  createUser(id) {
    const {
        firstName,
        lastName,
        email,
        // password,
        userRole } =
      this.usersForm.value;

    const userFormData = new FormData();
    userFormData.append('id', id);
    userFormData.append('firstName', firstName);
    userFormData.append('lastName', lastName);
    userFormData.append('email', email);
    // userFormData.append('password', password);
    userFormData.append('organizationRole', userRole.id);
    userFormData.append('applicationRole', '');
    userFormData.append('profilePicture', this.imageAsFile);
    this.store.dispatch(showSpinner());
    this.loading=true
    if (id === '') {
      this.service
        .createUser(this.orgId, userFormData)
        .subscribe((res: createUserResponse) => {
          this.getuserData({
            pageNumber: this.PageNumber,
            pageSize: this.pageSize,
            search: this.search,
          });
          this.Close();
          this.selectedImageUrl = null;
          this.imageAsFile = null;
          this.loading=false
            this.store.dispatch(hideSpinner());
            this.toastr.success(res?.message); 
        });
    } else {
      this.loading=true
      userFormData.append('id', id);
      this.service
        .updateUser(this.orgId, userFormData)
        .subscribe((res: createUserResponse) => {
          this.Close();
          this.loading=false
          this.getuserData({
            pageNumber: this.PageNumber,
            pageSize: this.pageSize,
            search: this.search,
          });
          this.authService.getUserProfile().subscribe((user: any) => {  
            if(user?.data?.id == res?.data?.id){
              this.userService.updateUserProfileData(res?.data);
            }
          });
          setTimeout(() => {
            this.store.dispatch(hideSpinner());
            this.toastr.success(res?.message); 
          },800)
        });
      
      this.store.dispatch(hideSpinner());
    }
  }
  // edit modal
  editUser(data) {
    this.buttoName = 'Update';
    this.header = 'Edit User';
    this.showUserModal = true;
    this.userId = data?.id;
    const updateUserRole = this.userRoleData.find(
      (item) => item.name == data.role
    );

    // Remove the 'required' validator from the password field
    // this.usersForm.get('password').clearValidators();
    // this.usersForm.get('password').updateValueAndValidity();
    // this.usersForm.get('confirmPassword').clearValidators();
    // this.usersForm.get('confirmPassword').updateValueAndValidity();

    this.selectedImageUrl =
      data.profilePicture == 'null' ? null : data.profilePicture;
    this.usersForm.patchValue({
      id: data.id,
      firstName: data.firstName,
      lastName: data.lastname,
      email: data.email,
      // password: data.password,
      // confirmPassword: data.password,
      userRole: updateUserRole,
    });
  }

  //close modal
  Close() {
    this.showUserModal = false;
    this.selectedImageUrl = null;
    // this.usersForm.reset();
  }

  //pattern validation
  inputValidationsErrors = (usersForm: FormGroup, type: string) => {
    return inputValidations(usersForm, type);
  };

  //email pattern validation
  inputEmailPatternValidationsErrors = (usersForm: FormGroup, type: string) => {
    return patterntValidations(usersForm, type);
  };
  // name validation

  onNameChange(event, form, type) {
    form.get(type).setValue(userNameValidations(event, form, type));
  }

  //password validation
  checkPasswordValidation(form, type) {
    return passwordValidation(form, type);
  }
  // password and confirm password validation
  confirmPasswordValidation = (
    usersForm: FormGroup,
    passwordFieldName: string,
    confirmPasswordFieldName: string
  ) => {
    return passwordAndConfirmPasswordValidation(
      usersForm,
      passwordFieldName,
      confirmPasswordFieldName
    );
  };

  // get user roles
  getuserRolesData() {
    this.service.getUserRoles().subscribe((res: orgRolesResponse) => {
      this.userRoleData = res.data;
    });
  }

  // get users
  getuserData(options: { pageNumber: number; pageSize: number; search: any }) {
    this.store.dispatch(showSpinner());
    const obj = {
      id: this.orgId,
      ...options,
    };
    this.service.getuserList(obj).subscribe((res: userResponse) => {
      this.store.dispatch(hideSpinner());
      this.usersData = res?.data?.organizationMembers.map((item) => {
        const {
          AppRole: appRoleName,
          orgnizations: {
            OrgRole: organizationRoleName,
            OrgType: organizationTypeName,
          },
        } = JSON.parse(localStorage.getItem('Roles'));
        const fullName = `${item.firstName} ${item.lastName}`;
        return {
          id: item.id,
          name: fullName,
          firstName: item.firstName,
          lastname: item.lastName,
          email: item.email,
          type: organizationTypeName.length > 0 ? organizationTypeName : localStorage.getItem('type'),
          role: item.organizationRole.name,
          profilePicture: item.profilePicture,
        };
      });
      this.metaDataInfo = res?.data?.metaData;
    });
  }

  //close delete modal
  closeModal() {
    this.deleteEventModal = false;
  }
  // searchUser
  searchUser() {
    const searchedText = this.usersForm.value.search;
    this.getuserData({
      pageNumber: this.PageNumber,
      pageSize: this.pageSize,
      search: searchedText,
    });
  }

  //deleteUser
  deleteUser(id: number) {
    this.deleteEventModal = true;
    this.deleteId = id;
  }

  //delete
  confirmDeleteUser() {
    this.store.dispatch(showSpinner());
    this.service
      .deleteUser(this.orgId, this.deleteId)
      .subscribe((res: deleteUserResponse) => {
        this.deleteEventModal = false;
        this.store.dispatch(hideSpinner());
        this.toastr.success(res?.message);
        this.getuserData({
          pageNumber: this.PageNumber,
          pageSize: this.pageSize,
          search: this.search,
        });
      });
  }
  // checking if any changes happend in form to active update or save
  checkChanges(form) {
    return this.usersData.some(
      (a: any) =>
        a.firstName === form.value.firstName &&
        a.lastname === form.value.lastName &&
        a.email === form.value.email &&
        a.role === form.value.userRole?.name &&
        a.profilePicture === this.selectedImageUrl
    );
  }
  // select image from file manager
  onFileSelected(file: File) {
    this.imageAsFile = file;
    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.selectedImageUrl = e.target.result;
    };

    reader.readAsDataURL(file);
  }
  actionFromTable(value): void {
    switch (value.type) {
      case 'edit':
        this.editUser(value.data);
        return;
      case 'delete':
        this.deleteUser(value.data.id);
        return;
      case 'pagination':
        this.PageNumber = value.data.page;
        this.getuserData({
          pageNumber: this.PageNumber,
          pageSize: this.pageSize,
          search: this.search,
        });
        return;
    }
  }
}
