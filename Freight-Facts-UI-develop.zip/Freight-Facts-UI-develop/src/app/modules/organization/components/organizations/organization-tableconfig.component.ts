

 export const organizationTableConfig = {
  class: 'cursor-pointer',
  columns: [
    {
      field: 'name',
      header: 'Organization Name',
      pipe: 'titleCase',
      type: 'navigate',
      link: 'link'
    },
    { field: 'code', header: 'Code', pipe: 'null', type: 'navigate' },
    {
      field: 'contactEmail',
      header: 'Contact Email',
      pipe: 'null',
      type: 'navigate',
    },
    {
      field: 'organizationType',
      header: 'Organization Type',
      pipe: 'null',
      type: 'navigate',
    },

    {
      header: 'Actions',
      type: 'actions',
      actions: [
        {
          type: 'edit',
          text: 'Edit',
          icon: 'pi pi-pencil',
        },
        {
          type: 'delete',
          text: 'Delete',
          icon: 'pi pi-trash',
        },
      ],
    },
  ],
};

