import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import {
  inputValidations,
  passwordAndConfirmPasswordValidation,
  passwordValidation,
  patterntValidations,
  userNameValidations,
} from 'src/app/core/common/utils';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import { SpinnerState } from 'src/app/store/state/spinner.state';

import { organizationTableConfig } from './organization-tableconfig.component';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
// import {
//   OrganizationModels,
//   organizationTypeModel,
// } from '../../interfaces/orgnization-models';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import { OrganizationService } from '../../services/organization.service';
import {
  OrgmetaData,
  associatedOrgCreateResponse,
  associatedOrganizationListResponse,
  deleteUserResponse,
  getAllOrgTypesResponse,
  orgType,
  organizationListReturnResponse,
} from '../../interfaces/orgnization-models';
@Component({
  selector: 'app-organizations',
  templateUrl: './organizations.component.html',
  styleUrls: ['./organizations.component.scss'],
})
export class OrganizationsComponent implements OnInit {
  organizationForm: FormGroup;
  dialogHeader: string;
  showOrganizationModal = false;
  organizations: organizationListReturnResponse[] = [];
  organizationId: number;
  deleteEventModal = false;
  deleteId: number;
  emailValidationPattern = regularExpressions.emailExp;
  organizationTableConfig: object = organizationTableConfig;
  organizationTypes: orgType[] = [];
  metaDataInfo: OrgmetaData;
  paginationInfo: any = {
    page: 0,
    rows: 5,
  };
  search = '';
  showCreateOrganization = true;
  selectedImageUrl: string;
  imageAsFile: any = null;
  loading:boolean;
  accessUsers: any = '';
  constructor(
    private fb: FormBuilder,
    private service: OrganizationService,
    private toasterService: ToastrService,
    private router: Router,
    private store: Store<{ spinner: SpinnerState }>
  ) {
    this.organizationForm = this.fb.group({
      id: [null],
      search: [null],
      logo: [null],
      name: [null, [Validators.required, Validators.minLength(2),
      ]],
      code: [null, [Validators.required, Validators.minLength(2)]],
      contactEmail: [
        null,
        [Validators.required, Validators.pattern(this.emailValidationPattern)],
      ],
      organizationType: [null, [Validators.required]],
      userId: [null],
      firstName: [null, [Validators.required, Validators.minLength(2)]],
      lastName: [null, [Validators.required, Validators.minLength(2)]],
      userEmailid: [
        null,
        [Validators.required, Validators.pattern(this.emailValidationPattern)],
      ],
      userRole: ['ADMIN'],
      // password: [null, [Validators.required]],
      // confirmPassword: [null, [Validators.required]],
    });
  }

  ngOnInit() {
    this.accessUsers = JSON.parse(localStorage.getItem('Roles'));
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
    const pageNations =
      JSON.parse(localStorage.getItem('page')) || this.paginationInfo;
    this.paginationInfo = pageNations;
    this.service.errorLoader.subscribe((res) => {
      if(res){
        this.loading=false
      }
    }); 
    this.getOrganizationTypes();
    const {
      AppRole: appRoleName,
      orgnizations: {
        id: organizationId,
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    this.showCreateOrgBtn(appRoleName, organizationRoleName, organizationTypeName);
  }

  onCodeChange(event) {
    const pattern = /^[A-Za-z0-9]*$/;
    event.target.value = pattern.test(event.target.value)
      ? event.target.value
      : this.organizationForm.get('code').value?.slice(0, -1);
  }

  //file selected
  onFileSelected(file: File) {
    this.imageAsFile = file;
    this.organizationForm.get('logo').setValue(file);
    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.selectedImageUrl = e.target.result;
    };
    reader.readAsDataURL(file);
  }

  //searching organizations
  searchOrganization(event) {
    this.search = event.target.value;
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
    if (event.target.value) {
      this.service
        .getAllOrganization(this.paginationInfo, this.search)
        .subscribe((res: any) => {
          this.organizations = res?.data.organizations.map((item) => {
            return {
              id: item.id,
              logo: item.logo,
              name: item.name,
              code: item.code,
              contactEmail: item.contactEmail,
              organizationType: item.type.name,
            };
          });
          this.metaDataInfo = res?.data?.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
        });
    } else {
      this.paginationInfo = {
        page: 0,
        rows: 5,
      };
      localStorage.setItem('page', JSON.stringify(this.paginationInfo));
      this.metaDataInfo.pageNumber = 0;
      this.getOrganizationsList();
    }
  }

  checkPasswordAndConfirmPassword() {
    const status = passwordAndConfirmPasswordValidation(
      this.organizationForm,
      'password',
      'confirmPassword'
    );
    status
      ? this.organizationForm
          .get('confirmPassword')
          .setErrors({ incorrect: true })
      : this.organizationForm.get('confirmPassword').setErrors(null);
    return status;
  }

  onNameChange(event, form, type) {
    form.get(type).setValue(userNameValidations(event, form, type));
  }

  //password validation
  checkPasswordValidation(form, type) {
    return passwordValidation(form, type);
  }

  //  show create user button based on roles

  showCreateOrgBtn(appRoleName, organizationRoleName, organizationTypeName) {
    switch (organizationTypeName) {
      case 'Carrier':
        switch (organizationRoleName) {
          case 'Admin':
            this.showCreateOrganization = false;
            this.showActionHeaders();
            return;
          case 'User':
            this.showCreateOrganization = false;
            this.showActionHeaders();
            return;
          default:
            this.showCreateOrganization = false;
            break;
        }
        return;
        default:
          this.showCreateOrganization = false;
          break;
    }
    switch (appRoleName) {
      case 'Admin':
        this.showCreateOrganization = true;
        this.showActionHeaders();
        return;
      case 'Member':
        this.showCreateOrganization = false;
        this.showActionHeaders();
        return;
      case 'User':
        switch (organizationRoleName) {
          case 'Owner':
            this.showCreateOrganization = true;
            this.showActionHeaders();
            return;
          case 'Admin':
            this.showCreateOrganization = false;
            this.showActionHeaders();
            return;
          case 'Member':
            this.showCreateOrganization = false;
            this.showActionHeaders();
            return;
          default:
            this.showCreateOrganization = false;
            this.showActionHeaders();
        }

        break;
      default:
        this.showCreateOrganization = false;
        break;
    }
  }
  // show action headers for table
  showActionHeaders() {
    // Modify the table configuration based on showActionsHeader
    this.organizationTableConfig = this.showCreateOrganization
      ? organizationTableConfig
      : {
          ...organizationTableConfig,
          columns: organizationTableConfig.columns.filter(
            (column) => column.header !== 'Actions'
          ),
        };
    return;
  }
  //get all organization Types{
  getOrganizationTypes() {
    this.store.dispatch(showSpinner());

    this.service
      .getAllOrganizationTypes()
      .subscribe((res: getAllOrgTypesResponse) => {
        this.organizationTypes = res?.data.map((item) => {
          return {
            id: item.id,
            name: item.name,
          };
        });
        this.getOrganizationsList();
        this.store.dispatch(hideSpinner());
      });
  }

  //get Organizations
  getOrganizationsList() {
    this.store.dispatch(showSpinner());
    this.service.getAllOrganization(this.paginationInfo, this.search).subscribe(
      (res: associatedOrganizationListResponse) => {
        if (res?.data.organizations.length > 0) {
          this.organizations = res?.data.organizations.map((item) => {
            return {
              id: item.id,
              logo: item.logo,
              name: item.name,
              code: item.code,
              contactEmail: item.contactEmail,
              organizationType: item.type.name,
            };
          });
          this.metaDataInfo = res?.data.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
          localStorage.setItem('page', JSON.stringify(this.paginationInfo));
        } else {
          this.organizations = [];
        }
        this.store.dispatch(hideSpinner());
      },
      () => {
        this.organizations = [];
      }
    );
  }

  //show modal
  createOrganizationModal() {
    this.showOrganizationModal = true;
    this.dialogHeader = 'Create Organization';
    //for sometime user role is owner until user
    this.addUserValidators();
    this.organizationForm.reset();
    this.selectedImageUrl = null;
    this.organizationForm.get('userRole').patchValue('ADMIN');

  }
  //create Organization
  createOrganization(id) {
    const {
      name,
      code,
      contactEmail,
      organizationType,
      firstName,
      lastName,
      userEmailid,
      // password,
      logo,
    } = this.organizationForm.value;
    
    console.log(name.trim(), "trim")
    const createOrganization = new FormData();
    createOrganization.append('id', id ? id : '');
    createOrganization.append('logo', logo);
    createOrganization.append('name', name);
    createOrganization.append('code', code);
    createOrganization.append('contactEmail', contactEmail);
    createOrganization.append('type', organizationType.id);
    createOrganization.append(
      'firstName',
      firstName?.charAt(firstName.length - 1) === ' '
        ? firstName.slice(0, -1)
        : firstName
    );
    createOrganization.append(
      'lastName',
      lastName?.charAt(lastName.length - 1) === ' '
        ? lastName.slice(0, -1)
        : lastName
    );
    createOrganization.append('email', userEmailid);
    // createOrganization.append('password', password);

    const updateOrganization = new FormData();
    updateOrganization.append('id', id ? id : '');
    updateOrganization.append('logo', logo);
    updateOrganization.append('name', name);
    updateOrganization.append('code', code);
    updateOrganization.append('contactEmail', contactEmail);
    updateOrganization.append('type', organizationType.id);

    this.store.dispatch(showSpinner());
    this.loading=true;
    if (!id) {
      this.service
        .createOrganizationWithDefaultUser(createOrganization)
        .subscribe((res: associatedOrgCreateResponse) => {
          const responseData = {
            id: res?.data?.id,
            logo: res?.data?.logo,
            name: res?.data.name,
            code: res?.data.code,
            contactEmail: res?.data.contactEmail,
            organizationType: res?.data.type.name,
          };
          this.selectedImageUrl = res?.data?.logo;
          this.organizations.unshift(responseData);
          this.getOrganizationsList();
          this.close();
          this.toasterService.success(res?.message);
          this.loading=false;
          this.store.dispatch(hideSpinner());
          this.showOrganizationModal = false;
        });
    } else {
      this.service
        .updateOrganization(updateOrganization)
        .subscribe((res: associatedOrgCreateResponse) => {
          const responseData = {
            id: res?.data?.id,
            logo: res?.data?.logo,
            name: res?.data.name,
            code: res?.data.code,
            contactEmail: res?.data.contactEmail,
            organizationType: res?.data.type.name,
          };
          this.selectedImageUrl = res?.data?.logo;
          this.getOrganizationsList();
          this.close();
          this.toasterService.success(res?.message);
          this.loading=false;
          this.store.dispatch(hideSpinner());
          this.showOrganizationModal = false;
        });
    }
  }

  setValidatorRequired(type) {
    this.organizationForm.get(type).setValidators([Validators.required]);
  }
  updateValueAndValidity(type) {
    this.organizationForm.get(type).updateValueAndValidity();
  }
  clearValidators(type) {
    this.organizationForm.get(type).clearValidators();
  }

  addUserValidators() {
    this.setValidatorRequired('firstName');
    this.updateValueAndValidity('firstName');
    this.setValidatorRequired('lastName');
    this.updateValueAndValidity('lastName');
    this.organizationForm
      .get('userEmailid')
      .setValidators([
        Validators.required,
        Validators.pattern(this.emailValidationPattern),
      ]);
    this.updateValueAndValidity('userEmailid');
    // this.setValidatorRequired('password');
    // this.updateValueAndValidity('password');
    // this.setValidatorRequired('confirmPassword');
    // this.updateValueAndValidity('confirmPassword');
  }

  removeUserValidators() {
    this.clearValidators('firstName');
    this.updateValueAndValidity('firstName');
    this.clearValidators('lastName');
    this.updateValueAndValidity('lastName');
    this.clearValidators('userEmailid');
    this.updateValueAndValidity('userEmailid');
    // this.clearValidators('password');
    // this.updateValueAndValidity('password');
    // this.clearValidators('confirmPassword');
    // this.updateValueAndValidity('confirmPassword');
  }

  //edit modal
  editOrganization(data) {
    
    this.dialogHeader = 'Update Organization';
    this.showOrganizationModal = true;
    const organizationType = this.organizationTypes.find(
      (item) => item.name == data.organizationType
    );
    this.removeUserValidators();

    this.organizationForm.patchValue({
      id: data.id,
      logo: data.logo,
      name: data.name,
      code: data.code,
      contactEmail: data.contactEmail,
      organizationType: organizationType,
    });    
    this.selectedImageUrl = data.logo == "null" ? null : data.logo;
  }

  //close modal
  close() {
    this.showOrganizationModal = false;
    // this.organizationForm.reset();
  }

  //pattern validation
  inputValidationsErrors = (form: FormGroup, type: string) => {

    return inputValidations(form, type);
  };
  //email pattern validation
  inputEmailPatternValidationsErrors = (
    organizationForm: FormGroup,
    type: string
  ) => {
    return patterntValidations(organizationForm, type);
  };

  //delete organization
  deleteOrganization(id) {
    this.deleteEventModal = true;
    this.deleteId = id;
  }
  //close delete modal
  closeModal() {
    this.deleteEventModal = false;
  }

  //delete
  confirmDeleteorganization() {
    this.store.dispatch(showSpinner());
    this.service
      .deleteOrganization(this.deleteId)
      .subscribe((res: deleteUserResponse) => {
        this.deleteEventModal = false;
        this.getOrganizationsList();
        this.store.dispatch(hideSpinner());
        this.toasterService.success(res?.message);
      });
  }

  // checking if any changes happend in form to active update or save
  checkChanges(form) {
    return this.organizations.some(
      (a: any) =>
        a.name === form.value.name &&
        //a.logo == form.value.logo &&
        a.code === form.value.code &&
        // a.firstName ===  form.value.firstName &&
        // a.lastName === form.value.lastName &&
        a.contactEmail === form.value.contactEmail &&
        a.organizationType === form.value.organizationType?.name
    );
  }

  actionFromTable(value): void {
    switch (value.type) {
      case 'navigate':
        this.router.navigate([
          `/freightfacts/organizations/details`,

          value.data.organizationType,
          value.data.id,
        ]);
        localStorage.setItem('orgName', value.data.name);
        localStorage.setItem('type', value.data.organizationType);
        return;
      case 'edit':
        this.editOrganization(value.data);
        return;
      case 'delete':
        this.deleteOrganization(value.data.id);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.getOrganizationsList();
        return;
    }
  }
}
