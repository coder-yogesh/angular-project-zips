import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AuthService } from "src/app/modules/auth/services/auth.service";
import { OrganizationService } from "../../services/organization.service";
import jsPDF from "jspdf";
import moment from "moment";
import { states } from "./states";
import autoTable from "jspdf-autotable";
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import * as _ from 'lodash';
import { GaugeComponent } from "src/app/shared/components/Insights/gauge/gauge.component";
import { GraphsComponent } from "src/app/shared/components/Insights/graphs/graphs.component";
import { hideSpinner, showSpinner } from "src/app/store/actions/spinner.actions";
import { SpinnerState } from "src/app/store/state/spinner.state";
import { Store } from "@ngrx/store";
import { searchValidations, userNameValidations, zipcodeValidations } from "src/app/core/common/utils";
import { ConfirmationService } from "primeng/api";
// import fflogo from '../../../../../assets/images/logos/FrightFact-brandlogo.svg';

@Component({
  selector: 'app-score-dashboard',
  templateUrl: './score-dashboard.component.html',
  styleUrls: ['./score-dashboard.component.scss'],
})
export class ScoreDashboardComponent implements OnInit {
  compareForm: FormGroup;
  @ViewChild('childComponent1') childComponent1: GaugeComponent;
  @ViewChild('childComponent2') childComponent2: GaugeComponent;
  @ViewChild('childComponent3') childComponent3: GaugeComponent;
  @ViewChild('Graphs') Graphs: GraphsComponent;
  fflogo = '../../../../../assets/images/logos/FreightFacts Logo.png';
  // eslint-disable-next-line @typescript-eslint/ban-types
  selectCompare: any[] = [];
  scoreSearch: FormGroup;
  ShipperapiAccess = true;
  selectedTab: number = 0;
  activeTabIndex: number = 0;
  btnAccess = true;
  showPrintBtn = false;
  openConfirmShipper = false;
  states = states;
  periodTime = "";
  shipperArray = [];
  selectedData: any = '';
  Report: any = '';
  ReportId: any = '';
  selectShipper: any[] = [];
  shipperMainArray: any = '';
  shipperSelect = false;
  loadedData = false;
  loadCompare = false;
  superAdmin = false;
  working = false;
  type: any = 'Carrier';
  tableBgColor = [
    '',
    '',
    ''
  ];
  compareScore: FormGroup;
  overAllNames = [];
  overAllScore = [];
  expanding: boolean;
  addedCompare: any;
  serachResult:any;
  searchType: any = 0;
  compareData = [];
  ScoreTable: any = [
    { name: 'Vol Shipments Monthly', possible: '50' },
    { name: 'Avg Length of Haul', possible: '50' },
    { name: 'Reweigh Changes', possible: '150' },
    { name: 'Reclass Changes', possible: '150' },
    { name: 'Billing Exceptions', possible: '150' }
  ];
  Score: any = {};
  orgName: string;
  loader: boolean;
  constructor (
      private confirmService: ConfirmationService,
      private authService: AuthService,
      private orgService: OrganizationService,
      private store: Store<{ spinner: SpinnerState }>,
      private fb: FormBuilder)
  {
    this.scoreSearch = this.fb.group({
      name: [''],
      street:[''],
      location: [''],
      accountNo: [''],
      city: [''],
      state: [''],
      postalcode: [''],
      shipperName:['']
    })
  }

  // vaildations for address fields
  onNameChange(event, form, type) {
    form.get(type).setValue(userNameValidations(event, form, type));
  }

  onStreetChange(event, form, type) {
    form.get(type).setValue(searchValidations(event, form, type));
  }

  onZipChange(event, form, type) {
    form.get(type).setValue(zipcodeValidations(event, form, type));
  }
  
  // selectShippers(item: any, index: any) {
  //   if (this.selectShipper.length === 0) {
  //     this.shipperSelect = true;
  //      this.selectShipper.splice(index, 0, item);
  //     // this.shipperArray.splice(index, 1);
  //   }
  // }

  changeValue(val: any, index: any) {
    if (val.units === '$') {
      return `${val.units}${val.value}`;
    }
    if (val.units === '%') {
      return `${val.value}${val.units}`;
    }
    if ((index === 4 || index === 5)
      || (index === 11 || index === 12)) {
      if (val.value === 'F') {
        return 'Not Required';
      }
      if (val.value === 'T') {
        return 'Required'
      }
    }
    if ((index === 6 || index === 8) || (index === 13 || index === 15)) {
      if (val.value === 'F') {
        return 'No';
      }
      if (val.value === 'T') {
        return 'Yes';
      }
    }
    return `${val.value} ${val.units}`;
  }

  removeShippers(index: any, item: any) {
    this.selectShipper.splice(index, 1);
    this.shipperArray.splice(index, 0, item);
  }
  filterAddress(item: any) {
    const requestAddress = item.request;
    if (requestAddress.smartKeyIdentifier === 'Origin') {
      return `${requestAddress.originStreetAdrress} | ${requestAddress.originCity} | ${requestAddress.originState} | ${requestAddress.originPostalCode}`;
    }
    if (requestAddress.smartKeyIdentifier === 'Consignee') {
      return `${requestAddress.consigneeStreetAddress} | ${requestAddress.consigneeCity} | ${requestAddress.consigneeState} | ${requestAddress.consigneePostalCode}`;
    }
    return '';
  }
  removeCompare(item) {
    let val = this.selectCompare.length >= 3 || !this.selectCompare.includes(item)
    if (this.selectCompare.length >= 2) {
      this.loadCompare = true;
      // this.store.dispatch(showSpinner());
      setTimeout(() => {
        this.loadCompare = false;
        this.type = 'Carrier';
        this.activeTabIndex = 0;
        // this.store.dispatch(hideSpinner());
      }, 1000); 
    }
    console.log('value', val);
    if (!val) {
      setTimeout(() => {
        this.ReportId = '';
        this.factorNamesDefault();
      }, 1000);
    }
  }
  isSelected(item: any): boolean {
    return this.selectCompare.includes(item);
  }
  isSelected2(item: any): boolean {
    return this.selectShipper.includes(item);
  }
  // addCompare(item: any) {
  //   this.compareData.splice(item, 1);
  // }
  //active tab
  // activateBothTabs() {
  //   this.selectedTab = 0;
  // }
  updateSearch(val: any) {
    this.searchType = val.index;
    if (this.scoreSearch.valid) {
      this.scoreSearch.reset();
    }
  }
  

  async getImageDataURL(canvas: HTMLCanvasElement): Promise<string> {
    // Check if canvas is available
    if (!canvas) {
        throw new Error("Canvas element not found");
    }

    // Return data URL
    return new Promise<string>((resolve, reject) => {
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            reject("2D context not available");
            return;
        }

        const dataURL = canvas.toDataURL('image/png');
        if (!dataURL) {
            reject("Failed to generate data URL");
            return;
        }

        resolve(dataURL);
    });
}

  reportPdf() {
    this.store.dispatch(showSpinner());
    const reportId = this.ReportId;
    this.orgService.getHistoryReport(reportId, this.ShipperapiAccess, false, '').subscribe(async (res: any) => {
      if (res.success) {
        this.expanding = true;
        this.Report = res.data[0];
        this.updateGauge(
          this.Report.searchResponse.shippersFreightScore.freightScoreDTO.accountLevel,
          this.Report.searchResponse.shippersFreightScore.freightScoreDTO.locationLevel,
          this.Report.searchResponse.shippersFreightScore.freightScoreDTO.overAll
        );
        this.genrateFile();
      }
    });
  }

  // genreate pdf file
  async genrateFile() {
      this.orgName = localStorage.getItem('orgNames').toUpperCase();
      // this.store.dispatch(showSpinner());
      const pdf = new jsPDF();
      const fflogo = this.fflogo;
      const Report = this.Report;
      const img = new Image();
      const img2 = new Image();
      const img3 = new Image();
      setTimeout(() => {
        this.store.dispatch(hideSpinner());
      }, 1000);
      setTimeout(async () => {
        const gaugeimage = document.getElementById('gague5') as HTMLCanvasElement;
        img.src = await this.getImageDataURL(gaugeimage);
        // img.src = gaugeimage.toDataURL('image/png');
        const gaugeimage2 = document.getElementById('gague6') as HTMLCanvasElement;
        img2.src = await this.getImageDataURL(gaugeimage2);
        // img2.src = gaugeimage2.toDataURL('image/png');
        const gaugeimage3 = document.getElementById('gague7') as HTMLCanvasElement;
        img3.src = await this.getImageDataURL(gaugeimage3);
        // img3.src = gaugeimage3.toDataURL('image/png');
        img.onload = async () => {
          
        }
        
      // font style
      var customFont = {
        // Load your font file (TTF, OTF, etc.)
        "file": "./assets/Avenir-Font/avenir_ff/avenir-medium.ttf",
        // Give a name to your font (you will use this name later)
        "name": "avenir-medium",
        // Additional font properties
        "style": "normal",
        "weight": "normal"
      };
      var customFont2 = {
        // Load your font file (TTF, OTF, etc.)
        "file": "./assets/avenir-lt-65-medium-bold/Avenir-Medium-Bold/Avenir-Medium-Bold.ttf",
        // Give a name to your font (you will use this name later)
        "name": "Avenir-Medium-Bold",
        // Additional font properties
        "style": "normal",
        "weight": "normal"
      };

      pdf.addFont(customFont.file, customFont.name, customFont.style, customFont.weight);
      pdf.addFont(customFont2.file, customFont2.name, customFont2.style, customFont2.weight);
      // logo
      pdf.addImage(fflogo, 'PNG', 80, 5, 50, 11);
      
      // business-details
      pdf.setLineWidth(0.5);
      pdf.setDrawColor(0, 0, 0);
      pdf.setLineWidth(0.5);
      pdf.setDrawColor('3E7FD7');
      pdf.roundedRect(150, 20, 50, 25, 2, 2, 'S');
      pdf.setFontSize(12);
      pdf.setFont(customFont2.name, 'normal');
      pdf.text('Overall Score' , 160, 30);
      pdf.setTextColor('3E7FD7');
      pdf.setFontSize(18);
      pdf.text(`${Report.searchResponse.shippersFreightScore.freightScoreDTO.overAll}`, 168, 38);
      pdf.setFont(customFont.name, 'normal');
      pdf.setFontSize(12);

      // gauges
      pdf.setTextColor('000000');
      pdf.addImage(img3.src, 'PNG', 0, 89, 90, 55);
      pdf.setFont(customFont2.name, 'normal');
      pdf.text('Overall Score', 32, 85);
      pdf.text('Account Level', 92, 85);
      pdf.text('Location Level', 152, 85);
      pdf.setFont(customFont.name, 'normal');
      pdf.text('Score', 40, 138);
      pdf.text('Score', 100, 138);
      pdf.text('Score', 160, 138);
      
      pdf.setFontSize(16);
      pdf.text(`${_.get(Report, 'searchResponse.shippersFreightScore.freightScoreDTO.overAll')}`, 41, 133);
      pdf.text(`${_.get(Report, 'searchResponse.shippersFreightScore.freightScoreDTO.accountLevel')}`, 101, 133);
      pdf.text(`${_.get(Report, 'searchResponse.shippersFreightScore.freightScoreDTO.locationLevel')}`, 161, 133);

      pdf.addImage(img.src, 'PNG', 60, 89, 90, 55);
      pdf.addImage(img2.src, 'PNG', 120, 89, 90, 55);
      pdf.setFont(customFont2.name, "normal");
      pdf.setTextColor('3E7FD7');
      pdf.text('Account Level', 15, 160);
      pdf.setFont(customFont.name, "normal");
      pdf.setTextColor('000000');
      pdf.setFontSize(12);
      const headingsdata = [
        { name: 'Account No:', values: Report.accNumber },
        { name: 'Report Generated By:', values: Report.user.firstName  },
        { name: 'Report Generated:', values: moment(Report.createdAt).format('MM-DD-YYYY hh:mm a') },
        { name: 'Shipper Name:', values: Report.shipperName },
        { name: 'Score Type:'},
        { name: 'Location:', values: Report.address },

      ];
      let start = 30;
      let gap = 8;

      headingsdata.forEach((data) => {
        pdf.setFontSize(14);
        pdf.setTextColor('3E7FD7');
        pdf.setFont(customFont2.name, "normal");
        pdf.text(data.name, 15, start);
        pdf.setTextColor('00000');
        pdf.setFont(customFont.name, "normal");
        start += gap;
      });

      pdf.text(`#${Report.accNumber}` , 47, 30);
      pdf.text(`${Report.user.firstName.toUpperCase()} ${Report.user.lastName.toUpperCase()}`, 69, 38);
      pdf.text(`${moment(Report.createdAt).format('MM-DD-YYYY hh:mm A')}`, 62, 46);
      pdf.text(`${Report.shipperName}`, 53, 54);
      pdf.text(`${Report.viewType === 1 ? this.orgName +" "+ 'VIEW' :'MARKET VIEW'}`, 44, 62);
      pdf.text(`${Report.address}`, 39, 70);

      // account level data

      const data = [];
      const data2 = [];
      Report.searchResponse.accountLevelFFNames.forEach((d: any, ind) => {
        // eslint-disable-next-line prefer-const
        let id = ind;
        Report.searchResponse.accountLevel.points.forEach((point: any, index) => {
          if (id === index) {
            // eslint-disable-next-line prefer-const
            data.push([d.name, d.possible, point.value, point.earned]);
          }
          return '';
        });
      });
      const accountTotal = [
        'Total',
        `${Report.searchResponse.possiblePoints.accountLevelPossiblePoints}`,
        '',
        `${Report.searchResponse.accountLevel.maximumTotalEarnedPoints}`
      ];
      const headings = ['Freight Facts', 'Points Possible', 'Values', 'Points Earned'];
      const styleDef = {
        fillColor: 'white',
        textColor: 'black',
        lineWidth: 0.5,
      }

      // account level table
      let accountTable = 182;
      let div = 10;
      pdf.setDrawColor(0, 0, 0);
      pdf.setLineWidth(0.112);
      pdf.line(15, 165, 200, 165);
      pdf.setFontSize(12);
      pdf.setFillColor('E9E9E9');
      pdf.rect(15, 245, 185, 8, 'F');
      pdf.setFont(customFont2.name, "normal");
      pdf.text(headings[0], 18, 171);
      pdf.text(headings[1], 80, 171);
      pdf.text(headings[2], 120, 171);
      pdf.text(headings[3], 164, 171);
      pdf.setFont(customFont.name, "normal");
      pdf.setFontSize(12);
      pdf.line(15, 175, 200, 175);
      pdf.line(15, 165, 15, 253);
      pdf.line(78, 165, 78, 253);
      pdf.line(118, 165, 118, 253);
      pdf.line(158, 165, 158, 253);
      pdf.line(200, 165, 200, 253);
      _.get(Report, 'searchResponse.accountLevelFFNames').forEach((d) => {
        pdf.text(d.name=== 'Total Weight' ? 'Average Weight Per Shipment' : d.name , 18, accountTable);
        pdf.text(`${d.possible}`, 80, accountTable);
        accountTable += div;
      });
      accountTable = 182;
      var back = 176;
      let boxdiv = 10;
      var width = 41;
      var height = 8.5;
      const last = _.get(Report, 'searchResponse.accountLevel.points').length;
      _.get(Report, 'searchResponse.accountLevel.points').forEach((d2, index) => {
        pdf.text(`${this.changeValue(d2, index)}`, 122, accountTable);
        if (last !== index) {
          pdf.setFillColor(
            this.updateColor2(d2.earned, index, 1)[0],
            this.updateColor2(d2.earned, index, 1)[1],
            this.updateColor2(d2.earned, index, 1)[2],
          );
          pdf.roundedRect(165, back, 27, 8, 4, 4, 'F');
          back += boxdiv;
        }
        pdf.text(`${d2.earned}`, 176, accountTable);
        pdf.line(15, accountTable + 3, 200, accountTable + 3);
        accountTable += div;
      });
      pdf.setFontSize(12);
      pdf.setFont(customFont2.name, "normal");
      pdf.text(accountTotal[0], 18, 250);
      pdf.text(accountTotal[1], 80, 250);
      pdf.text(accountTotal[2], 120, 250);
      pdf.text(accountTotal[3], 175, 250);
      pdf.line(15, 253, 200, 253);
      pdf.setFont(customFont.name, "normal");
      pdf.setFontSize(14);

      // location level table
      const locationTotal = [
        'Total',
        `${_.get(Report, 'searchResponse.possiblePoints.locationLevelPossiblePoints')}`,
        '',
        `${Report.searchResponse.locationLevel.maximumTotalEarnedPoints}`
      ];

      let locationTable = 42;
      // pdf.line(15, 210, 200, 210);
      // pdf.setFontSize(12);
      // pdf.line(15, 217, 200, 217);
      // pdf.line(15, 210, 15, 288.5);
      // pdf.line(78, 210, 78, 288.5);
      // pdf.line(118, 210, 118, 288.5);
      // pdf.line(158, 210, 158, 288.5);
      // pdf.line(200, 210, 200, 288.5);
      _.get(Report, 'searchResponse.locationLevelFFNames').forEach((d, index) => {
        if (index === 0) {
          pdf.addPage();
          pdf.setFontSize(16);
          pdf.setTextColor('3E7FD7');
          pdf.setFont(customFont2.name, "normal");
          pdf.text('Location Level', 15, 20);
          pdf.setFontSize(12);
          pdf.setTextColor('00000');
          pdf.line(15, 25, 200, 25);
          pdf.setFillColor('E9E9E9');
          pdf.rect(15, 185, 185, 10, 'F');
          pdf.text(headings[0], 18, 32);
          pdf.text(headings[1], 80, 32);
          pdf.text(headings[2], 120, 32);
          pdf.text(headings[3], 164, 32);
          pdf.text(locationTotal[0], 18, 192);
          pdf.text(locationTotal[1], 80, 192);
          pdf.text(locationTotal[2], 120, 192);
          pdf.text(locationTotal[3], 175, 192);
          pdf.line(15, 195, 200, 195);
          pdf.setFont(customFont.name, "normal");
          pdf.line(15, 35, 200, 35);
          pdf.line(15, 25, 15, 195);
          pdf.line(78, 25, 78, 195);
          pdf.line(118, 25, 118, 195);
          pdf.line(158, 25, 158, 195);
          pdf.line(200, 25, 200, 195);
          pdf.setFontSize(12);
        }
        pdf.text(d.name=== 'Total Weight' ? 'Average Weight Per Shipment' : d.name , 18, locationTable);
        pdf.text(`${d.possible}`, 80, locationTable);
        locationTable += div;
        // if (index === 8) {
        //   locationTable = 15;
        //   pdf.addPage();
        //   pdf.line(15, 10, 15, 58);
        //   pdf.line(78, 10, 78, 58);
        //   pdf.line(118, 10, 118, 58);
        //   pdf.line(158, 10, 158, 58);
        //   pdf.line(200, 10, 200, 58);
        // }
      });
      locationTable = 42;
      let back2 = 36;
      const last2 = _.get(Report, 'searchResponse.locationLevel.points').length;
      _.get(Report, 'searchResponse.locationLevel.points').forEach((d2, index) => {
        // if (index < 9) {
        //   pdf.setPage(1);
        //   pdf.text(`${d2.value} ${d2.units}`, 120, locationTable);
        //     pdf.setFillColor(
        //       this.updateColor(d2.earned, index, 2)[0],
        //       this.updateColor(d2.earned, index, 2)[1],
        //       this.updateColor(d2.earned, index, 2)[2],
        //     );
        //     pdf.rect(158.5, back2, width, height, 'F');
        //     back2 += div;
        //   pdf.line(15, locationTable + 1.5, 200, locationTable + 1.5);
        //   pdf.text(`${d2.earned}`, 160, locationTable);
        //   locationTable += div;
        // }
        // if (index === 8) {
        //   pdf.setPage(2);
        //   pdf.setFontSize(14);
        //   pdf.text(locationTotal[0], 18, 55);
        //   pdf.text(locationTotal[1], 80, 55);
        //   pdf.text(locationTotal[2], 120, 55);
        //   pdf.text(locationTotal[3], 160, 55);
        //   pdf.line(15, 58, 200, 58);
        //   pdf.setFontSize(12);
        //   locationTable = 15;
        //   pdf.line(15, 10, 200, 10);
        //   div = 8;
        //   back2 = 10;
        // }
        // if (index > 8) {

          pdf.text(`${this.changeValue(d2, index)}`, 121, locationTable);
          if (last2 !== index) {
            pdf.setFillColor(
              this.updateColor2(d2.earned, index, 2)[0],
              this.updateColor2(d2.earned, index, 2)[1],
              this.updateColor2(d2.earned, index, 2)[2],
            );
            pdf.roundedRect(165, back2, 27, 8, 4, 4, 'F');
            back2 += div;
          }
          pdf.line(15, locationTable + 3, 200, locationTable + 3);
          pdf.text(`${d2.earned}`, 176, locationTable);
          locationTable += div;
        // }
      });

      // pdf.addPage();
      // accountTable = 42;
      // back = 36;
      // pdf.setFontSize(16);
      // pdf.setTextColor('3E7FD7');
      // pdf.setFont(customFont2.name, "normal");
      // pdf.text('Overall', 15, 20);
      // pdf.setFontSize(12);
      // pdf.setTextColor('00000');
      // pdf.line(15, 25, 200, 25);
      // pdf.text(headings[0], 18, 32);
      // pdf.text(headings[1], 80, 32);
      // pdf.text(headings[2], 120, 32);
      // pdf.text(headings[3], 164, 32);
      // pdf.setFont(customFont.name, "normal");
      // pdf.line(15, 35, 200, 35);
      // pdf.line(15, 25, 15, 255);
      // pdf.line(78, 25, 78, 255);
      // pdf.line(118, 25, 118, 255);
      // pdf.line(158, 25, 158, 255);
      // pdf.line(200, 25, 200, 255);
      // pdf.line(15, 255, 200, 255);
      // this.overAllNames.forEach((d) => {
      //   pdf.text(d.name=== 'Total Weight' ? 'Average Weight Per Shipment' : d.name , 18, accountTable);
      //   pdf.text(`${d.possible}`, 80, accountTable);
      //   accountTable += div;
      // });
      // accountTable = 42;
      // const last3 = this.overAllScore.length;
      // this.overAllScore.forEach((d2, index) => {
      //   pdf.text(`${this.changeValue(d2, index)}`, 122, accountTable);
      //   if (last3 !== index) {
      //     pdf.setFillColor(
      //       this.updateColor2(d2.earned, index, 3)[0],
      //       this.updateColor2(d2.earned, index, 3)[1],
      //       this.updateColor2(d2.earned, index, 3)[2],
      //     );
      //     pdf.roundedRect(165, back, 27, 8, 4, 4, 'F');
      //     back += boxdiv;
      //   }
      //   pdf.text(`${d2.earned}`, 176, accountTable);
      //   pdf.line(15, accountTable + 3, 200, accountTable + 3);
      //   accountTable += div;
      // });
      // account level table
      // autoTable(pdf, {
      //   headStyles: styleDef,
      //   bodyStyles: styleDef,
      //   alternateRowStyles: styleDef,
      //   head: [headings],
      //   body: data,
      //   startY: 129,
      // });

        // const table = canvas1.toDataURL('image/png');
        // const imm = new Image();
        // imm.src = table;
        // // doc.text(imagee, 30, 40);
        // pdf.addImage(imm.src, 'PNG', 15, 129, 160, 55);
  
      
      // location level data
      _.get(Report, 'searchResponse.locationLevelFFNames').forEach((d: any, ind) => {
        // eslint-disable-next-line prefer-const
        let id = ind;
          _.get(Report, 'searchResponse.locationLevel.points').forEach((point: any, index) => {
          if (id === index) {
            // eslint-disable-next-line prefer-const
            data2.push([d.name, d.possible, point.value, point.earned]);
          }
          return '';
        });
      });
      data2.push([
        'Total',
        `${_.get(Report, 'searchResponse.possiblePoints.locationLevelPossiblePoints')}`,
        '',
        `${_.get(Report, 'searchResponse.possiblePoints.maximumTotalEarnedPoints')}`]);

      // location level table

      // const table2 = canvas2.toDataURL('image/png');
      // const imm2 = new Image();
      // imm2.src = table2;
      // // doc.text(imagee, 30, 40);
      // pdf.addImage(imm2.src, 'PNG', 15, 210, 160, 55);

      // autoTable(pdf, {
      //   headStyles: styleDef,
      //   bodyStyles: styleDef,
      //   alternateRowStyles: styleDef,
      //   head: [headings],
      //   body: data2,
      //   startY: 210,
      // });
        
        pdf.autoPrint();
        const link: any = pdf.output('bloburl');
        window.open(link);
      }, 1000);
      setTimeout(() => {
        this.expanding = false;
      }, 1001);
  }
  
  resetData() {
    this.store.dispatch(showSpinner());
    setTimeout(() => {
      this.type = 'Carrier';
      this.activeTabIndex = 0;
      this.scoreSearch.reset({
        name: '',
        street:'',
        location: '',
        accountNo: '',
        city: '',
        state: '',
        postalcode: '',
        shipperName: ''
      });
      this.loadedData = false;
      this.expanding = false;
      this.showPrintBtn = false;
      this.store.dispatch(hideSpinner());
    }, 1000); 
  }
  
  checkForm() {
    if (this.scoreSearch.value.name || this.scoreSearch.value.accountNo
        || this.scoreSearch.value.location || this.scoreSearch.value.city
        || this.scoreSearch.value.state || this.scoreSearch.value.postalcode) {
      return false;
    }
    return false;
  }
  updateGauge(val1: any, val2: any, val3: any) {
    setTimeout(() => {
      if (this.childComponent1 && typeof this.childComponent1.gaugeCont === 'function') {
        this.childComponent1.gaugeCont(val1);
      }
      if (this.childComponent2 && typeof this.childComponent2.gaugeCont === 'function') {
        this.childComponent2.gaugeCont(val2);
      }
      if (this.childComponent3 && typeof this.childComponent3.gaugeCont === 'function') {
        this.childComponent3.gaugeCont(val3);
      }
    }, 1)
  }
  updateTab() {
    this.Score.shippersFreightScore.map((data: any) => {
      this.updateGauge(
        data.freightScoreDTO.accountLevel,
        data.freightScoreDTO.locationLevel,
        data.freightScoreDTO.overAll
      );
    })
  }

  onTabChange(event: any) {
    this.activeTabIndex = event.index;
    this.updateTab();
  }
  
  updateColor(val: any, font: any, index: any, check: any) {
    let value = Number(val);
    let step = 0;
    // const colors = [
    //   { h: '4', l: '47%' },
    //   { h: '35', l: '69%' },
    //   { h: '35', l: '70%' },
    //   { h: '39', l: '75%' },
    //   { h: '40', l: '77%' },
    //   { h: '44', l: '79%' },
    //   { h: '59', l: '74%' },
    //   { h: '140', l: '66%' },
    //   { h: '170', l: '33%' },
    //   { h: '170', l: '32%' },
    //   { h: '169', l: '29%' },
    // ];
    if (check === 1) {
      step = value / this.Score.accountLevelFFNames[index].possible * 100;
    }
    if (check === 2) {
      step = value / this.Score.locationLevelFFNames[index].possible * 100;
    }
    if (check === 3) {
      step = value / this.overAllNames[index].possible * 100;
    }
    // let parts = Math.round(100 / 11);
    if (font) {
      if (step < 41) {
        return 'white';
      } else {
        return 'black';
      }
    }
    let color = 'rgba(255, 86, 86, 1)';
    if (step < 21) {
      return color = 'rgba(255, 86, 86, 1)';
    } else if (step < 41) {
      return color = 'rgba(255, 136, 136, 1)';
    } else if (step < 61) {
      return color = 'rgba(254, 225, 20, 1)';
    } else if (step < 81) {
      return color = 'rgba(209, 216, 15, 1)';
    } else if (step < 101) {
      return color = 'rgba(132, 189, 50, 1)';
    }

    // const array = [];
    // let count = 0;
    // for (let i = 1; i < 12; i++) {
    //   array.push(count += parts);
    // }
    // let nearest = null;
    // let index = 0;
    // for (let i = 0; i < array.length; i++) {
    //   // If the current element is greater than the target
    //   if (array[i] > step) {
    //     // If nearest is null or the current element is closer to the target than nearest
    //     if (nearest === null || array[i] - step < nearest - step) {
    //       nearest = array[i];
    //       index = i;
    //     }
    //   }
    // }
    // if (step < 11) {
    //   step = 100;
    // }
    // if (value === 200) {
    //   return 'hsl('+colors[10].h+','+ 100 +'%,'+colors[10].l+')';
    // }
    // let color = 'hsl('+colors[index].h+','+ step +'%,'+colors[index].l+')';
    return color;
  }

  updateColor2(val: any, index: any, check: any) {
    let value = Number(val);
    let step = 0;
    if (check === 1) {
      step = value / this.Report.searchResponse.accountLevelFFNames[index].possible * 100;
    }
    if (check === 2) {
      step = value / this.Report.searchResponse.locationLevelFFNames[index].possible * 100;
    }
    if (check === 3) {
      step = value / this.overAllNames[index].possible * 100;
    }
    let color:any = '';
    if (step < 21) {
      return color = [255, 86, 86];
    } else if (step < 41) {
      return color = [255, 136, 136];
    } else if (step < 61) {
      return color = [254, 225, 49];
    } else if (step < 81) {
      return color = [208, 216, 45];
    } else if (step < 101) {
      return color = [132, 189, 50];
    }
    return color;
  }

  factorNamesDefault() {
    this.showPrintBtn = false;
    this.orgService.getFactorNames().subscribe(
      async (res: any) => {
        if (res.success) {
          this.Score = res.data;
          this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
          this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
          setTimeout(() => {
            // this.store.dispatch(hideSpinner());
            this.updateTab();
          }, 500);
          if (this.Graphs && typeof this.Graphs.updateGraph === 'function') {
            this.Graphs.updateGraph(this.Score.keyMetrics);
          }
        }
      },
      () => {
        // this.store.dispatch(hideSpinner());
      }
      )
  }
  
  shipperScore() {
      this.ReportId = '';
      this.showPrintBtn = false;
      this.selectShipper.forEach((d) => {
        this.shipperMainArray[d.index].request.highLevelAccntNo = d.data.highest_account;
        this.shipperMainArray[d.index].request.billToAccountNo = d.data.bill_to_account;
        this.shipperMainArray[d.index].request.billToSmartKey = d.data.bill_to_smartKey;
      });
      const payload = {
        searchResult: this.shipperMainArray,
      }
      setTimeout(() => {
        this.store.dispatch(showSpinner());
      }, 500);
      if (this.type === 'Carrier') {
        this.orgService.scoreGenrate(payload).subscribe({
          next: (res: any) => {
            if (res.success) {
                this.shipperMainArray = res.data;
                if (_.get(this.shipperMainArray, 'historyDashBoardResponses') || _.get(this.shipperMainArray, 'accountLevel')) {
                  this.openConfirmShipper = false;
                  this.Score = _.get(this.shipperMainArray, 'historyDashBoardResponses') ? this.shipperMainArray.historyDashBoardResponses : this.shipperMainArray;
                  this.ReportId = res.data?.reportId?res.data?.reportId[0]:null;
                  this.showPrintBtn = true;
                  this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
                  this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
                  setTimeout(() => {
                    this.store.dispatch(hideSpinner());
                    this.updateTab();
                  }, 300);
                  this.Graphs.updateGraph(this.Score.keyMetrics);
                  // this.Score.shippersFreightScore.map((searchZero) => {
                  //   if (searchZero.freightScoreDTO.overAll === 0) {
                  //     setTimeout(() => {
                  //       this.confirmService.confirm({
                  //         message: 'lkdafjlkdsafsajd lfjsdlfsadflkdsafjsad fjdsflksaj', 
                  //         header: 'No score', 
                  //         rejectVisible: false,
                  //         acceptVisible: false
                  //       })
                  //     }, 1000)
                  //   }
                  // })
                }
                this.shipperMainArray.forEach((d, index) => {
                  if (d.request.requestStatus === 'HIGHERACCOUNTNUMBER') {
                    this.selectedData = '';
                    this.selectedData = d;
                    this.openConfirmShipper = true;
                    this.shipperArray = [];
                    this.selectShipper = [];
                    this.factorNamesDefault();
                    setTimeout(() => {
                      this.store.dispatch(hideSpinner());
                      this.updateTab();
                    }, 300);
                    d.request.accountData.forEach((d2) => {
                      this.shipperArray.push({
                        index: index,
                        data: d2,
                      });
                    })
                  }
                })
            } else {
              this.factorNamesDefault();
            }
          },
          error: (error) => {
            this.openConfirmShipper = false;
            this.factorNamesDefault();
          }
        })
      }
      if (this.type === 'Market') {
        this.orgService.marketviewscoreGenrate(payload).subscribe({
          next: (res: any) => {
            if (res.success) {
                this.shipperMainArray = res.data;
                if (_.get(this.shipperMainArray, 'historyDashBoardResponses') || _.get(this.shipperMainArray, 'accountLevel')) {
                  this.openConfirmShipper = false;
                  this.showPrintBtn = true;
                  this.Score = _.get(this.shipperMainArray, 'historyDashBoardResponses')
                    ? this.shipperMainArray.historyDashBoardResponses : this.shipperMainArray;
                  this.ReportId = res.data?.reportId?res.data?.reportId[0]:null;
                  this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
                  this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
                  
                  setTimeout(() => {
                    this.store.dispatch(hideSpinner());
                    this.updateTab();
                  }, 300);
                  this.Graphs.updateGraph(this.Score.keyMetrics);
                }
                this.shipperMainArray.forEach((d, index) => {
                  if (d.request.requestStatus === 'HIGHERACCOUNTNUMBER') {
                    this.selectedData = '';
                    this.selectedData = d;
                    this.openConfirmShipper = true;
                    this.shipperArray = [];
                    this.selectShipper = [];
                    this.factorNamesDefault();
                    setTimeout(() => {
                      this.store.dispatch(hideSpinner());
                      this.updateTab();
                    }, 300);
                    d.request.accountData.forEach((d2) => {
                      this.shipperArray.push({
                        index: index,
                        data: d2,
                      });
                    })
                  }
                })
            } else {
              this.factorNamesDefault();
            }
          },
          error: (error) => {
            this.openConfirmShipper = false;
            this.factorNamesDefault();
          }
        })
      }
  }
  
  ViewType(val: any) {
    if (val === 1) {
      this.type = 'Carrier';
      this.compareScoring();
    }
    if (val === 2) {
      this.type = 'Market';
      this.compareScoring();
    }
  }

  compareScoring() {
    this.ReportId = '';
    // this.loader = true;
    if (this.selectCompare.length > 1) {
      this.type = 'Carrier';
    }
    if (this.selectCompare.length > 0) {
      const payload = {
        searchResult: this.selectCompare,
      }
      
      setTimeout(() => {
        this.store.dispatch(showSpinner());
      }, 500);
      if (this.type === 'Carrier') {
        this.orgService.scoreGenrate(payload).subscribe({
          next: async (res: any) => {
            if (res.success) {
              if (res.data.length > 0) {
                this.shipperArray = [];
                this.selectShipper = [];
                // this.factorNamesDefault();
                this.shipperMainArray = res.data;
                this.shipperMainArray.forEach((d, index) => {
                  if (d.request.requestStatus === 'HIGHERACCOUNTNUMBER') {
                    this.selectedData = '';
                    this.selectedData = d;
                    setTimeout(() => {
                      this.store.dispatch(hideSpinner());
                    }, 500);
                    this.openConfirmShipper = true;
                    // if (val === true) {
                    //   this.openConfirmShipper = false;
                    // }
                    this.shipperArray = [];
                    this.selectShipper = [];
                    // this.factorNamesDefault();
                    d.request.accountData.forEach((d2) => {
                      this.shipperArray.push({
                        index: index,
                        data: d2,
                      });
                    })
                  }
                })
              }
              if (_.get(res.data, 'historyDashBoardResponses') || _.get(res.data, 'accountLevel')) {
                this.Score = this.selectCompare.length < 2 ? res.data.historyDashBoardResponses : res.data;
                this.ReportId = res.data?.reportId?res.data?.reportId[0]:null;
                this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
                this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
                setTimeout(() => {
                  this.store.dispatch(hideSpinner());
                  this.showPrintBtn = true;
                  this.updateTab();
                }, 500);
                this.Graphs.updateGraph(this.Score.keyMetrics);
                // this.Score.shippersFreightScore.map((searchZero) => {
                //   if (searchZero.freightScoreDTO.overAll === 0) {
                //     setTimeout(() => {
                //       this.confirmService.confirm({
                //         message: 'lkdafjlkdsafsajd lfjsdlfsadflkdsafjsad fjdsflksaj', 
                //         header: 'No score', 
                //         rejectVisible: false,
                //         acceptVisible: false
                //       })
                //     }, 1000)
                //   }
                // })
                // console.log('zero state', this.Score.shippersFreightScore[0].freightScoreDTO.overAll === 0);
              }
            }
             else {
              console.log('errr');
              setTimeout(() => {
                this.store.dispatch(hideSpinner());
              }, 500);
              this.factorNamesDefault();
            }
          },
          error: (error) => {
            setTimeout(() => {
              this.store.dispatch(hideSpinner());
            }, 500);
            this.factorNamesDefault();
          }
        })
      }
      if (this.type === 'Market') {
        const payload2 = {
          searchResult: [this.selectCompare[0]],
        }
        this.orgService.marketviewscoreGenrate(payload2).subscribe({
          next: async (res: any) => {
            if (res.success) {
              if (res.data.length > 0) {
                this.shipperArray = [];
                this.selectShipper = [];
                // this.factorNamesDefault();
                // this.openConfirmShipper = true;
                this.shipperMainArray = res.data;
                this.shipperMainArray.forEach((d, index) => {
                  if (d.request.requestStatus === 'HIGHERACCOUNTNUMBER') {
                    this.selectedData = '';
                    this.selectedData = d;
                    setTimeout(() => {
                      this.store.dispatch(hideSpinner());
                    }, 500);
                    this.openConfirmShipper = true;
                    // if (val === true) {
                    //   this.openConfirmShipper = false;
                    // }
                    this.shipperArray = [];
                    this.selectShipper = [];
                    // this.factorNamesDefault();
                    d.request.accountData.forEach((d2) => {
                      this.shipperArray.push({
                        index: index,
                        data: d2,
                      });
                    })
                  }
                })
              }
              if (_.get(res.data, 'historyDashBoardResponses') || _.get(res.data, 'accountLevel')) {
                this.Score = this.selectCompare.length < 2 ? res.data.historyDashBoardResponses : res.data;
                this.ReportId = res.data?.reportId?res.data?.reportId[0]:null;
                this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
                this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
                setTimeout(() => {
                  this.showPrintBtn = true;
                  this.store.dispatch(hideSpinner());
                  this.updateTab();
                }, 500);
                this.Graphs.updateGraph(this.Score.keyMetrics);
              }
            } else {
              setTimeout(() => {
                this.store.dispatch(hideSpinner());
              }, 500);
              this.factorNamesDefault();
            }
          },
          error: (error) => {
            setTimeout(() => {
              this.store.dispatch(hideSpinner());
            }, 500);
            this.factorNamesDefault();
          }
        })
      }
    }
  }
  
  async searchScore() {
    this.type = 'Carrier';
    this.activeTabIndex = 0;
    this.expanding = false;
    this.showPrintBtn = false;
    const payload = {
      street: this.scoreSearch.controls["street"].value,
      city: this.scoreSearch.controls["city"].value,
      state: this.scoreSearch.controls["state"].value,
      postalCode: this.scoreSearch.controls["postalcode"].value,
      country: '',
      shipperName: this.scoreSearch.controls["shipperName"].value,
      accountNumber: this.scoreSearch.controls["accountNo"].value,
      searchType: Number(this.searchType),
    };
    this.compareData = [];
    this.selectCompare = [];
    this.ReportId = '';
    setTimeout(() => {
      this.store.dispatch(showSpinner());
    }, 1);
    if(this.btnAccess === true){
    this.orgService.getSearchResults(payload).subscribe(
      async (res: any) => {
        this.store.dispatch(hideSpinner());
        this.Score = {};
        this.loadedData = true;
        this.compareData = res.data.searchResult;
        this.orgService.getFactorNames().subscribe(
          async (res: any) => {
            if (res.success) {
              this.store.dispatch(hideSpinner());
              this.Score = res.data;
              this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
              this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
              setTimeout(() => {
                this.updateTab();
              }, 200);
              if (this.Graphs && typeof this.Graphs.updateGraph === 'function') {
                this.Graphs.updateGraph(this.Score.keyMetrics);
              }
            }
          },
          () => {
            this.store.dispatch(hideSpinner());
          }
          )
    },
    () => {
      this.store.dispatch(hideSpinner());
    }
    );}
    else{
      this.orgService.getShipper3PLScore(payload).subscribe(async (res: any) => {
  
        if (res.success) {
          this.store.dispatch(hideSpinner());
          this.Score = res.data;
          this.overAllNames = this.Score.accountLevelFFNames.concat(this.Score.locationLevelFFNames);
          this.overAllScore = this.Score.accountLevel[0].points.concat(this.Score.locationLevel[0].points);
          this.loadedData = true;
          this.expanding = true;
          setTimeout(() => {
            this.updateTab();
          }, 1000);
          this.Graphs.updateGraph(this.Score.keyMetrics);
          this.factorNamesDefault();
        }
      });
    }

    
    if (this.compareData.length === 0) {
      this.store.dispatch(hideSpinner());
      this.loadedData = false;
    }
    this.addedCompare = '';
  }

  async ngOnInit() {
    this.authService.getUserProfile().subscribe()
    const {
      AppRole: appRoleName,
      orgnizations: {
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    switch (appRoleName) {
      case 'Admin':
      this.superAdmin = true;
      if (organizationRoleName === 'Admin') {
        switch (organizationTypeName) {
          case 'Carrier':
            this.factorNamesDefault();
            this.superAdmin = false;
            this.ShipperapiAccess = false;
            return;
            case 'Shipper':
              this.type = 'Market';
              this.btnAccess = false;
              this.working = false;
              this.factorNamesDefault();
              this.superAdmin = false;
              return;
            case '3PL':
              this.type = 'Market';
              this.btnAccess = false;
              this.working = false;
              this.factorNamesDefault();
              this.superAdmin = false;
              return;
        }
        return;
      }
      return;
      case 'User':
        switch (organizationTypeName) {
          case 'Carrier':
            this.factorNamesDefault();
            this.superAdmin = false;
            this.ShipperapiAccess = false;
            return;
            case 'Shipper':
              this.type = 'Market';
              this.btnAccess = false;
              this.working = false;
              this.factorNamesDefault();
              this.superAdmin = false;
              return;
            case '3PL':
              this.type = 'Market';
              this.btnAccess = false;
              this.working = false;
              this.factorNamesDefault();
              this.superAdmin = false;
              return;
        }
        return;
    }
  }
  }
