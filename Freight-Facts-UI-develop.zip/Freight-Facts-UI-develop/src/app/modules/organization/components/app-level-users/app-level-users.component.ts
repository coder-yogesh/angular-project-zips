import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import { tableConfig } from './applevelusersconfig';
import {
  inputValidations,
  patterntValidations,
  passwordAndConfirmPasswordValidation,
  userNameValidations,
  passwordValidation,
} from 'src/app/core/common/utils';

import { ToastrService } from 'ngx-toastr';
import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import {
  showSpinner,
  hideSpinner,
} from 'src/app/store/actions/spinner.actions';
import { OrganizationService } from '../../services/organization.service';
import {
  OrgmetaData,
  RoleDataResponse,
  userResponse,
  usersDataReturnResponse,
} from '../../interfaces/orgnization-models';
import * as _ from 'lodash';
import { UserProfileInfoService } from 'src/app/shared/services/user-profile-info.service';
import { AuthService } from 'src/app/modules/auth/services/auth.service';
@Component({
  selector: 'app-app-level-users',
  templateUrl: './app-level-users.component.html',
  styleUrls: ['./app-level-users.component.scss'],
})
export class AppLevelUsersComponent {
  usersForm: FormGroup;
  header: string;
  showUserModal = false;

  usersData: usersDataReturnResponse[];
  buttoName: string;
  userId: number;
  deleteEventModal = false;
  deleteId: number;
  userRoleData;
  tableConfig: object;
  emailValidationPattern = regularExpressions.emailExp;
  roleFromLocalStorage: string;
  metaDataInfo: OrgmetaData;
  PageNumber = 0;
  pageSize = 5;
  search = '';
  showCreateUser = true;
  selectedImageUrl: any = null;
  imageAsFile: any = null;
  emailFirstLetter: string;
  loading:boolean
  constructor(
    private fb: FormBuilder,
    private service: OrganizationService,
    private toastr: ToastrService,
    private userService : UserProfileInfoService,
    private authService: AuthService,
    private store: Store<{ spinner: SpinnerState }>
  ) {
    this.usersForm = this.fb.group({
      id: [''],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: [
        '',
        [Validators.required, Validators.pattern(this.emailValidationPattern)],
      ],
      userRole: [null, [Validators.required]],
      // password: [''],
      // confirmPassword: [''],
      search: [null],
    });
    this.searchUser = _.debounce(this.searchUser, 300);
  }

  ngOnInit(): void {
    this.getuserRolesData();
    this.service.errorLoader.subscribe((res) => {
      if(res){
        this.loading=false
      }
    }); 
    const {
      AppRole: appRoleName,
      orgnizations: { OrgRole: organizationRoleName },
    } = JSON.parse(localStorage.getItem('Roles'));

    this.roleFromLocalStorage = appRoleName;
    this.getuserData({
      pageNumber: this.PageNumber,
      pageSize: this.pageSize,
      search: this.search,
    });
    this.showCreateUserBtn(appRoleName, organizationRoleName);
  }
  //  show create user button based on roles

  showCreateUserBtn(appRoleName, organizationRoleName) {
    switch (appRoleName) {
      case 'Admin':
        this.showCreateUser = true;
        this.showActionHeaders();
        return;
      case 'Member':
        this.showCreateUser = false;
        this.showActionHeaders();
        return;
      case 'User':
        switch (organizationRoleName) {
          case 'Owner':
            this.showCreateUser = true;
            this.showActionHeaders();
            return;
          case 'Pricing Admin':
            this.showCreateUser = false;
            this.showActionHeaders();
            return;
          case 'Member':
            this.showCreateUser = false;
            this.showActionHeaders();
            return;
          default:
            // alert('please contact admin')
            this.showCreateUser = false;
        }

        break;
      default:
        this.showCreateUser = false;
        break;
    }
  }
  // show action headers for table
  showActionHeaders() {
    // Modify the table configuration based on showActionsHeader
    this.tableConfig = this.showCreateUser
      ? tableConfig
      : {
          ...tableConfig,
          columns: tableConfig.columns.filter(
            (column) => column.header !== 'Actions'
          ),
        };
    return;
  }
  //show modal
  createUserModal() {
    this.showUserModal = true;
    this.header = 'Create User';
    this.buttoName = 'Create';
    this.usersForm.reset();
    this.selectedImageUrl = null;
    this.imageAsFile = null;
      // Set the password field as required for creating a new user
    // this.usersForm.get('password').setValidators([Validators.required]);
    // this.usersForm.get('password').updateValueAndValidity();
    // this.usersForm.get('confirmPassword').setValidators([Validators.required]);
    // this.usersForm.get('confirmPassword').updateValueAndValidity();
  }

  //close modal
  Close() {
    this.showUserModal = false;
    // this.usersForm.reset();
  }
   // searchUser
   searchUser() {
    const searchedText = this.usersForm.value.search;
    this.getuserData({
      pageNumber: this.PageNumber,
      pageSize: this.pageSize,
      search: searchedText,
    });
  }
 

  // name validation
  
  onNameChange(event, form, type) {
    userNameValidations(event, form, type);
  }
  //pattern validation
  inputValidationsErrors = (usersForm: FormGroup, type: string) => {
    return inputValidations(usersForm, type);
  };
   //password validation
   checkPasswordValidation(form, type) {
    return passwordValidation(form, type);
  }
  //email pattern validation
  inputEmailPatternValidationsErrors = (usersForm: FormGroup, type: string) => {
    return patterntValidations(usersForm, type);
  };
  // password and confirm password validation
  confirmPasswordValidation = (
    usersForm: FormGroup,
    passwordFieldName: string,
    confirmPasswordFieldName: string
  ) => {
    return passwordAndConfirmPasswordValidation(
      usersForm,
      passwordFieldName,
      confirmPasswordFieldName
    );
  };

  //submit accessoral
  createUser(id) {
  
    
    const { firstName, lastName, email, userRole } =
      this.usersForm.value;
    const userFormData=new FormData()
   userFormData.append('id',id)
   userFormData.append('firstName',firstName)
   userFormData.append('lastName',lastName)
   userFormData.append('email',email)
  //  userFormData.append('password',password)
   userFormData.append('applicationRole',userRole.id)
    userFormData.append('profilePicture',this.imageAsFile)
    
    this.store.dispatch(showSpinner());
    this.loading=true
    if (id === '') {
      this.service.createAppLevelUser(userFormData).subscribe((res) => {
        this.Close();

        this.toastr.success(res?.message);
        this.getuserData({
          pageNumber: this.PageNumber,
          pageSize: this.pageSize,
          search: this.search,
        });
        this.loading=false
        this.store.dispatch(hideSpinner());
      });
    } else {
      userFormData.append('id',id)
      this.service.updateAppLevelUser(userFormData).subscribe((res) => {
        this.Close();
        this.toastr.success(res?.message);
        this.loading=false
        this.getuserData({
          pageNumber: this.PageNumber,
          pageSize: this.pageSize,
          search: this.search,
        });
        this.authService.getUserProfile().subscribe((user: any) => {              
          if(user?.data?.id == res?.data?.id){
            this.userService.updateUserProfileData(res?.data);
          }
        });
        setTimeout(() => {
          this.store.dispatch(hideSpinner());
          this.toastr.success(res?.message); 
        },800)
      });
    }
  }

  // edit modal
  editUser(data) {
    this.buttoName = 'Update';
    this.header = 'Edit User';
    this.showUserModal = true;
    this.userId = data?.id;
    const updateUserRole = this.userRoleData.find(
      (item) => item.name == data.role
    );
      // Remove the 'required' validator from the password field
  // this.usersForm.get('password').clearValidators();
  // this.usersForm.get('password').updateValueAndValidity();
  // this.usersForm.get('confirmPassword').clearValidators();
  // this.usersForm.get('confirmPassword').updateValueAndValidity();
    
     this.selectedImageUrl=data.profilePicture =="null" ? null :data.profilePicture
    this.usersForm.patchValue({
      id: data.id,
      firstName: data.firstName,
      lastName: data.lastname,
      email: data.email,
      // password: data.password,
      // confirmPassword: data.password,
      userRole: updateUserRole,
    });
  }
  //close delete modal
  closeModal() {
    this.deleteEventModal = false;
  }
  //deleteUser
  deleteUser(id: number) {
    this.deleteEventModal = true;
    this.deleteId = id;
  }
  //delete
  confirmDeleteUser() {
    this.store.dispatch(showSpinner());
    this.service.deleteAppLevelUser(this.deleteId).subscribe((res) => {
      this.deleteEventModal = false;
      this.store.dispatch(hideSpinner());
      this.toastr.success('User has been deleted');
      this.getuserData({
        pageNumber: this.PageNumber,
        pageSize: this.pageSize,
        search: this.search,
      });
    });
  }

  // get users
  getuserData(options: {
    pageNumber: number;
    pageSize: number;
    search: string;
  }) {
    this.store.dispatch(showSpinner());

    this.service.getAppLevelUser(options).subscribe((res: userResponse) => {
      this.store.dispatch(hideSpinner());
      this.usersData = res?.data?.organizationMembers.map((item) => {
        const fullName = `${item.firstName} ${item.lastName}`;
        return {
          id: item.id,
          name: fullName,
          firstName: item.firstName,
          lastname: item.lastName,
          email: item.email,
          role: item.applicationRole.name,
          profilePicture:item.profilePicture
        };
      });
      this.metaDataInfo = res?.data?.metaData;
    });
  }

  // get user roles
  getuserRolesData() {
    this.service.getAppLevelUserRoles().subscribe((res: RoleDataResponse) => {
      this.userRoleData = res;
    });
  }
  // checking if any changes happend in form to active update or save
  checkChanges(form) {
    return this.usersData.some(
      (a :any) =>
        a.firstName === form.value.firstName &&
        a.lastname === form.value.lastName &&
        a.email === form.value.email &&
        a.role === form.value.userRole?.name &&
        a.profilePicture===this.selectedImageUrl
    );
  }

    // select image from file manager
    onFileSelected(file: File) {
      this.imageAsFile = file;
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.selectedImageUrl = e.target.result;
      };
  
      reader.readAsDataURL(file);
    }
  actionFromTable(value): void {
    switch (value.type) {
      case 'edit':
        this.editUser(value.data);
        return;
      case 'delete':
        this.deleteUser(value.data.id);
        return;
      case 'pagination':
        this.PageNumber = value.data.page;
        this.getuserData({
          pageNumber: this.PageNumber,
          pageSize: this.pageSize,
          search: this.search,
        });
        return;
    }
  }
}
