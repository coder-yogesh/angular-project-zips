import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppLevelUsersComponent } from './app-level-users.component';

describe('AppLevelUsersComponent', () => {
  let component: AppLevelUsersComponent;
  let fixture: ComponentFixture<AppLevelUsersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AppLevelUsersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AppLevelUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
