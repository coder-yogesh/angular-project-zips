
  
   export const tableConfig = {
    columns: [
      {
        field: 'name',
        header: 'Name',
        pipe: 'titleCase',
      },
      {
        field: 'email',
        header: 'Email',
        pipe: 'null',
      },
      {
        field: 'role',
        header: 'Role',
        pipe: 'null',
      },
      {
        header: 'Actions',
        type: 'actions',
        actions: [
          {
            type: 'edit',
            text: 'Edit',
            icon: 'pi pi-pencil',
          },
          {
            type: 'delete',
            text: 'Delete',
            icon: 'pi pi-trash',
          },
        ],
      },
    ],
  };
  

    
      
  
 
  