

export const organizationTableConfig = {
    class: 'cursor-pointer',
    columns: [
      {
        field: 'name',
        header: 'Organization Name',
        pipe: 'titleCase',
        type: 'navigate',
        link: 'link'
      },
      { field: 'code',
        header: 'Code',
        pipe: 'null',
        type: 'navigate'
      },
      {
        field: 'contactEmail',
        header: 'Contact Email',
        pipe: 'null',
        type: 'navigate',
      },
      {
        field: 'organizationType',
        header: 'Organization Type',
        pipe: 'null',
        type: 'navigate',
      },
      {
        field: 'reports',
        header: 'Report Count',
        pipe: 'null',
        type: 'navigate',
      },
    ],
  };
  
  