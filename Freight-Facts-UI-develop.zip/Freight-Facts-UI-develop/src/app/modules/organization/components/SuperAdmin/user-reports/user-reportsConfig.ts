

export const UserConfig = {
  // class: 'cursor-pointer',
  columns: [
    {
      field: 'username',
      header: 'User Name',
      pipe: 'titleCase',
      // type: 'navigate',
      // link: 'link'
    },
    {
      field: 'contactEmail',
      header: 'Contact Email',
      pipe: 'null',
      // type: 'navigate',
    },
    {
      field: 'createdAt',
      header: 'Created At',
      pipe: 'null'
    },
    {
      field: 'role',
      header: 'Role',
      pipe: 'null'
    }
  ],
};