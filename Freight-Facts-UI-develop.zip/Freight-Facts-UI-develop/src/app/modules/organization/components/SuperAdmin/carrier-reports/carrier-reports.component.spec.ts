import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarrierReportsComponent } from './carrier-reports.component';

describe('CarrierReportsComponent', () => {
  let component: CarrierReportsComponent;
  let fixture: ComponentFixture<CarrierReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarrierReportsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarrierReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
