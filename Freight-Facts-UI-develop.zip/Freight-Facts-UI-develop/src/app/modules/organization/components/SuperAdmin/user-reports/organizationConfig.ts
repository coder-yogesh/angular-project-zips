export const organizationConfig = {
    class: 'cursor-pointer',
    columns: [
      {
        field: 'username',
        header: 'User Name',
        pipe: 'titleCase',
        type: 'navigate',
        link: 'link'
      },
      {
        field: 'contactEmail',
        header: 'Contact Email',
        pipe: 'null',
        type: 'navigate',
      },
      {
        field: 'role',
        header: 'Role',
        pipe: 'null',
        type: 'navigate'
      },
      {
        field: 'reports',
        header: 'Report Count',
        pipe: 'null',
        type: 'navigate'
      },
    ],
  };