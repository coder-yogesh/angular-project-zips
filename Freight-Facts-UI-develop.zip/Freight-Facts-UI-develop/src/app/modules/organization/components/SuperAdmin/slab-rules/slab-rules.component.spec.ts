import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SlabRulesComponent } from './slab-rules.component';

describe('SlabRulesComponent', () => {
  let component: SlabRulesComponent;
  let fixture: ComponentFixture<SlabRulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SlabRulesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SlabRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
