import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipperReportsComponent } from './shipper-reports.component';

describe('ShipperReportsComponent', () => {
  let component: ShipperReportsComponent;
  let fixture: ComponentFixture<ShipperReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShipperReportsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShipperReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
