import { Component, OnInit } from '@angular/core';
import { OrganizationService } from '../../../services/organization.service';
import { hideSpinner, showSpinner } from 'src/app/store/actions/spinner.actions';
import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { AuthService } from 'src/app/modules/auth/services/auth.service';

@Component({
  selector: 'app-super-admin-dashboard',
  templateUrl: './super-admin-dashboard.component.html',
  styleUrls: ['./super-admin-dashboard.component.scss']
})
export class SuperAdminDashboardComponent implements OnInit {
  data:any = {};
  userName: any = '';
  constructor (private organizationService: OrganizationService, public authServices:AuthService, private store: Store<{ spinner: SpinnerState }>) {}

  superAdminDb() {
    this.store.dispatch(showSpinner());
    this.organizationService.superAdminDashboard().subscribe(
      (data:any) => {
        if (data.success) {
          this.data = data.data;
          this.store.dispatch(hideSpinner());
        }
      }
    );
  }
  getUserProfileData() {
    this.authServices.getUserProfile().subscribe((user: any) => {      
      this.userName = user?.data?.firstName
      console.log("sfs", this.userName)

    });
  }

  ngOnInit() {
    this.superAdminDb();
    this.getUserProfileData()
  }
}
