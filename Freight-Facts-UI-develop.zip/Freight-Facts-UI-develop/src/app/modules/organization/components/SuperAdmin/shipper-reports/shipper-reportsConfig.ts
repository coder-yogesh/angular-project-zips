

export const organizationTableConfig = {
    class: 'cursor-pointer',
    columns: [
        {
          field: 'name',
          header: 'Organization Name',
          pipe: 'titleCase',
          type: 'navigate',
          link: 'link'
        },
        {
          field: 'contactEmail',
          header: 'Contact Email',
          pipe: 'null',
          type: 'navigate',
        },
        {
          field: 'createdAt',
          header: 'Created At',
          pipe: 'null',
          type: 'navigate',
        },
        {
          field: 'count',
          header: 'User Count',
          pipe: 'null',
          type: 'navigate',
        }
      ],
  };
  
  