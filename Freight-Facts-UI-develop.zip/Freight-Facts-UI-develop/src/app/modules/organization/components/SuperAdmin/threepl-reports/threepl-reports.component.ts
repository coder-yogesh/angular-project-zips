import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import { SpinnerState } from 'src/app/store/state/spinner.state';

import { organizationTableConfig } from './threepl-reportsConfig';
import { Router } from '@angular/router';
import { OrganizationService } from '../../../services/organization.service';
import {
  OrgmetaData,
  organizationListReturnResponse,
} from '../../../interfaces/orgnization-models';
import { Location } from '@angular/common';
import moment from 'moment';

@Component({
  selector: 'app-threepl-reports',
  templateUrl: './threepl-reports.component.html',
  styleUrls: ['./threepl-reports.component.scss'],
})
export class ThreeplReportsComponent implements OnInit {
  organizationReport: FormGroup;
  organizations: organizationListReturnResponse[] = [];
  organizationId: number;
  organizationTableConfig: object = organizationTableConfig;
  metaDataInfo: OrgmetaData;
  paginationInfo: any = {
    page: 0,
    rows: 5,
  };
  search = '';
  loading:boolean;
  constructor(
    private location: Location,
    private fb: FormBuilder,
    private service: OrganizationService,
    private router: Router,
    private store: Store<{ spinner: SpinnerState }>
  ) {
    this.organizationReport = this.fb.group({
      search: [null],
    });
  }

  navigateToBack() {
    this.location.back();
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
  }

  //get Organizations
  getOrganizationsList() {
    this.store.dispatch(showSpinner());
    this.service.threeplReports(this.paginationInfo, this.search).subscribe(
      (res: any) => {
        if (res.success) {
          this.store.dispatch(hideSpinner());
          this.organizations = res?.data.users.map((item: any) => {
            return {
              organizationId: item.organization_id,
              name: item.name,
              contactEmail: item.email,
              createdAt: moment(item.createdAt).format('MM-DD-YYYY'),
              count: Number(item.usersCount)
            };
          });
          this.metaDataInfo = res?.data.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
          localStorage.setItem('page', JSON.stringify(this.paginationInfo));
        } else {
          this.organizations = [];
        }
        this.store.dispatch(hideSpinner());
      },
      () => {
        this.organizations = [];
      }
    );
  }

  ngOnInit() {
    const pageNations =
      JSON.parse(localStorage.getItem('page')) || this.paginationInfo;
    this.paginationInfo = pageNations;
    this.getOrganizationsList();
  }

  //searching organizations
  searchOrganization(event) {
    this.search = event.target.value;
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
    if (event.target.value) {
      this.service
        .threeplReports(this.paginationInfo, this.search)
        .subscribe((res: any) => {
          this.organizations = res?.data.users.map((item) => {
            return {
              id: item.id,
              logo: item.logo,
              name: item.name,
              username: item.first_name + ' ' + item.last_name,
              contactEmail: item.email,
              role: item.application_Role
            };
          });
          this.metaDataInfo = res?.data?.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
        });
    } else {
      this.paginationInfo = {
        page: 0,
        rows: 5,
      };
      localStorage.setItem('page', JSON.stringify(this.paginationInfo));
      this.metaDataInfo.pageNumber = 0;
      this.getOrganizationsList();
    }
  }

  actionFromTable(value): void {
    switch (value.type) {
      case 'navigate':
        this.router.navigate([
          `/freightfacts/3pl-reports/details`,
          
          value.data.organizationId,
        ]);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.getOrganizationsList();
        return;
    }
  }
}
