import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import { SpinnerState } from 'src/app/store/state/spinner.state';

import { organizationConfig } from './organizationConfig';
import { UserConfig } from './user-reportsConfig';
import { Router } from '@angular/router';
import { OrganizationService } from '../../../services/organization.service';
import {
  OrgmetaData,
  organizationListReturnResponse,
} from '../../../interfaces/orgnization-models';
import { Location } from '@angular/common';
import moment from 'moment';

@Component({
  selector: 'app-threepl-reports',
  templateUrl: './user-reports.component.html',
  styleUrls: ['./user-reports.component.scss'],
})
export class UserReportsComponent implements OnInit {
  organizationReport: FormGroup;
  organizations: organizationListReturnResponse[] = [];
  organizationId: number;
  organizationTableConfig = {};
  metaDataInfo: OrgmetaData;
  paginationInfo: any = {
    page: 0,
    rows: 5,
  };
  search = '';
  pageName = '';
  orgId = '';
  loading:boolean;
  constructor(
    private location: Location,
    private fb: FormBuilder,
    private service: OrganizationService,
    private router: Router,
    private store: Store<{ spinner: SpinnerState }>
  ) {
    this.organizationReport = this.fb.group({
      search: [null],
    });
  }

  navigateToBack() {
    this.location.back();
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
  }

  //get Organizations
  getOrganizationsList() {
    this.store.dispatch(showSpinner());
    const reportPath = this.router.url.split('/')[2];
    this.orgId = this.router.url.split('/')[4];
    switch (reportPath) {
      case 'organizations-reports':
        this.organizationTableConfig = organizationConfig;
        this.pageName = localStorage.getItem('orgName');
        this.service.organizationReports(this.paginationInfo, this.search, this.orgId).subscribe(
          (res: any) => {
            if (res.success) {
              this.store.dispatch(hideSpinner());
              this.organizations = res?.data.body.content.map((item: any) => {
                return {
                  id: item.id,
                  username: item.firstName + ' ' + item.lastName,
                  contactEmail: item.email,
                  role: item.role,
                  reports: String(item.reportCount)
                };
              });
              this.metaDataInfo = res?.data.body.metaData;
              this.paginationInfo.page = res?.data.body.metaData.pageNumber;
              this.paginationInfo.rows = res?.data.body.metaData.pageSize;
              localStorage.setItem('page', JSON.stringify(this.paginationInfo));
            } else {
              this.organizations = [];
            }
            this.store.dispatch(hideSpinner());
          },
          () => {
            this.organizations = [];
          }
        );
        return;
        case 'carrier-reports':
          this.organizationTableConfig = UserConfig;
          this.pageName = 'Users';
          this.service.carrierUserReports(this.paginationInfo, this.search, this.orgId).subscribe(
            (res: any) => {
              if (res.success) {
                this.store.dispatch(hideSpinner());
                this.organizations = res?.data.body.content.map((item: any) => {
                  return {
                    id: item.id,
                    username: item.firstName + ' ' + item.lastName,
                    contactEmail: item.email,
                    role: item.applicationRole,
                    createdAt: moment(item.createdAt).format('MM-DD-YYYY'),
                    reports: String(item.reportCount)
                  };
                });
                this.metaDataInfo = res?.data.body.metaData;
                this.paginationInfo.page = res?.data.body.metaData.pageNumber;
                this.paginationInfo.rows = res?.data.body.metaData.pageSize;
                localStorage.setItem('page', JSON.stringify(this.paginationInfo));
              } else {
                this.organizations = [];
              }
              this.store.dispatch(hideSpinner());
            },
            () => {
              this.organizations = [];
            }
          );
          return;
          case 'shipper-reports':
            this.organizationTableConfig = UserConfig;
            this.pageName = 'Users';
            this.service.shipperUserReports(this.paginationInfo, this.search, this.orgId).subscribe(
              (res: any) => {
                if (res.success) {
                  this.store.dispatch(hideSpinner());
                  this.organizations = res?.data.body.content.map((item: any) => {
                    return {
                      id: item.id,
                      username: item.firstName + ' ' + item.lastName,
                      contactEmail: item.email,
                      role: item.applicationRole,
                      createdAt: moment(item.createdAt).format('MM-DD-YYYY'),
                      reports: String(item.reportCount)
                    };
                  });
                  this.metaDataInfo = res?.data.body.metaData;
                  this.paginationInfo.page = res?.data.body.metaData.pageNumber;
                  this.paginationInfo.rows = res?.data.body.metaData.pageSize;
                  localStorage.setItem('page', JSON.stringify(this.paginationInfo));
                } else {
                  this.organizations = [];
                }
                this.store.dispatch(hideSpinner());
              },
              () => {
                this.organizations = [];
              }
            );
            return;
            case '3pl-reports':
              this.organizationTableConfig = UserConfig;
              this.pageName = 'Users';
              this.service.threeplUserReports(this.paginationInfo, this.search, this.orgId).subscribe(
                (res: any) => {
                  if (res.success) {
                    this.store.dispatch(hideSpinner());
                    this.organizations = res?.data.body.content.map((item: any) => {
                      return {
                        id: item.id,
                        username: item.firstName + ' ' + item.lastName,
                        contactEmail: item.email,
                        role: item.applicationRole,
                        createdAt: moment(item.createdAt).format('MM-DD-YYYY'),
                        reports: String(item.reportCount)
                      };
                    });
                    this.metaDataInfo = res?.data.body.metaData;
                    this.paginationInfo.page = res?.data.body.metaData.pageNumber;
                    this.paginationInfo.rows = res?.data.body.metaData.pageSize;
                    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
                  } else {
                    this.organizations = [];
                  }
                  this.store.dispatch(hideSpinner());
                },
                () => {
                  this.organizations = [];
                }
              );
              return;
      default:
        this.organizationTableConfig = UserConfig;
        this.pageName = 'Users';
        return;
    }
  }

  actionFromTable(value): void {
    switch (value.type) {
      case 'navigate':
        this.router.navigate([
          `/freightfacts/history`,

          value.data.id,
        ]);
        
        localStorage.setItem('checkhistoryName', value.data.username);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.getOrganizationsList();
        return;
    }
  }

  ngOnInit() {
    const pageNations =
      JSON.parse(localStorage.getItem('page')) || this.paginationInfo;
    this.paginationInfo = pageNations;
    this.getOrganizationsList();
  }
}
