import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
import { SpinnerState } from 'src/app/store/state/spinner.state';

import { organizationTableConfig } from './organizationreports-tableconfig.component';
import { Router } from '@angular/router';
import { OrganizationService } from '../../../services/organization.service';
import {
  OrgmetaData,
  organizationListReturnResponse,
} from '../../../interfaces/orgnization-models';
import { Location } from '@angular/common';

@Component({
  selector: 'app-organizations-reports',
  templateUrl: './organization-reports.component.html',
  styleUrls: ['./organization-reports.component.scss'],
})
export class OrganizationReportsComponent implements OnInit {
  organizationReport: FormGroup;
  organizations: organizationListReturnResponse[] = [];
  organizationId: number;
  organizationTableConfig: object = organizationTableConfig;
  metaDataInfo: OrgmetaData;
  paginationInfo: any = {
    page: 0,
    rows: 5,
  };
  search = '';
  loading:boolean;
  constructor(
    private location: Location,
    private fb: FormBuilder,
    private service: OrganizationService,
    private router: Router,
    private store: Store<{ spinner: SpinnerState }>
  ) {
    this.organizationReport = this.fb.group({
      search: [null],
    });
  }

  navigateToBack() {
    this.location.back();
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
  }

  //get Organizations
  getOrganizationsList() {
    this.store.dispatch(showSpinner());
    this.service.totalReports(this.paginationInfo, this.search).subscribe(
      (res: any) => {
        if (res.success) {
          this.store.dispatch(hideSpinner());
          this.organizations = res?.data.totalReports.map((item: any) => {
            return {
              id: item.id,
              logo: item.logo,
              name: item.name,
              code: item.code,
              contactEmail: item.contact_email,
              organizationType: item.organizationType,
              reports: String(item.total_reports)
            };
          });
          this.metaDataInfo = res?.data.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
          localStorage.setItem('page', JSON.stringify(this.paginationInfo));
        } else {
          this.organizations = [];
        }
        this.store.dispatch(hideSpinner());
      },
      () => {
        this.organizations = [];
      }
    );
  }

  ngOnInit() {
    const pageNations =
      JSON.parse(localStorage.getItem('page')) || this.paginationInfo;
    this.paginationInfo = pageNations;
    this.getOrganizationsList();
  }

  //searching organizations
  searchOrganization(event) {
    this.search = event.target.value;
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
    if (event.target.value) {
      this.service
        .totalReports(this.paginationInfo, this.search)
        .subscribe((res: any) => {
          this.organizations = res?.data.organizations.map((item) => {
            return {
              id: item.id,
              logo: item.logo,
              name: item.name,
              code: item.code,
              contactEmail: item.contactEmail,
              organizationType: item.type.name,
            };
          });
          this.metaDataInfo = res?.data?.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
        });
    } else {
      this.paginationInfo = {
        page: 0,
        rows: 5,
      };
      localStorage.setItem('page', JSON.stringify(this.paginationInfo));
      this.metaDataInfo.pageNumber = 0;
      this.getOrganizationsList();
    }
  }

  actionFromTable(value): void {
    switch (value.type) {
      case 'navigate':
        this.router.navigate([
          `/freightfacts/organizations-reports/details`,

          value.data.id,
        ]);
        localStorage.setItem('orgName', value.data.name);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.getOrganizationsList();
        return;
    }
  }
}
