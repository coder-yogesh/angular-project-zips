import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-slab-table',
  templateUrl: './slab-table.component.html',
  styleUrls: ['./slab-table.component.scss']
})
export class SlabTableComponent {
  @Input() rules: any = [];
  @Input() total: any = '';
  @Output() actionHappens = new EventEmitter();
  table = [
    { freightFact: 'Avg Length of Haul', pointsEarned: '20', maxPoints: '30', minPoints: '30' },
    { freightFact: 'Billing Exceptions', pointsEarned: '30', maxPoints: '30', minPoints: '30' },
    { freightFact: 'Claims Filed', pointsEarned: '20', maxPoints: '30', minPoints: '30' },
    { freightFact: 'Claims Paid', pointsEarned: '30', maxPoints: '30', minPoints: '30' },
    { freightFact: 'Days to Pay', pointsEarned: '20', maxPoints: '30', minPoints: '30' },
    { freightFact: 'Digital BOLs', pointsEarned: '30', maxPoints: '30', minPoints: '30' },
    { freightFact: 'vol_shipments_monthly', pointsEarned: '20', maxPoints: '30', minPoints: '30' },
  ];
  deleteAction(val: any, item: any) {
    this.actionHappens.emit({ val, item });
  }
}
