import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SlabTableComponent } from './slab-table.component';

describe('SlabTableComponent', () => {
  let component: SlabTableComponent;
  let fixture: ComponentFixture<SlabTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SlabTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SlabTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
