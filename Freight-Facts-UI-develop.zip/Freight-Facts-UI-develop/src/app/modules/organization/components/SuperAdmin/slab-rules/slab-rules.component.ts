import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import { OrganizationService } from '../../../services/organization.service';
import { acceptSpecialCharacters, inputValidations, targetMaxValidations } from 'src/app/core/common/utils';
import { hideSpinner, showSpinner } from 'src/app/store/actions/spinner.actions';
import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';

@Component({
  selector: 'app-slab-rules',
  templateUrl: './slab-rules.component.html',
  styleUrls: ['./slab-rules.component.scss']
})
export class SlabRulesComponent implements OnInit {
  slabRuleForm: FormGroup;
  slabHeader: string;
  slabRuleId: number;
  activeIndex:any;
  addedSlabs = [];
  organizationList: any = [];
  selectedOrg: any = '';
  selected = false;
  superAdmin = false;
  openSlabRuleModel = false;
  loading = false;
  slabRules: any = '';
  isSlab: boolean;
  calculatedValue: any = '';
  slabOptions: object [] = [
    { name: 'Percentage' },
    { name: 'Flat' }
  ];
  deleteEventModal = false;
  showResult: boolean;
  deleteId: number;
  toasterService: any;
  constructor (private fb: FormBuilder, private orgService: OrganizationService, private store: Store<{ spinner: SpinnerState }>) {
    this.slabRuleForm = this.fb.group({
      freightFactName: [''],
      Points: [''],
      pointsEarned: ['', [Validators.required, Validators.maxLength(5), Validators.min(0)]],
      maxPoints: ['', [Validators.required, Validators.maxLength(10), Validators.min(0)]],
      minPoints: ['', [Validators.required, Validators.maxLength(10), Validators.min(0)]],
      flatSlab: ['', Validators.required],
      selectFlatSlab: ['Percentage'],
    })
  }
  removeOrg() {
    this.selectedOrg = '';
    this.selected = false;
  }
  changeOrgName() {
    this.store.dispatch(showSpinner());
    setTimeout(() => {
      this.selected = true;
      this.store.dispatch(hideSpinner());
    }, 1000);
  }
  onFlatSlabChange(event, form, type) {
    form.get(type).setValue(acceptSpecialCharacters(event, form, type));
  }
  earnedValue() {
    const {
      pointsEarned,
      Points,
      selectFlatSlab
    } = this.slabRuleForm.value;
    // eslint-disable-next-line @typescript-eslint/no-unused-vars, prefer-const
    let value: any = pointsEarned / 100 * Points;
    if (selectFlatSlab.name === 'Flat') {
      return pointsEarned <= 0 ? 0 : pointsEarned;
    }
    if (regularExpressions.decimalValueExp.test(value)) {
      return value;
    }
    return value.toFixed(2);
  }
  createSlabRule() {
    this.slabHeader = 'Create Slab Rule';
    this.slabRuleForm.reset();
    this.openSlabRuleModel = true;
  }
  close() {
    this.openSlabRuleModel = false;
  }
  actionFromTable(val: any) {
    if (val.item === 'edit') {
      this.slabHeader = this.superAdmin ? 'Edit Rule' : 'Rule Details';
      this.loading = true;
      this.addedSlabs = [];
      this.slabRuleForm.reset();
      this.openSlabRuleModel = true;
      this.slabRuleId = val.val.id;
      this.slabRuleForm.patchValue({
        freightFactName: val.val.freightFactName === 'Total Weight' ? 'Average Weight Per Shipment' : val.val.freightFactName,
        Points: val.val.maxPoints,
        selectFlatSlab: this.slabOptions[0],
      });
      this.orgService.getSlabData(this.slabRuleId, '', this.isSlab, this.superAdmin, this.selectedOrg).subscribe((res: any) => {
        this.addedSlabs = res.data.slabs;
        this.isSlab = res.data.isFlatSlab;
        this.loading = false;
        if (this.addedSlabs.length > 0) {
          this.slabRuleForm.patchValue({
            selectFlatSlab: this.addedSlabs[0].weightType === 'FLAT' ? this.slabOptions[1] : this.slabOptions[0],
          })
        }
      })
    }
  }
  updateSlabRuleList() {
    const {
      selectFlatSlab
    } = this.slabRuleForm.value;
    this.orgService.getSlabData(this.slabRuleId, selectFlatSlab.name, this.isSlab, this.superAdmin, this.selectedOrg).subscribe((res: any) => {
      this.addedSlabs = res.data.slabs;
      this.isSlab = res.data.isFlatSlab;
      if (this.addedSlabs.length > 0) {
        this.slabRuleForm.patchValue({
          selectFlatSlab: this.addedSlabs[0].weightType === 'FLAT' ? this.slabOptions[1] : this.slabOptions[0],
        })
      }
    })
  }
  inputValidationsErrors = (form: FormGroup, type: string) => {
    return inputValidations(form, type);
  };
  checkSlab() {
    const {
      pointsEarned,
      Points,
      selectFlatSlab,
    } = this.slabRuleForm.value;
    if (selectFlatSlab.name === 'Flat') {
      if (pointsEarned > Points) {
        return true;
      }
    }
    return false;
  }
  targetMaxValidations(form: FormGroup, target: string, max: string) {
    return targetMaxValidations(form, target, max);
  }
  checkForm() {
    if (!this.isSlab) {
      if (this.slabRuleForm.controls['pointsEarned'].valid &&
        this.slabRuleForm.controls['maxPoints'].valid &&
          this.slabRuleForm.controls['minPoints'].valid) {
          return false;
      }
    }
    if (this.isSlab) {
      if (this.slabRuleForm.controls['pointsEarned'].valid &&
        this.slabRuleForm.controls['flatSlab'].valid) {
          return false;
      }
    }
    return true;
  }
  addSlab(val: any) {
    if (!this.checkForm()) {
      const payload = {
        masterCarrierId: this.slabRuleId,
        min: Number(this.slabRuleForm.value.minPoints),
        max: Number(this.slabRuleForm.value.maxPoints),
        points_earned: Number(this.slabRuleForm.value.pointsEarned),
        flatSlab: this.slabRuleForm.value.flatSlab,
        weightType: this.slabRuleForm.value.selectFlatSlab.name,
        orgName: this.selectedOrg.name,
      };
      this.orgService.createSlabRule(payload).subscribe((res: any) => {
        if (res.success) {
          this.slabRuleForm.controls['pointsEarned'].reset();
          this.slabRuleForm.controls['maxPoints'].reset();
          this.slabRuleForm.controls['minPoints'].reset();
          this.slabRuleForm.controls['flatSlab'].reset();
          this.openSlabRuleModel = val === 'update' ? false : true;
          this.updateSlabRuleList();
        }
      })
    }
  }
  
  deleteSlab(id: number) {
    this.deleteEventModal = true;
    this.deleteId = id;
  }

  confirmDeleteSlab() {
    this.orgService
      .deleteSlabRule(this.deleteId)
      .subscribe((res:any) => {
        if (res.success) {
          this.deleteEventModal = false;
          this.updateSlabRuleList();
        }
      });
  }
  closeModal() {
    this.deleteEventModal = false;
  }
  changeTab(event:any) {
    this.activeIndex = event.index;
    // const tabHeaderName = event.originalEvent.target.innerText;
  }
  
  getAccess() {
    const {
      AppRole: appRoleName,
      orgnizations: {
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    switch (appRoleName) {
      case 'Admin':
      if (!organizationRoleName) {
        // this.historyFilter = [{ name: 'Date range', value: '' }]
        this.superAdmin = true;
      }
      return;
    }
  }

  ngOnInit() {
    this.store.dispatch(showSpinner());
    this.selectedOrg = '';
    this.showResult = false;
    this.getAccess();
    this.orgService.getSlabRules().subscribe((res: any) => {
      this.showResult = true;
      this.slabRules = res.data;
      this.store.dispatch(hideSpinner());
    });
    this.orgService.getOrganizationNames().subscribe((res: any) => {
      res.data.forEach((d) => {
        if (d.type.name === 'Carrier' || 'superAdmin') {
          this.organizationList.push(d);
        }
      });
      this.store.dispatch(hideSpinner());
    });
  }
}
