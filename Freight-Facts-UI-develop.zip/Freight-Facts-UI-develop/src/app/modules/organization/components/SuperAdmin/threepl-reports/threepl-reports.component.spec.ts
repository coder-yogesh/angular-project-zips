import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ThreeplReportsComponent } from './threepl-reports.component';

describe('ThreeplReportsComponent', () => {
  let component: ThreeplReportsComponent;
  let fixture: ComponentFixture<ThreeplReportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ThreeplReportsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ThreeplReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
