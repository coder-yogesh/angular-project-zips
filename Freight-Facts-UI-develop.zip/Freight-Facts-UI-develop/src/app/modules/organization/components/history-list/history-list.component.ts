import { Component, OnInit, ViewChild } from '@angular/core';
import { historyTableConfig } from './history-tableconfig';
import { usersHistoryTableConfig } from './users-historyConfig';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AuthService } from 'src/app/modules/auth/services/auth.service';
import moment from 'moment';
import { Router } from '@angular/router';
import { OverlayPanel } from 'primeng/overlaypanel';
import { Column } from 'jspdf-autotable';
import { _isClickEvent } from 'chart.js/dist/helpers/helpers.core';
import { OrganizationService } from '../../services/organization.service';
import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { hideSpinner, showSpinner } from 'src/app/store/actions/spinner.actions';
import { Location } from '@angular/common';

@Component({
  selector: 'app-history-list',
  templateUrl: './history-list.component.html',
  styleUrls: ['./history-list.component.scss']
})
export class HistoryListComponent implements OnInit {
  @ViewChild('myCalendar') myCalendar;
  date: Date | undefined;
  historyForm: FormGroup;
  dateForm: FormGroup;
  historyTableConfig = {};
  historyList:any = [];
  historyFilter: any = [ 
    { name: 'Date range', value: '' },
    // { name: 'Shipper Name', value: '1' },
    { name: 'Location', value: '0'},
    // { name: 'Account Number', value: '2' }
  ];
  paginationInfo: any = {
    page: 0,
    rows: 10,
    shipperName: '',
    startDate: '',
    endDate: '',
    accNumber: '',
    street: '',
    city: '',
    state: '',
    postalCode: '',
  };
  placeholder = '<span style="color: gray">Select an option</span>';
  locationData: any = [
    { street: '10040 LICKINGHOLE RD', city: 'ASHLAND', state: 'VA', zipcode: '23005' },
    { street: '1517 COINING DR', city: 'TOLEDO', state: 'OH', zipcode: '43612' },
    { street: '377 PAUL HOLLOW RD', city: 'GALETON', state: 'PA', zipcode: '16922' },
    { street: '651 N WASHINGTON ST', city: 'WILKES BARRE', state: 'PA', zipcode: '18705' },
    { street: '7255 INDUSTRIAL PARK BLVD', city: 'MENTOR', state: 'OH', zipcode: '44060' },
  ];
  shipperZipcode: any = [];
  selectedZipcode: any = [];
  selectedStreet: any = [];
  shipperCity: any = [];
  shipperState: any = [];
  selectedState: any = [];
  selectedCity: any = [];
  selectedName: any = [];
  selectLocation: any = [];
  selectedLocation: any = [];
  selectedShipper: any;
  shipperNames: any[];
  shipperStreet: any[];
  selectAccountNo: any = [];
  selectedAccountNo: any = [];
  shipperAccountNo: any[];
  showDateModal = false;
  userIdadmin = '';
  selectFilter = [];
  search = '';
  filterDate = '';
  startDate: any = '';
  endDate: any = '';
  maxDate = new Date();
  metaDataInfo: any;
  ShipperApiAccess = true;
  superAdmin = false;
  viewicon = "";
  userName: string;
  userId: any;
  constructor (
    private location: Location,
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private orgService: OrganizationService,
    private store: Store<{ spinner: SpinnerState }>
    ) {
    this.historyForm = this.fb.group({
      search: [null],
      selectDate: [''],
    });
  }

  // criteria names of history
  criteriaResult(result: any) {
    if (result.searchRequestType === '1') {
      return result.shipperName;
    } else if (result.searchRequestType === '2') {
      return result.accNumber;
    } else {
      return result.address;
    }
  }

  dateFormat(val: any) {
    const date = val;
    const set = moment.utc(date).format('MM-DD-YYYY h:mm A');
    return set;
  }

  // page load function
  async loadPage() {
    this.store.dispatch(showSpinner());
    this.paginationInfo = {
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
      shipperName: this.paginationInfo.shipperName,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.paginationInfo.accNumber,
      street: this.paginationInfo.street,
      city: this.paginationInfo.city,
      state: this.paginationInfo.state,
      postalCode: this.paginationInfo.postalCode
    }
    await this.orgService.getHistoryList(this.paginationInfo, this.ShipperApiAccess, this.superAdmin, this.router.url.split('/')[3]).subscribe(
      (res: any) => {
        if (res.data !== null) {
          this.historyList = res?.data.scoreResponseDTOS.map((item: any, index) => {
            return {
              no: String(item.serialId),
              firstName: `${item.user.firstName} ${item.user.lastName}`,
              businessName: item.shipperName,
              date: this.dateFormat(item.createdAt),
              overAll: String(item.overAllScore),
              criteria: this.criteriaResult(item),
              searchType: item.searchRequestType,
              id: item.id,
            };
          });
          this.metaDataInfo = res?.data.metaData;
          this.paginationInfo.page = res?.data.metaData.pageNumber;
          this.paginationInfo.rows = res?.data.metaData.pageSize;
          localStorage.setItem('page', JSON.stringify(this.paginationInfo));
          this.store.dispatch(hideSpinner());
        } else {
          this.metaDataInfo = {
            pageNumber: 0,
            pageSize: 0,
            totalPages: 0,
            totalRecords: 0,
          };
          this.historyList = [];
        }
        // this.store.dispatch(hideSpinner());
      },
      () => {
        this.metaDataInfo = {
          pageNumber: 0,
          pageSize: 0,
          totalPages: 0,
          totalRecords: 0,
        };
        this.historyList = [];
      }
    );
    this.historyTableConfig = this.superAdmin ? usersHistoryTableConfig : historyTableConfig;
  }

  // selected filter
  filterType() {
    this.paginationInfo.page = 0;
    this.paginationInfo.rows = 10;
    // if (event.value.value === '') {
    //   this.showDateModal = true;
    // }
    // if (event.value.value === '1') {
    //   this.selectedName = [];
    //   this.shipperNames = [{ name: 'All' }];
    //   this.selectedShipper = this.shipperNames[0];
    //   this.orgService.getHistoryFilterNames(this.userId, event.value.value, this.userIdadmin).subscribe(
    //     (res: any) => {
    //       const data = res.data.map((data) => {
    //         return { name: data }
    //       })
    //       this.shipperNames = data;
    //       this.shipperNames.splice(0, 0, { name: 'All' });
    //       this.selectedShipper = this.shipperNames[0];
    //     })
    //   this.selectedName.push(event);
    // }
    // if (event.value.value === '0') {
      this.selectLocation = [];
      // this.shipperStreet = [{ name: 'All' }];
      // this.selectedStreet = this.shipperStreet[0];
      this.orgService.getHistoryFilterNames(this.userId, '0', this.userIdadmin, 'street').subscribe(
        (res: any) => {
          const data = res.data.map((data) => {
            return { name: data }
          })
          this.shipperStreet = data;
          // this.shipperStreet.splice(0, 0, { name: 'All' });
          // this.selectedStreet = this.shipperStreet[0];
        })
        // this.shipperCity = [{ name: 'All' }];
        this.orgService.getHistoryFilterNames(this.userId, '0', this.userIdadmin, 'city').subscribe(
          (res: any) => {
            const data = res.data.map((data) => {
              return { name: data }
            })
            this.shipperCity = data;
            // this.shipperCity.splice(0, 0, { name: 'All' });
            // this.selectedCity = this.shipperCity[0];
          })
        // this.shipperState = [{ name: 'All' }];
        this.orgService.getHistoryFilterNames(this.userId, '0', this.userIdadmin, 'state').subscribe(
          (res: any) => {
            const data = res.data.map((data) => {
              return { name: data }
            })
            this.shipperState = data;
            // this.shipperState.splice(0, 0, { name: 'All' });
            // this.selectedState = this.shipperState[0];
          })
        // this.shipperZipcode = [{ name: 'All' }];
        this.orgService.getHistoryFilterNames(this.userId, '0', this.userIdadmin, 'postal_code').subscribe(
          (res: any) => {
            const data = res.data.map((data) => {
              return { name: data }
            })
            this.shipperZipcode = data;
            // this.shipperZipcode.splice(0, 0, { name: 'All' });
            // this.selectedZipcode = this.shipperZipcode[0];
          })
      this.selectLocation.push(event);
    // }
    // if (event.value.value === '2') {
    //   this.selectAccountNo = [];
    //   this.shipperAccountNo = [{ name: 'All' }];
    //   this.selectedAccountNo = this.shipperAccountNo[0];
    //   this.orgService.getHistoryFilterNames(this.userId, event.value.value, this.userIdadmin).subscribe(
    //     (res: any) => {
    //       const data = res.data.map((data) => {
    //         return { name: data }
    //       })
    //       this.shipperAccountNo = data;
    //       this.shipperAccountNo.splice(0, 0, { name: 'All' });
    //       this.selectedAccountNo = this.shipperAccountNo[0];
    //     })
    //   this.selectAccountNo.push(event);
    // }
  }

  // saved date list
  saveDate(event: any) {
    const startDate = moment(event[0]).format('MM/DD/YYYY');
    let endDate: any = moment(event[1]).format('MM/DD/YYYY');
    if (event[1] === null) {
      endDate = moment(event[0]).format('MM/DD/YYYY');
    }
    if (event.length > 0) {
      this.filterDate = `${startDate} - ${endDate}`;
      this.startDate = moment(startDate).format('YYYY/MM/DD')
      this.endDate = moment(endDate).format('YYYY/MM/DD')
      this.paginationInfo = {
        page: 0,
        rows: 10,
        shipperName: this.paginationInfo.shipperName,
        startDate: this.startDate,
        endDate: this.endDate,
        accNumber: this.paginationInfo.accNumber,
        street: this.paginationInfo.street,
        state: this.paginationInfo.state,
        city: this.paginationInfo.city,
        postalCode: this.paginationInfo.postalCode
      }
      this.loadPage();
      this.showDateModal = false;
    }
  }

  // shippers list
  changeShipperName() {
    this.paginationInfo = {
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
      shipperName: this.selectedShipper.name === 'All' ? '' : this.selectedShipper.name,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.paginationInfo.accNumber,
    }
    this.loadPage();
  }
  // shipper location
  changeShipperStreet() {
    this.paginationInfo = {
      page: 0,
      rows: 10,
      shipperName: this.paginationInfo.shipperName,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.paginationInfo.accNumber,
      street: this.selectedStreet.name === 'All' ? '' : this.selectedStreet.name,
      state: this.paginationInfo.state,
      city: this.paginationInfo.city,
      postalCode: this.paginationInfo.postalCode
    }
    this.loadPage();
  }
  changeShipperCity() {
    this.paginationInfo = {
      page: 0,
      rows: 10,
      shipperName: this.paginationInfo.shipperName,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.paginationInfo.accNumber,
      city: this.selectedCity.name === 'All' ? '' : this.selectedCity.name,
      street: this.paginationInfo.street,
      state: this.paginationInfo.state,
      postalCode: this.paginationInfo.postalCode
    }
    this.loadPage();
  }
  changeShipperState() {
    this.paginationInfo = {
      page: 0,
      rows: 10,
      shipperName: this.paginationInfo.shipperName,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.paginationInfo.accNumber,
      state: this.selectedState.name === 'All' ? '' : this.selectedState.name,
      street: this.paginationInfo.street,
      city: this.paginationInfo.city,
      postalCode: this.paginationInfo.postalCode
    }
    this.loadPage();
  }
  changeShipperZipcode() {
    this.paginationInfo = {
      page: 0,
      rows: 10,
      shipperName: this.paginationInfo.shipperName,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.paginationInfo.accNumber,
      postalCode: this.selectedZipcode.name === 'All' ? '' : this.selectedZipcode.name,
      street: this.paginationInfo.street,
      city: this.paginationInfo.city,
      state: this.paginationInfo.state,
    }
    this.loadPage();
  }
  // shipper accountNo
  changeShipperaccountNo() {
    this.paginationInfo = {
      page: this.paginationInfo.page,
      rows: this.paginationInfo.rows,
      shipperName: this.paginationInfo.shipperName,
      startDate: this.paginationInfo.startDate,
      endDate: this.paginationInfo.endDate,
      accNumber: this.selectedAccountNo.name === 'All' ? '' : this.selectedAccountNo.name,
      address: this.paginationInfo.address
    }
    this.loadPage();
  }

  // removing filters from seleceted filters
  removeDate() {
    this.date = new Date();
    this.filterDate = '';
    this.selectFilter = [];
    this.startDate = '';
    this.endDate = '';
    this.paginationInfo.startDate = '';
    this.paginationInfo.endDate = '';
    this.loadPage();
    this.historyForm.reset();
    this.showDateModal = false;
  }
  removeNames() {
    this.selectFilter = [];
    this.selectedShipper = [];
    this.selectedName = [];
    this.paginationInfo.shipperName = '';
    this.loadPage();
    this.historyForm.reset();
  }
  removeStreet() {
    // this.selectFilter = [];
    // this.selectLocation = [];
    // this.selectedLocation = [];
    this.selectedStreet = '';
    this.paginationInfo.street = '';
    this.loadPage();
    this.historyForm.reset();
  }
  removeCity() {
    this.selectedCity = '';
    this.paginationInfo.city = '';
    this.loadPage();
    this.historyForm.reset();
  }
  removeState() {
    this.selectedState = '';
    this.paginationInfo.state = '';
    this.loadPage();
    this.historyForm.reset();
  }
  removeZipcode() {
    this.selectedZipcode = '';
    this.paginationInfo.postalCode = '';
    this.loadPage();
    this.historyForm.reset();
  }
  removeShipperAccountNO() {
    this.selectFilter = [];
    this.selectAccountNo = [];
    this.selectedAccountNo = [];
    this.paginationInfo.accNumber = '';
    this.loadPage();
    this.historyForm.reset();
  }

  // actions For view and delete history
  actionFromTable(value): void {
    switch (value.type) {
      // case 'delete':
      //   this.deleteOrganization(value.data.id);
      //   return;
      case 'view':
        if (this.superAdmin) {
          this.router.navigate([`freightfacts/historyreport/${this.router.url.split('/')[3]}`]);
          localStorage.setItem('reportId', value.data.id);
          return;
        }
        localStorage.setItem('reportId', value.data.id);
        this.router.navigate(['freightfacts/historyreport']);
        return;
      case 'pagination':
        this.paginationInfo.page = value.data.page;
        this.paginationInfo.rows = value.data.rows;
        this.loadPage();
        return;
    }
  }

  getAccess() {
    const {
      AppRole: appRoleName,
      orgnizations: {
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    switch (appRoleName) {
      case 'Admin':
      if (!organizationRoleName) {
        // this.historyFilter = [{ name: 'Date range', value: '' }]
        this.superAdmin = true;
        this.userIdadmin = this.router.url.split('/')[3];
      }
      if (organizationRoleName === 'Admin') {
        switch (organizationTypeName) {
          case 'Carrier':
            this.ShipperApiAccess = false;
            return;
        }
        return;
      }
      return;
      case 'User':
        switch (organizationTypeName) {
          case 'Carrier':
            this.ShipperApiAccess = false;
            return;
        }
        return;
    }
  }

  navigateToBack() {
    this.location.back();
    this.paginationInfo = {
      page: 0,
      rows: 5,
    };
    localStorage.setItem('page', JSON.stringify(this.paginationInfo));
  }

  async ngOnInit() {
    // const pageNations =
    //   JSON.parse(localStorage.getItem('page')) || this.paginationInfo;
    // this.paginationInfo = pageNations;
    this.authService.getUserProfile().subscribe((res: any) => {
      this.userId = res.data.id;
      this.filterType();
    })
    this.getAccess();
    this.userName = localStorage.getItem('checkhistoryName');
    await this.loadPage();
  }
}
