import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-organization-type-screen',
  templateUrl: './organization-type-screen.component.html',
  styleUrls: ['./organization-type-screen.component.scss'],
})
export class OrganizationTypeScreenComponent {
  activeIndex;
  role: string;
  showCarrierTab: boolean;
  showShipperTab: boolean;
  showBackBtn: boolean;
  showUserRecords: boolean;
  id: number;
  orgName: any = '';
  constructor(private location: Location, private router: Router, private route: ActivatedRoute) {}

  ngOnInit() {
    const orgPage = this.router.url.split('/')[2];
    if (orgPage === 'organizations-reports') {
      this.showUserRecords = true;
    }
    
    const urlt = window.location.href;
    const url_parts = urlt.split('/');
    const details_index = url_parts.indexOf('details');
    this.role = url_parts[details_index + 1];
    this.orgName = localStorage.getItem('orgName');
    const {
      AppRole: appRoleName,
      orgnizations: {
        id: organizationId,
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    // switch (organizationTypeName) {
    //   case 'Carrier':
    //     switch (organizationRoleName) {
    //       case 'Admin':
    //         this.showBackBtn = false;
    //         return;
    //       case 'User':
    //         this.showBackBtn = false;
    //         return;
    //       default:
    //         this.showBackBtn = false;
    //         break;
    //     }
    //     return;
    //     default:
    //       this.showBackBtn = false;
    //       break;
    // }
    switch (appRoleName) {
      case 'Admin':
        this.orgName = localStorage.getItem('orgName');
        this.showBackBtn = true;
        switch (organizationTypeName) {
          case 'Carrier':
            this.showBackBtn = false;
            return;
          case 'Shipper':
            this.showBackBtn = false;
            return;
          case '3PL':
            this.showBackBtn = false;
            return;
        }
        return;
        case 'User':
          switch (organizationRoleName) {
            case 'Admin':
              switch (organizationTypeName) {
                case 'Carrier':
                this.orgName = localStorage.getItem('orgNames');
                return;
              case 'Shipper':
                this.orgName = localStorage.getItem('orgNames');
                return;
              case '3PL':
                this.orgName = localStorage.getItem('orgNames');
                return;
              }
              return;
          }
          return;
    }
    switch (this.role) {
      case 'Brokerage':
        this.showCarrierTab = true;
        this.showShipperTab = true;

        return;
      case 'Carrier':
        this.showShipperTab = true;
        this.showCarrierTab = false;
        return;
      case 'Shipper':
        this.showCarrierTab = true;
        this.showShipperTab = false;
        return;

      default:
        return;
    }
  }

  changeTab(event) {
    this.activeIndex = event.index;
    // const tabHeaderName = event.originalEvent.target.innerText;
  }

  navigateToOrganization() {
    this.location.back();
  }
}
