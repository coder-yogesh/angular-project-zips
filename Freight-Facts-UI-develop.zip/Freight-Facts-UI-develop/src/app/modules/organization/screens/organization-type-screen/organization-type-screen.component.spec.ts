import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganizationTypeScreenComponent } from './organization-type-screen.component';

describe('OrganizationTypeScreenComponent', () => {
  let component: OrganizationTypeScreenComponent;
  let fixture: ComponentFixture<OrganizationTypeScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrganizationTypeScreenComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrganizationTypeScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
