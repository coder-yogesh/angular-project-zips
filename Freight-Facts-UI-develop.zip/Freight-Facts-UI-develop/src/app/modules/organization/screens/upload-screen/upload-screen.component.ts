import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { OrganizationService } from '../../services/organization.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-upload-screen',
  templateUrl: './upload-screen.component.html',
  styleUrls: ['./upload-screen.component.scss']
})
export class UploadScreenComponent {
  loader = false;
  selectedIndex:any = {
    index: 0,
  };
  loadingfile = 0;
  labelName = "Account Level Template";
  urllink = "";

  constructor (
    private orgService: OrganizationService,
    private toaster: ToastrService,
  ) {}
  selectedFile: any;

  onChange($event) {
    this.selectedIndex = $event;
    console.log(this.selectedIndex, "indexvalue")
    if(this.selectedIndex.index == 0){
      this.labelName="Account Level Template"
    }
    else{
      this.labelName="Shipment Level Template"
    }
  }
  
  // loadingPage(val: any) {
  //   const timer = setInterval(() => {
  //     if (this.loadingfile < 100) {
  //       this.loadingfile = this.loadingfile + 1;
  //       document.getElementById(`progress-spinner${val}`).style.background = "conic-gradient(rgb(3, 133, 255) " +
  //       this.loadingfile +
  //       "%,rgb(242, 242, 242) " +
  //       this.loadingfile +
  //       "%)";
  //     }
  //     if (this.loadingfile >= 100) {
  //       this.loader = false;
  //       clearInterval(timer);
  //     }
  //   }, 100);
  // }
  selectFile() {
   if (!this.selectedFile) {
      // eslint-disable-next-line no-var
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = '.xlsx';
      input.onchange = () => {
        this.loader = true;
        const files = Array.from(input.files);
        for (const file of files) {
          this.selectedFile = file;
          const formData = new FormData();
          formData.append('file', this.selectedFile);
          formData.append('numberOfSheet', '1');
          console.log(formData, "formdata")
          this.selectedFile = '';
          // this.loadingPage('2');
          this.orgService.uploadExcel(formData).subscribe(
            (res: any) => {
              if (res.body.success) {
                this.loader = false;
                this.toaster.success(`${res.body.message}`, '');
              } else {
                this.loader = false;
                this.toaster.error(`${res.body.message}`, '');
              }
            },
            () => {
              this.loader = false;
            }
          )
         
          // // if (this.selecteFile) {
          // //   URL.revokeObjectURL(this.selecteFile); 
          // // }
          // this.imgURL = URL.createObjectURL(this.selecteFile);
          // this.openImage = true;
        }
      }
    }
    input.click();
  }
  accountLevelSelectFile(){
    if (!this.selectedFile) {
      // eslint-disable-next-line no-var
      var input = document.createElement('input');
      input.type = 'file';
      input.accept = '.xlsx, .csv';
      input.onchange = () => {
        this.loader = true;
        const files = Array.from(input.files);
        for (const file of files) {
          this.selectedFile = file;
          const formData = new FormData();
          formData.append('file', this.selectedFile);
          formData.append('numberOfSheet', '1');
          console.log(formData, "formdata")
          this.selectedFile = '';
          // this.loadingPage('1');
          this.orgService.uploadAccountLevelExcel(formData).subscribe(
            (res: any) => {
              if (res.body.success) {
                this.loader = false;
                this.toaster.success(`${res.body.message}`, '');
              } else {
                this.loader = false;
                this.toaster.error(`${res.body.message}`, '');
              }
            },
            () => {
              this.loader = false;
            }
          )
          // // if (this.selecteFile) {
          // //   URL.revokeObjectURL(this.selecteFile); 
          // // }
          // this.imgURL = URL.createObjectURL(this.selecteFile);
          // this.openImage = true;
        }
      }
    }
    input.click();

  }
  uploadFile() {
    let url = '';
    url = '../../../../../assets/ShipmentLevelLatest.xlsx';
    let accountlevelurl = '';
    accountlevelurl = '../../../../../assets/Accountlevelsampletemplate-withdata.xlsx';
    const samplelink = document.createElement('a');
    const linkname = `${this.labelName}.xlsx`;
    samplelink.setAttribute('href', this.selectedIndex.index === 0 ? accountlevelurl : url);
    samplelink.setAttribute('download', linkname);
    samplelink.click();
  }
  formatCell(key: any) {
    throw new Error('Method not implemented.');
  }
}
