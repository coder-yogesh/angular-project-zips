import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrganizationRoutingModule } from './organization-routing.module';
import { OrganizationDashboardComponent } from './screens/organization-dashboard/organization-dashboard.component';
import { OrganizationsComponent } from './components/organizations/organizations.component';
// import { ScoreDashboardComponent } from './components/score-dashboard/score-dashboard.component';
import { UsersComponent } from './components/users/users.component';
import { ShipperComponent } from './components/shipper/shipper.component';
import { CarrierComponent } from './components/carrier/carrier.component';
import { OrganizationTypeScreenComponent } from './screens/organization-type-screen/organization-type-screen.component';
import { AppLevelUsersComponent } from './components/app-level-users/app-level-users.component';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from 'src/app/shared/shared.module';
import { ScoreDashboardComponent } from './components/score-dashboard/score-dashboard.component';
import { UserlistComponent } from './components/userlist/userlist.component';
import { HistoryListComponent } from './components/history-list/history-list.component';
import { DashboardComponent } from './screens/dashboard/dashboard.component';
import { UploadScreenComponent } from './screens/upload-screen/upload-screen.component';
import { SuperAdminDashboardComponent } from './components/SuperAdmin/super-admin-dashboard/super-admin-dashboard.component';
import { OrganizationReportsComponent } from './components/SuperAdmin/organization-reports/organization-reports.component';
import { UserReportsComponent } from './components/SuperAdmin/user-reports/user-reports.component';
import { SlabRulesComponent } from './components/SuperAdmin/slab-rules/slab-rules.component';
import { SlabTableComponent } from './components/SuperAdmin/slab-table/slab-table.component';
import { HomescreenComponent } from './components/homescreen/homescreen.component';
import { CarrierReportsComponent } from './components/SuperAdmin/carrier-reports/carrier-reports.component';
import { ShipperReportsComponent } from './components/SuperAdmin/shipper-reports/shipper-reports.component';
import { ThreeplReportsComponent } from './components/SuperAdmin/threepl-reports/threepl-reports.component';


@NgModule({
  declarations: [
    OrganizationDashboardComponent,
    OrganizationsComponent,
    UsersComponent,
    ShipperComponent,
    CarrierComponent,
    OrganizationTypeScreenComponent,
    AppLevelUsersComponent,
    ScoreDashboardComponent,
    UserlistComponent,
    HistoryListComponent,
    DashboardComponent,
    UploadScreenComponent,
    SuperAdminDashboardComponent,
    OrganizationReportsComponent,
    UserReportsComponent,
    SlabRulesComponent,
    SlabTableComponent,
    HomescreenComponent,
    CarrierReportsComponent,
    ShipperReportsComponent,
    ThreeplReportsComponent,
  ],
  imports: [
    CommonModule,
    OrganizationRoutingModule,
    HttpClientModule,

    SharedModule,
  ],
  exports: [
    OrganizationsComponent,
    UsersComponent,
    ShipperComponent,
    CarrierComponent,
    OrganizationTypeScreenComponent,
    AppLevelUsersComponent,
    ScoreDashboardComponent,
    DashboardComponent,
    HomescreenComponent,

  ],
})
export class OrganizationModule {}
