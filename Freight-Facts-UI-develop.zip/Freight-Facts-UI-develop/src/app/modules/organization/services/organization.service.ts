import { HttpClient, HttpParams } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import {
  RoleDataResponse,
  userResponse,
} from '../interfaces/orgnization-models';

@Injectable({
  providedIn: 'root',
})
export class OrganizationService {
  private baseurl: string = environment.API_URL;
  errorLoader = new EventEmitter<boolean>()
  // private baseurl: string = environment.ORG_API_URL;

  constructor(private http: HttpClient) {}

  //superadmin dashboard
  superAdminDashboard(){
    return this.http.get(this.baseurl + 'organizations/admin/users');
  }

  // total reports list with report count

  totalReports(pageNation, search) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/totalReports`, {
      params: params,
    });
  }

  organizationReports(pageNation, search, id) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/organisation/${id}`, {
      params: params,
    });
  }

  carrierReports(pageNation, search) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/totalCarrierUsers`, {
      params: params,
    });
  }

  carrierUserReports(pageNation, search, id) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/carrierOrg/${id}`, {
      params: params,
    });
  }

  shipperReports(pageNation, search) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/totalShipperUsers`, {
      params: params,
    });
  }

  shipperUserReports(pageNation, search, id) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/shipperOrg/${id}`, {
      params: params,
    });
  }

  threeplReports(pageNation, search) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/total3PLUsers`, {
      params: params,
    });
  }

  threeplUserReports(pageNation, search, id) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/admin/3plOrg/${id}`, {
      params: params,
    });
  }

  // dashboard styles
  setPropertyValuesToCSSVariables(cssClassName, valueAssigned) {
    document.documentElement.style.setProperty(cssClassName, valueAssigned);
  }

  //organization

  //get all organization

  getAllOrganization(pageNation, search) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('search', search);
    return this.http.get(this.baseurl + `organizations/all`, {
      params: params,
    });
  }


  //createOrganizationWith defaultUser
  createOrganizationWithDefaultUser(data) {
    return this.http.post(this.baseurl + 'organizations/users', data);
  }
  //get all organization types
  getAllOrganizationTypes() {
    return this.http.get(this.baseurl + 'organization-types/all');
  }

  //create and update  organization
  updateOrganization(data) {
    return this.http.post(this.baseurl + 'organizations', data);
  }

  //delete organization
  deleteOrganization(id) {
    return this.http.delete(this.baseurl + `organizations/${id}`);
  }

  // get all organization assosiation based on parent organization id and organization type

  getAssociatedOrganizationList(orgData) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', orgData.page)
      .append('pageSize', orgData.rows);
    return this.http.get(
      this.baseurl +
        `organizations/${orgData.parentOrgId}/associations/${orgData.type}`,
      { params: params }
    );
  }
  // get  search organization assosiation based on parent organization id and organization type

  getAssociatedOrganizationSearchList(orgData) {
    let params = new HttpParams();
    params = params
      .append('pageNumber', orgData.page)
      .append('pageSize', orgData.rows)
      .append('search', orgData.search);
    return this.http.get(
      this.baseurl +
        `organizations/${orgData.parentOrgId}/associations/${orgData.type}`,
      { params: params }
    );
  }

  //create or update organization association

  createAssociation(parentOrgId, data) {
    return this.http.post(
      this.baseurl + `organizations/${parentOrgId}/associations`,
      data
    );
  }

  //delete organization association
  deleteAssociation(parentOrgId, associatedOrgId) {
    return this.http.delete(
      this.baseurl +
        `organizations/${parentOrgId}/associations/${associatedOrgId}`
    );
  }

  // USERS

  // create org level user
  createUser(orgId, data): Observable<any> {
    return this.http.post(
      this.baseurl + `organizations/${orgId}/members`,
      data
    );
  }

  //get users list

  getuserList(data): Observable<any> {
    let params = new HttpParams();
    params = params
      .append('pageNumber', data.pageNumber)
      .append('pageSize', data.pageSize)
      .append('search', data.search);
    return this.http.get(
      this.baseurl + `organizations/${data.id}/members/all`,
      { params: params }
    );
  }
  //update user

  updateUser(orgId, data): Observable<any> {
    return this.http.post(
      this.baseurl + `organizations/${orgId}/members`,
      data
    );
  }
  //delete user
  deleteUser(orgId, id): Observable<any> {
    return this.http.delete(
      this.baseurl + `organizations/${orgId}/members/${id}`
    );
  }
  // create app level user
  createAppLevelUser(data): Observable<any> {
    return this.http.post(this.baseurl + `users`, data);
  }

  // get app level user
  getAppLevelUser(data): Observable<userResponse> {
    let params = new HttpParams();
    params = params
      .append('pageNumber', data.pageNumber)
      .append('pageSize', data.pageSize)
      .append('search', data.search);
    return this.http.get<userResponse>(this.baseurl + `users/all`, {
      params: params,
    });
  }

  //update app level user

  updateAppLevelUser(data): Observable<any> {
    return this.http.post(this.baseurl + `users`, data);
  }
  //delete app level user
  deleteAppLevelUser(id): Observable<any> {
    return this.http.delete(this.baseurl + `users/${id}`);
  }
  //  get app levl user roles

  getAppLevelUserRoles(): Observable<RoleDataResponse> {
    return this.http.get<RoleDataResponse>(
      this.baseurl + 'role/application/roles'
    );
  }
  //  get user roles

  getUserRoles() {
    return this.http.get(this.baseurl + 'role/organization/roles');
  }

  //get all orgs without pagination

  getAllOrganizations() {
    return this.http.get(this.baseurl + 'organizations');
  }

  // search results of compare scoring
  getSearchResults(data: any) {
    return this.http.post(this.baseurl + 'score/getSearchResults', data);
  }
    // search results of compare scoring
  getShipper3PLScore(data: any) {
      return this.http.post(this.baseurl + 'score/getShipper3PLScore', data);
    }
  // genreate carrierview score
  scoreGenrate(payload: any) {
    return this.http.post(this.baseurl + 'score/getCarrierScore', payload);
  }

  // genreate marketview score
    marketviewscoreGenrate(payload: any) {
      return this.http.post(this.baseurl + 'score/getMarketScore', payload);
    }
  // get level names
  getFactorNames() {
    return this.http.get(this.baseurl + 'score/getDefaultScore');
  }
  // upload excel file
  uploadExcel(data: any) {
    return this.http.post(this.baseurl + 'carrier/saveCarrierDataFromExcel', data);
  }
  uploadAccountLevelExcel(data: any) {
    return this.http.post(this.baseurl + 'carrier/saveCarrierAccountDataFromExcel', data);
  }
  // get history list
  getHistoryList(pageNation: any, Access: any, superAdmin: any, id: any) {
    // const api = shipperAccess ? 'new' : 'history';
    let params = new HttpParams();
    params = params
      .append('pageNumber', pageNation.page)
      .append('pageSize', pageNation.rows)
      .append('startDate', pageNation.startDate)
      .append('endDate', pageNation.endDate)
      .append('shipperName', pageNation.shipperName)
      .append('accNumber', pageNation.accNumber)
      .append('street', pageNation.street)
      .append('city', pageNation.city)
      .append('state', pageNation.state)
      .append('postalCode', pageNation.postalCode)
    if (superAdmin) {
      return this.http.get(this.baseurl + `admin/history/report/user/${id}`, {
        params: params,
      });
    }
    if (Access) {
      return this.http.get(this.baseurl + 'history/3pl/shipper', {
        params: params,
      });
    } else {
      return this.http.get(this.baseurl + 'history', {
        params: params,
      });
    }
  }
  // getShipperHistoryList(pageNation) {
  //   // const api = shipperAccess ? 'new' : 'history';
  //   let params = new HttpParams();
  //   params = params
  //     .append('pageNumber', pageNation.page)
  //     .append('pageSize', pageNation.rows)
  //     .append('startDate', pageNation.startDate)
  //     .append('endDate', pageNation.endDate)
  //     .append('shipperName', pageNation.shipperName)
  //     .append('accNumber', pageNation.accNumber)
  //     .append('address', pageNation.address)
  //   return this.http.get(this.baseurl + 'history/3pl/shipper', {
  //     params: params,
  //   });
  // }
  getHistoryFilterNames(userId: any, id: string, adminId: any, type: any) {
    let params = new HttpParams();
    params = params.append('schemaUser', Number(adminId));
    params = params.append('addressType', type);
    return this.http.get(this.baseurl + `history/user/${userId}/type/${id}`, {
      params
    });
  }
  getHistoryReport(id: string, Access: any, superAdmin: any, userId: any) {
    if (superAdmin) {
      return this.http.get(this.baseurl + `admin/history/user/${userId}/report/${id}`);
    }
    if (Access) {
      return this.http.get(this.baseurl + `historyShipper3PL/report/${id}`);
    }
    return this.http.get(this.baseurl + `history/report/${id}`);
  }
  // getshipper3plHistoryReport(id: string) {
  //   return this.http.get(this.baseurl + `historyShipper3PL/report/${id}`);
  // }

  // slab rules freight facts list
  getSlabRules() {
    return this.http.get(this.baseurl + 'freightFacts');
  }

  getOrganizationNames() {
    return this.http.get(this.baseurl + 'organizations/all/list');
  }

  // get slab rules data for edit
  getSlabData(id: number, type: any, access: any, superAdmin: boolean, organization: any) {
    let params = new HttpParams();
    params = params.append('weightType', type);
    if (superAdmin) {
      params = params.append('schemaName', organization.name);
      return this.http.get(this.baseurl + `freightFact/slabs/${id}`, {
        params,
      });
    }
    if (access) {
      return this.http.get(this.baseurl + `freightFact/slabs/${id}`, {
        params,
      }); 
    }
    return this.http.get(this.baseurl + `freightFact/slabs/${id}`);
  }
  // create slab rule
  createSlabRule(payload: any) {
    return this.http.post(this.baseurl + 'freightFact/slab', payload);
  }
  // delete slab rule
  deleteSlabRule(id: number) {
    return this.http.delete(this.baseurl + `freightFact/slab/${id}`);
  }
}
