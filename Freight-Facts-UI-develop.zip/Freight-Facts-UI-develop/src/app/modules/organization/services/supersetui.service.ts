import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
/** rxjs Imports */
import { Observable, throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
/** EmbedDashboard SDK import */
import { embedDashboard } from '@superset-ui/embedded-sdk';
import { environment } from 'src/environments/environment';
import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { hideSpinner, showSpinner } from 'src/app/store/actions/spinner.actions';

@Injectable({
  providedIn: 'root'
})
export class SupersetuiService {
  orgName: any = '';
  carrierName:any = '';
  private apiUrl = 'https://analytics.logisticsstudio.com/api/v1/security';
  private baseUrl: string = environment.API_URL;
  constructor(
    private http: HttpClient,
    private store: Store<{ spinner: SpinnerState }>
  ) {}
  private fetchAccessToken(): Observable<any> {
    const body = {
      username: 'User',
      password: 'pass',
      provider: 'db',
      refresh: true,
    };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<any>(`${this.apiUrl}/login`, body, { headers });
  }
  /**
   *
   * @returns { guest token } using @param { accessToken }
   */
  private fetchGuestToken(accessToken: any): Observable<any> {
    this.orgName = localStorage.getItem('orgNames');
    // this.carrierName = localStorage.getItem('carrierName'); 
    // console.log("orgname", this.orgName)
    // console.log("carrierName", this.carrierName)
    const insightsType = this.orgName?.toLowerCase();
    // console.log(insightsType, "insightstype")
    const body = {
      resources: [
        {
          type: 'dashboard',
          id: '4727dcac-5f71-4d04-96a0-4a2cad8ff320',
        },
      ],
      /**
       * rls: Row Level Security, this differs for client to client ,like what to show each client
       */
       rls: [{ "clause": `carrier_name = '${insightsType}'` }],

      
      user: {
        username: 'User',
        first_name: 'Guest',
        last_name: 'User',
      },
    };
    console.log(body, "body")
    const acc = accessToken['access_token']; //accessToken is an object in which there are two tokens access_token and refresh_token ,out of which we just need to send access_token to get guest_token
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${acc}`,
    });
    //guest_token URL should end with forward_slash(/)
    return this.http.post<any>(`${this.apiUrl}/guest_token/`, body, {
      headers,
    });
  }
  /**
   *
   * @returns { guest Token }
   */
  getGuestToken(): Observable<any> {
    return this.fetchAccessToken().pipe(
      catchError((error) => {
        console.error(error);
        return throwError(error);
      }),
      switchMap((accessToken: any) => this.fetchGuestToken(accessToken))
    );
  }
  /**
   *
   * @returns { dashboard }
   */
  embedDashboard(): Observable<void> {
    return new Observable((observer) => {
      this.store.dispatch(showSpinner());
      this.getGuestToken().subscribe(
        (token) => {
          embedDashboard({
            id: '4727dcac-5f71-4d04-96a0-4a2cad8ff320', // Replace with your dashboard ID
            supersetDomain: 'https://analytics.logisticsstudio.com/',
            mountPoint: document.getElementById('dashboard'),
            fetchGuestToken: () => token['token'],
            dashboardUiConfig: {
              hideTitle: true,
              hideChartControls: false,
              hideTab: true,
            },
          });
          observer.next();
          observer.complete();
          this.store.dispatch(hideSpinner())
        },
        (error) => {
          observer.error(error);
          this.store.dispatch(hideSpinner())
        }
      );
    });
  }
}
