import { TestBed } from '@angular/core/testing';

import { SupersetuiService } from './supersetui.service';

describe('SupersetuiService', () => {
  let service: SupersetuiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SupersetuiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
