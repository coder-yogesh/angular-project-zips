import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UnauthorizedPageComponent } from 'src/app/shared/components/unauthorized-page/unauthorized-page.component';
import { OrganizationTypeScreenComponent } from './screens/organization-type-screen/organization-type-screen.component';
import { AuthGuard } from '../auth/services/auth.guard';
import { Roles } from 'src/app/core/common/role';
import { ProfileSettingsComponent } from 'src/app/shared/components/profile-settings/profile-settings.component';
import { CarrierComponent } from './components/carrier/carrier.component';
import { ShipperComponent } from './components/shipper/shipper.component';
import { HistoryListComponent } from './components/history-list/history-list.component';
import { UserlistComponent } from './components/userlist/userlist.component';
import { ScoreDashboardComponent } from './components/score-dashboard/score-dashboard.component';
import { OrganizationsComponent } from './components/organizations/organizations.component';
import { DashboardComponent } from './screens/dashboard/dashboard.component';
import { UploadScreenComponent } from './screens/upload-screen/upload-screen.component';
import { ReportComponent } from 'src/app/shared/components/report/report.component';
import { OrganizationReportsComponent } from './components/SuperAdmin/organization-reports/organization-reports.component';
import { SupersetuiComponent } from 'src/app/shared/components/supersetui/supersetui.component';
import { SlabRulesComponent } from './components/SuperAdmin/slab-rules/slab-rules.component';
import { CarrierReportsComponent } from './components/SuperAdmin/carrier-reports/carrier-reports.component';
import { ShipperReportsComponent } from './components/SuperAdmin/shipper-reports/shipper-reports.component';
import { ThreeplReportsComponent } from './components/SuperAdmin/threepl-reports/threepl-reports.component';
import { UserReportsComponent } from './components/SuperAdmin/user-reports/user-reports.component';

// const AllRoles = [
//   Roles.Admin,
//   Roles.Member,
//   Roles.OrgAdmin,
//   Roles.OrgMember,
//   Roles.Broker,
//   Roles.Shipper,
//   Roles.Carrier,
//   Roles.PriceAdmin,
//   Roles.User,
// ];

// const groupRoles = [
//   Roles.Admin,
//   Roles.Member,
//   Roles.OrgAdmin,
//   Roles.OrgMember,
//   Roles.Broker,
//   Roles.Shipper,
//   Roles.Carrier,
//   Roles.PriceAdmin,
//   Roles.User,
// ];
// const routes: Routes = [
//   { path: '', redirectTo: 'unauthorized', pathMatch: 'full' },
//   { path: 'unauthorized', component: UnauthorizedPageComponent },
// ];
const AllRoles = [
  Roles.Admin,
  Roles.Member,
  Roles.OrgAdmin,
  Roles.OrgMember,
  Roles.Broker,
  Roles.Shipper,
  Roles.Carrier,
  Roles.PriceAdmin,
  Roles.User,
];

const groupRoles = [
  Roles.Admin,
  Roles.Member,
  Roles.OrgAdmin,
  Roles.OrgMember,
  Roles.Broker,
  Roles.Shipper,
  Roles.Carrier,
  Roles.PriceAdmin,
  Roles.User,
];

// const spotroutes: Routes = [
//   {
//     path: '',
//     redirectTo: 'base-rate-rules',
//     pathMatch: 'full',
//   },
//   {
//     path: 'base-rate-rules',
//     component: BaseRateScreenComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },

//   {
//     path: 'base-rate-rules/:id',
//     component: BaseRateScreenComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
//   {
//     path: 'primary-config/:id',
//     component: PrimaryConfigScreenComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
//   {
//     path: 'configure-adjustments',
//     component: ConfigureAdjustmentsScreenComponent,
//     children: [
//       {
//         path: '',
//         redirectTo: 'day-of-the-week/:id',
//         pathMatch: 'full',
//       },
//       {
//         path: 'day-of-the-week/:id',
//         component: DayOfTheWeekComponent,
//       },
//       {
//         path: 'date/:id',
//         component: DateComponent,
//       },
//       {
//         path: 'same-day-pickup/:id',
//         component: SameDayPickupComponent,
//       },
//       {
//         path: 'accessorial/:id',
//         component: AccessorialTabComponent,
//       },
//     ],
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
//   {
//     path: 'final-constraint/:id',
//     component: FinalConstraintScreenComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
//   {
//     path: 'shipper-sell-price/:id',
//     component: ShipperSellPriceScreenComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
// ];
// const contractroutes: Routes = [
//   {
//     path: '',
//     redirectTo: 'base-rate-rules',
//     pathMatch: 'full',
//   },

//   {
//     path: 'base-rate-rules',
//     component: BaseScreenContractComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
//   {
//     path: 'base-rate-rules/:id',
//     component: BaseScreenContractComponent,
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
//   {
//     path: 'configure-adjustments',
//     component: ConfigureAdjustmentsScreenComponent,
//     children: [
//       {
//         path: '',
//         redirectTo: 'day-of-the-week/:id',
//         pathMatch: 'full',
//       },
//       {
//         path: 'day-of-the-week/:id',
//         component: DayOfTheWeekComponent,
//       },
//       {
//         path: 'date/:id',
//         component: DateComponent,
//       },
//       {
//         path: 'same-day-pickup/:id',
//         component: SameDayPickupComponent,
//       },
//       {
//         path: 'accessorial/:id',
//         component: AccessorialTabComponent,
//       },
//     ],
//     canActivate: [AuthGuard],
//     data: { roles: AllRoles },
//   },
// ];

const routes: Routes = [
  { path: '', redirectTo: 'unauthorized', pathMatch: 'full' },
  { path: 'unauthorized', component: UnauthorizedPageComponent },
  {
    path: '',
    component: DashboardComponent,
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      // {
      //   path: 'rate-lookup',
      //   component: RateLookupScreenComponent,
      //   canActivate: [AuthGuard],
      //   data: { roles: AllRoles },
      // },

      // {
      //   path: 'insights',
      //   component: RateInsightsComponent,
      //   canActivate: [AuthGuard],
      //   data: { roles: AllRoles },
      // },
      // {
      //   path: 'accessorial',
      //   component: AccessorialScreenComponent,
      //   canActivate: [AuthGuard],
      //   data: { roles: AllRoles },
      // },
      // {
      //   path: 'rule-set',
      //   // component:RuleSetScreenComponent
      //   children: [
      //     {
      //       path: '',
      //       redirectTo: 'list',
      //       pathMatch: 'full',
      //     },
      //     {
      //       path: 'list',
      //       component: RuleSetScreenComponent,
      //       canActivate: [AuthGuard],
      //       data: { roles: groupRoles },
      //     },
      //     {
      //       path: 'create-spot',
      //       component: RuleSetCreateScreenComponent,
      //       children: spotroutes,
      //     },
      //     {
      //       path: 'update-spot',
      //       component: RuleSetCreateScreenComponent,
      //       children: spotroutes,
      //     },
      //     {
      //       path: 'create-contract',
      //       component: RuleSetCreateScreenComponent,
      //       children: contractroutes,
      //     },
      //     {
      //       path: 'update-contract',
      //       component: RuleSetCreateScreenComponent,
      //       children: contractroutes,
      //     },
      //   ],
      // },

      {
        path: 'organizations',
        component: OrganizationsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin, Roles.Member] },
      },
      {
        path: 'organizations-reports',
        component: OrganizationReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'organizations-reports/details/:id2',
        component: UserReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'carrier-reports',
        component: CarrierReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'carrier-reports/details/:id',
        component: UserReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'shipper-reports',
        component: ShipperReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'shipper-reports/details/:id',
        component: UserReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: '3pl-reports',
        component: ThreeplReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: '3pl-reports/details/:id',
        component: UserReportsComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'scoresettings',
        component: SlabRulesComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path:'insights',
        component:SupersetuiComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [
            Roles.Admin,
            Roles.OrgAdmin,
            Roles.Carrier,
            Roles.User,
          ],
        },
      },
      {
        path: 'dashboard',
        component: ScoreDashboardComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [
            Roles.Admin,
            Roles.OrgAdmin,
            Roles.Carrier,
            Roles.User,
          ],
        },
      },
      {
        path: 'users',
        component: UserlistComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin] },
      },
      {
        path: 'history',
        component: HistoryListComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin, Roles.User] },
      },
      {
        path: 'history/:id',
        component: HistoryListComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin, Roles.User] },
      },
      {
        path: 'dataupload',
        component: UploadScreenComponent,
        canActivate: [AuthGuard],
      },
      {
        path:'historyreport',
        component:ReportComponent,
        canActivate:[AuthGuard]
      },
      {
        path: 'historyreport/:userid',
        component: ReportComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'shipper',
        component: ShipperComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [
            Roles.Admin,
            Roles.OrgAdmin,
            Roles.Carrier,
            Roles.Broker,
            Roles.PriceAdmin,
            Roles.User,
          ],
        },
      },
      {
        path: 'carrier',
        component: CarrierComponent,
        canActivate: [AuthGuard],
        data: {
          roles: [
            Roles.Admin,
            Roles.OrgAdmin,
            Roles.Shipper,
            Roles.Broker,
            Roles.PriceAdmin,
            Roles.User,
          ],
        },
      },
      // {
      //   path: 'contract-lanes',
      //   component: ContractLanesListComponent,
      //   canActivate: [AuthGuard],
      //   data: {
      //     roles: [Roles.OrgAdmin, Roles.PriceAdmin, Roles.User, Roles.Admin],
      //   },
      // },
      // {
      //   path: 'lanes-list',
      //   component: LanesListComponent,
      //   canActivate: [AuthGuard],
      //   data: {
      //     roles: [Roles.OrgAdmin, Roles.PriceAdmin, Roles.User, Roles.Admin],
      //   },
      // },

      {
        path: 'organizations/details/:id/:id2',
        component: OrganizationTypeScreenComponent,
        canActivate: [AuthGuard],
        data: { roles: [Roles.Admin, Roles.Member] },
      },
      // {
      //   path: 'users',
      //   component: UsersComponent,
      //   canActivate: [AuthGuard],
      //   data: {
      //     roles: [
      //       Roles.Admin,
      //       Roles.OrgAdmin,
      //       Roles.Shipper,
      //       Roles.Broker,
      //       Roles.Carrier,
      //       Roles.PriceAdmin,
      //       Roles.User,
      //     ],
      //   },
      // },
      // {
      //   path: 'appusers',
      //   component: AppLevelUsersComponent,
      //   canActivate: [AuthGuard],
      //   data: {
      //     roles: [Roles.Admin, Roles.OrgAdmin, Roles.Member],
      //   },
      // },
      {
        path: 'settings',
        component: ProfileSettingsComponent,
        canActivate: [AuthGuard],
        data: { roles: AllRoles },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class OrganizationRoutingModule {}
