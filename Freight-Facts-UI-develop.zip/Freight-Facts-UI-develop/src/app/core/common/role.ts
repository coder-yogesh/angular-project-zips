export enum Roles {
  Admin = 'Admin',
  Member = 'Member',
  OrgAdmin = 'Owner',
  OrgMember = 'Member',
  PriceAdmin = 'Pricing Admin',
  Shipper = 'Shipper',
  Carrier = 'Carrier',
  Broker = 'Broker',
  User = 'User',
}
