export const regularExpressions = {
    emailExp:"^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$",
    oldemailExp:"^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$",
    passwordExp:/^(?=\S*[a-z])(?=\S*[A-Z])(?=\S*\d)(?=\S*[^\w\s])\S{8,}$/,
    phonenumberExp:/^(?:\+?(61))? ?(?:\((?=.*\)))?(0?[2-57-8])\)? ?(\d\d(?:[- ](?=\d{3})|(?!\d\d[- ]?\d[- ]))\d\d[- ]?\d[- ]?\d{3})$/,
    titleExp:/^(?=.*[a-zA-Z]).+$/,
              // '^(?=.*[a-zA-z]).+$'
    decimalValueExp: /^\d+(\.\d{0,2})?$/
  };