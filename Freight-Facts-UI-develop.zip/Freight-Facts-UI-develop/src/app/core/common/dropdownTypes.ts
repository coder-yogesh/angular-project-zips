export const globalEquipmentTypes = [
    [
      {
        label: 'Flatbed',
        disabled: false,
        id: 0,
      },
      {
        label: 'Reefer',
        disabled: false,
        id: 1,
      },
      {
        label: 'Van',
        disabled: false,
        id: 2,
      },
    ],
    [
      {
        label: 'Flatbed',
        disabled: false,
        id: 0,
      },
      {
        label: 'Reefer',
        disabled: false,
        id: 1,
      },
      {
        label: 'Van',
        disabled: false,
        id: 2,
      },
    ],
    [
      {
        label: 'Flatbed',
        disabled: false,
        id: 0,
      },
      {
        label: 'Reefer',
        disabled: false,
        id: 1,
      },
      {
        label: 'Van',
        disabled: false,
        id: 2,
      },
    ],
  ];

  export const staticEquipmentType=[
    {
      label: 'Flatbed',
      disabled: false,
      id: 0,
    },
    {
      label: 'Reefer',
      disabled: false,
      id: 1,
    },
    {
      label: 'Van',
      disabled: false,
      id: 2,
    },
  ]

  export const globalAdjustmentTypes = [
    {
      name: 'Flat Rate',
      id: 5,
    },
    {
      name: 'Percentage',
      id: 6,
    },
    {
      name: 'RPM',
      id: 7,
    },
  ];

 