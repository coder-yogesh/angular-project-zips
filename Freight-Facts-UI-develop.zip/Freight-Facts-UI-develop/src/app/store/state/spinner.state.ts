// spinner.state.ts

export interface SpinnerState {
  isLoading: boolean;
}

export const initialSpinnerState: SpinnerState = {
  isLoading: false,
};
