// spinner.reducer.ts

import { createReducer, on } from '@ngrx/store';
import { showSpinner, hideSpinner } from '../actions/spinner.actions';
import { initialSpinnerState } from '../state/spinner.state';

export const spinnerReducer = createReducer(
  initialSpinnerState,
  on(showSpinner, (state) => ({ ...state, isLoading: true })),
  on(hideSpinner, (state) => ({ ...state, isLoading: false }))
);
