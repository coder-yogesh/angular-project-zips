// spinner.actions.ts

import { createAction } from '@ngrx/store';

export const showSpinner = createAction('[Spinner] Show Spinner');
export const hideSpinner = createAction('[Spinner] Hide Spinner');
