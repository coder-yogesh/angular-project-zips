import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthComponent } from './modules/auth/components/auth/auth.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { UnauthorizedPageComponent } from './shared/components/unauthorized-page/unauthorized-page.component';
import { RateGuard } from './modules/auth/services/rate.guard';
import { AuthGuard } from './modules/auth/services/auth.guard';
import { SetPasswordComponent } from './modules/auth/components/set-password/set-password.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/signIn',
    pathMatch: 'full',
  },
  {
    path: '',
    component: AuthComponent,
    children: [
      {
        path: 'auth',
        canActivate: [RateGuard],
        loadChildren: () =>
          import('./modules/auth/auth.module').then((m) => m.AuthModule),
      },
      {
        path: 'freightfacts',
        canActivate: [AuthGuard],
        loadChildren: () =>
          import('./modules/organization/organization.module').then(
            (m) => m.OrganizationModule
          ),
      },
    ],
  },
  { path: 'auth/setPassword/:token', component: SetPasswordComponent },
  { path: 'unauthorized', component: UnauthorizedPageComponent },
  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
