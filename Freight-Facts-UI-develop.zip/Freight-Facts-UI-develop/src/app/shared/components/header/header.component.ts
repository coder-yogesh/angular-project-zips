import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import * as _ from 'lodash';
import { UserData } from 'src/app/core/models/user.model';
import { UserProfileInfoService } from '../../services/user-profile-info.service';
import { AuthService } from 'src/app/modules/auth/services/auth.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class HeaderComponent implements OnInit {
  @Input() imageUrl: string;
  @Input() label: string;

  user: UserData;
  name = 'User';
  token: string;
  userProfile: any = {
    imageUrl: '',
    name: '',
    label: 'vdv',
  };

  constructor(
    private router: Router,
    private userService :UserProfileInfoService,
    private authService: AuthService,
    private toaster: ToastrService,
    ) {}

  ngOnInit(): void {
    const helper = new JwtHelperService();
    const token = localStorage.getItem('token');
    this.token = token;
    const decoded = helper.decodeToken(token);
    if (token.length > 0) {
      this.getUserProfile();
    }
    const user = {
      id: decoded.id,
      name: decoded.name,
      email: decoded.email,
    };

    this.name = _.upperFirst(user.name);
  }
  openProfile() {
    this.router.navigate(['freightfacts/settings']);
  }
  logOut() {
    this.toaster.success('Logout successfully', '');
    localStorage.clear();
    this.router.navigateByUrl('/auth/signIn');
  }
  getUserProfile() {
    this.authService.getUserProfile().subscribe((user: any) => {      
      this.userProfile.name =
        user?.data?.firstName;
      this.userProfile.label =
        user?.data?.firstName?.charAt(0).toUpperCase() 
      this.userProfile.imageUrl = user?.data?.profilePicture
    });
  }
}
