export class AppDialogConfig<D = any> {
  data?: D;
}
