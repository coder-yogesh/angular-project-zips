import { AppDialogDirective } from './app-dialog.directive';

describe('AppDialogDirective', () => {
  it('should create an instance', () => {
    const directive = new AppDialogDirective();
    expect(directive).toBeTruthy();
  });
});
