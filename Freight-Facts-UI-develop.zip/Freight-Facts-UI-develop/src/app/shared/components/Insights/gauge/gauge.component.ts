import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild, ViewEncapsulation } from '@angular/core';
import { Gauge } from 'gaugeJS';

@Component({
  selector: 'app-gauge',
  templateUrl: './gauge.component.html',
  styleUrls: ['./gauge.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class GaugeComponent {
  @Input() title = '';
  @Input() mainClass = '';
  @Input() guage = '';
  @Input() value:number;
  // @Input() values:number;
  @Output() action = new EventEmitter<void>();
  async gaugeCont(val: any) {
    const opts = {
      angle: -0.38, // The span of the gauge arc
      lineWidth: 0.10, // The line thickness
      radiusScale: 1, // Relative radius
      pointer: {
        length: 0.35, // // Relative to gauge radius
        strokeWidth: 0.020, // The thickness
        color: '#000000' // Fill color
      },
      // renderTicks is Optional
      // renderTicks: {
      //   divisions: 0,
      //   divWidth: 0.1,
      //   divLength: 0.41,
      //   divColor: '#333333',
      //   subDivisions: 0,
      //   subLength: 0.14,
      //   subWidth: 3.1,
      //   subColor: '#ffffff'
      // },
      staticZones: [
       {strokeStyle: "rgba(255, 86, 86, 1)", min: 1, max: 180}, // Red from 70 to 80
       {strokeStyle: "rgba(255, 136, 136, 1)", min: 150, max: 360}, // Yellow 80 to 90
       {strokeStyle: "rgba(254, 225, 20, 1)", min: 360, max: 540}, // Green 90 to 100
       {strokeStyle: "rgba(209, 216, 15, 1)", min: 540, max: 720},
       {strokeStyle: "rgba(132, 189, 50, 1)", min: 720, max: 900},
      //  {strokeStyle: "rgba(48, 173, 67, 1)", min: 750, max: 900}
      ],
      staticLabels: {
        font: "16px sans-serif",  // Specifies font
        labels: [100, 450, 800],  // Print labels at these values
        color: "#000000",  // Optional: Label text color
        fractionDigits: 0  // Optional: Numerical precision. 0=round off.
      },
      limitMax: false,
      limitMin: false,
      colorStart: '#F0F0F0',
      colorStop: '#F0F0F0',
      strokeColor: '#E0E0E0',
      generateGradient: true,
      highDpiSupport: true,
    };
    const targe = document.getElementById(`${this.guage}`);
    const gague = new Gauge(targe).setOptions(opts);
    // gague.setProperty();
    targe.style.backgroundColor = 'transparent';
    gague.maxValue = 900;
    gague.setMinValue(1);
    gague.animationSpeed = 60;
    // gague.setTextField(document.getElementById(`${this.values}`));
    // const textdiv = document.getElementById(`${this.values}`);
    // // position: absolute;
    // //   left: 0;
    // //   right: 0;
    // //   bottom: 50px;
    // //   text-align: center;
    // // }
    // textdiv.style.position = 'absolute';
    // textdiv.style.left = '0';
    // textdiv.style.fontSize = '15px';
    // textdiv.style.right = '0';
    // textdiv.style.bottom = '0';
    // textdiv.style.textAlign = 'center';
    gague.set(val);
  }
  // eslint-disable-next-line @angular-eslint/use-lifecycle-interface
  async ngAfterViewInit() {
    await this.gaugeCont(this.value);
  }
}
