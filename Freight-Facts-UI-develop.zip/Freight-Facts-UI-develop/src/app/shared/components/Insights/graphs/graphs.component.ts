import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

interface Item {
  name: string,
  code: string
}
@Component({
  selector: 'app-graphs',
  templateUrl: './graphs.component.html',
  styleUrls: ['./graphs.component.scss']
})
export class GraphsComponent implements OnInit {
  @Input() points: any;
  @Output() action = new EventEmitter<void>();
  data: any;
  options: any;
  setOptions: any;
  Points: any;
  graphdatamain: any;
  timePeriodLabel:any;
  mode = [
    { name: 'Bar Graph', value: 'bar' },
    { name: 'line Graph', value: 'line' }
  ];
  modedays = [
    { name: 'Last 30Days', value: 'Last 30Days' },
    { name: 'Last 60Days', value: 'Last 60Days' },
  ];
  items: Item[];
  selectedItems: Item[];
  graphOption: FormGroup;
  constructor(private fb: FormBuilder) {
    this.graphOption = this.fb.group({
      graph: this.mode[0]
    })
  }
  async updateGraph(val: any) {
    this.Points = Object.values(val.shippersMetrics[0].metrics);
    const graphArr = [];
    const graphoption = this.Points.map((data: any, index: number) => {
      const colors = ['#3E7FD7', '#171D2C', '#EB147E', '#7841BE', '#D0A62F', '#0712F8', '#25B6DA', '#A08D5F', '#A2EB14', '#FADB05', '#DAFD02', '#867980', '#A08D5F','#0923F6',];
      const setData = {
        fill: true,
        label: data.name,
        backgroundColor: colors[index],
        borderColor: colors[index],
        data: data.points,
        extraInfo:data.values,
        tension: 0.4,
        borderRadius: 8,
      };
      // console.log(setData)
      graphArr.push({
        name: data.name,
      });
      return setData;
    });
    this.graphdatamain = graphoption;
    this.setOptions = graphoption.slice(0, 0);
    this.items = graphArr;
    this.selectedItems = this.items.slice(0, 0);
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const surfaceBorder = documentStyle.getPropertyValue('--surface-border');
    this.data = {
      labels: val.months,
      datasets: this.setOptions,
      timePeriodLabel:val.period,
    };
    this.timePeriodLabel = this.data.timePeriodLabel
    // console.log(this.data.timePeriodLabel, "timeperiod")
    this.options = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      
      plugins: {
        legend: {
          display: true,
          position: 'bottom'
        },
        tooltip: {
          callbacks: {
            label: (context) => {
              const label = context.dataset.label || '';
              if (context.parsed.y !== null) {
                const value = context.parsed.y;
                const extraInfo = this.data.datasets[context.datasetIndex].extraInfo;
                const labelValue = `${label}: ${value}%`;
                const actualValue = `Actual Value: ${extraInfo[context.dataIndex]}`;
                return [labelValue, actualValue];
              }
              return '';
            }
          }
          
        }
      },
      indexAxis: 'x',
      scales: {
        x: {
          scaleLabel: {
            display: true,
            labelString: 'Time Period'
            
          },
          ticks: {
            color: textColorSecondary,
            overflowX: 'scroll',
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false,
            overflowX: 'scroll',
          }
        },

        y: {
          min:0,
          max:100,
          beginAtZero: true,
          grace:10,
          title: {
            display: true,
            text: '% of Points Available',
            
        
        },
          ticks: {
            color: textColorSecondary,
            overflowX: 'scroll',
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false,
            overflowX: 'scroll',
          }
          
        }
      }
    };
  }
  ngOnInit(): void {
    this.updateGraph(this.points);

  }

  graphlabel(event){
    const graphlabelNames = event.value.map((e)=>{  
      return e.name
    })
    const graphData = this.graphdatamain.filter((a,index)=>{
      if(graphlabelNames.includes(a.label)
      ){
        return a
      }
    });
    this.setOptions = graphData;
    this.data = {
      ...this.data,
      datasets: this.setOptions,
    };
  }
}
