import { Component, Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  currentPasswordAndNewPasswordValidation,
  inputValidations,
  passwordAndConfirmPasswordValidation,
  passwordValidation,
} from 'src/app/core/common/utils';
import { ProfileService } from '../../services/profile.service';
import { ToastrService } from 'ngx-toastr';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { Store } from '@ngrx/store';
import {
  hideSpinner,
  showSpinner,
} from 'src/app/store/actions/spinner.actions';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent {
  @Input() userProfileData:any;
  changePasswordForm: FormGroup;
  userChangedData:any;
  constructor(private fb: FormBuilder,
    private service:ProfileService,
    private toasterService: ToastrService,
    private store: Store<{ spinner: SpinnerState }>
    ) {
    this.changePasswordForm = this.fb.group({
      currentPassword: ['', [Validators.required]],
      newPassword: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]],
    });
  }
  

  //  input required validation
  inputValidationsErrors = (changePasswordForm: FormGroup, type: string) => {
    return inputValidations(changePasswordForm, type);
  };

  // password and confirm password validation
  confirmPasswordValidation = (
    changePasswordForm: FormGroup,
    passwordFieldName: string,
    confirmPasswordFieldName: string
  ) => {
    return passwordAndConfirmPasswordValidation(
      changePasswordForm,
      passwordFieldName,
      confirmPasswordFieldName
    );
  };
  //password validation
  checkPasswordValidation(form, type) {
    return passwordValidation(form, type);
  }
  // current password and new password validation

  currentPasswordValidation(
    changePasswordForm: FormGroup,
    curentPasswordFieldName: string,
    newPasswordFieldName: string
  ) {
    return currentPasswordAndNewPasswordValidation(
      changePasswordForm,
      curentPasswordFieldName,
      newPasswordFieldName
    );
  }

  // close or clear form fields
  Close() {
    this.changePasswordForm.reset();
  }
  
   CreateNewPassword(){
    const data ={
      username:this.userProfileData.email,
      currentPassword:this.changePasswordForm.value.currentPassword,
      newPassword:this.changePasswordForm.value.newPassword
    }
    this.store.dispatch(showSpinner());
    this.service.createNewPassword(data).subscribe((res:any)=>{
   
      if(res.success){
        this.changePasswordForm.reset()
        this.toasterService.success(res?.message);
        this.store.dispatch(hideSpinner());
      }else{
       
        this.store.dispatch(hideSpinner());
        this.toasterService.error(res?.message);
        
      }
      
    })
   }
  // submit form
  submitCreateNewPassword() {
    this.CreateNewPassword()
    
  }
  // input remove spaces only
 removeSpaces(event: KeyboardEvent): void {
    if (event.key === ' ') {
      event.preventDefault();
    }
  } 
}
