import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import jsPDF from 'jspdf';
import _ from 'lodash';
import moment from 'moment';
// import autoTable from 'jspdf-autotable';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/modules/auth/services/auth.service';
import { OrganizationService } from 'src/app/modules/organization/services/organization.service';
import { GaugeComponent } from '../Insights/gauge/gauge.component';
import { GraphsComponent } from '../Insights/graphs/graphs.component';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import { hideSpinner, showSpinner } from 'src/app/store/actions/spinner.actions';
import { Location } from '@angular/common';

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {
 

  compareForm: FormGroup;
  @ViewChild('locationLevel') accountLevel: ElementRef;
  @ViewChild('childComponent1') childComponent1: GaugeComponent;
  @ViewChild('childComponent2') childComponent2: GaugeComponent;
  @ViewChild('childComponent3') childComponent3: GaugeComponent;
  @ViewChild('Graphs') Graphs: GraphsComponent;
  fflogo = '../../../../../assets/images/logos/FreightFacts Logo.png';
  options: any [] = [ '122222', '155666' ];
  // eslint-disable-next-line @typescript-eslint/ban-types
  selected: {};
  Report: any = '';
  reportId = '';
  userId = '';
  imagedata: string = 'ladsfjdas';
  showresult: boolean;
  compareIndex: number;
  selectedOrigin: any[];
  selectCompare: any[] = [];
  overAllNames = [];
  overAllScore = [];
  scoreSearch: FormGroup;
  btnAccess = true;
  showData = true;
  businessName = false;
  superAdmin = false;
  type: any = 'Carrier';
  width:"332px";
  tableBgColor = [
    '#cce5ff',
    'rgba(255, 236, 206, 0.41)',
    '#9ba8ca'
  ];
  compareScore: FormGroup;
  ShipperapiAccess = true;
  expanding: boolean;
  Score: any = {};
  orgName: string;
  orgNames: string;
  constructor (
      private elementRef: ElementRef,
      private authService: AuthService,
      private orgService: OrganizationService,
      private toaster: ToastrService,
      private router: Router,
      private location: Location,
      private store: Store<{ spinner: SpinnerState }>
  ) {}

  changeValue(val: any, index: any) {
    if (val.units === '$') {
      return `${val.units}${val.value}`;
    }
    if (val.units === '%') {
      return `${val.value}${val.units}`;
    }
    if ((index === 4 || index === 5)
    || (index === 11 || index === 12)) {
    if (val.value === 'F') {
      return 'Not Required';
    }
    if (val.value === 'T') {
      return 'Required'
    }
  }
  if ((index === 6 || index === 8) || (index === 13 || index === 15)) {
    if (val.value === 'F') {
      return 'No';
    }
    if (val.value === 'T') {
      return 'Yes';
    }
  }
    return `${val.value} ${val.units}`;
  }
  updateColor2(val: any, font: any, index: any, check: any) {
    let value = Number(val);
    let step = 0;
    if (check === 1) {
      step = value / this.Report.searchResponse.accountLevelFFNames[index].possible * 100;
    }
    if (check === 2) {
      step = value / this.Report.searchResponse.locationLevelFFNames[index].possible * 100;
    }
    if (check === 3) {
      step = value / this.overAllNames[index].possible * 100;
    }
    if (font) {
      if (step < 41) {
        return 'white';
      } else {
        return 'black';
      }
    }
    let color = 'rgba(255, 86, 86, 1)';
    if (step < 21) {
      return color = 'rgba(255, 86, 86, 1)';
    } else if (step < 41) {
      return color = 'rgba(255, 136, 136, 1)';
    } else if (step < 61) {
      return color = 'rgba(254, 225, 20, 1)';
    } else if (step < 81) {
      return color = 'rgba(209, 216, 15, 1)';
    } else if (step < 101) {
      return color = 'rgba(132, 189, 50, 1)';
    }
    return color;
  }
  updateColor(val: any, index: any, check: any) {
    let value = Number(val);
    let step = 0;
    if (check === 1) {
      step = value / this.Report.searchResponse.accountLevelFFNames[index].possible * 100;
    }
    if (check === 2) {
      step = value / this.Report.searchResponse.locationLevelFFNames[index].possible * 100;
    }
    if (check === 3) {
      step = value / this.overAllNames[index].possible * 100;
    }
    let color:any = '';
    if (step < 21) {
      return color = [255, 86, 86];
    } else if (step < 41) {
      return color = [255, 136, 136];
    } else if (step < 61) {
      return color = [254, 225, 49];
    } else if (step < 81) {
      return color = [208, 216, 45];
    } else if (step < 101) {
      return color = [132, 189, 50];
    }
    return color;
  }
  genrateReport(val: string) {
    //this.orgName = localStorage.getItem('orgNames').toUpperCase();

    if (val === 'print') {
      const pdf = new jsPDF();
      const fflogo = this.fflogo;
      const Report = this.Report;
      const img = new Image();
      const img2 = new Image();
      const img3 = new Image();
      const gaugeimage = document.getElementById('gague1') as HTMLCanvasElement;
      img.src = gaugeimage.toDataURL('image/png');
      const gaugeimage2 = document.getElementById('gague2') as HTMLCanvasElement;
      img2.src = gaugeimage2.toDataURL('image/png');
      const gaugeimage3 = document.getElementById('gague3') as HTMLCanvasElement;
      img3.src = gaugeimage3.toDataURL('image/png');

      // font style
      var customFont = {
        // Load your font file (TTF, OTF, etc.)
        "file": "./assets/Avenir-Font/avenir_ff/avenir-medium.ttf",
        // Give a name to your font (you will use this name later)
        "name": "avenir-medium",
        // Additional font properties
        "style": "normal",
        "weight": "normal"
      };
      var customFont2 = {
        // Load your font file (TTF, OTF, etc.)
        "file": "./assets/avenir-lt-65-medium-bold/Avenir-Medium-Bold/Avenir-Medium-Bold.ttf",
        // Give a name to your font (you will use this name later)
        "name": "Avenir-Medium-Bold",
        // Additional font properties
        "style": "normal",
        "weight": "normal"
      };

      pdf.addFont(customFont.file, customFont.name, customFont.style, customFont.weight);
      pdf.addFont(customFont2.file, customFont2.name, customFont2.style, customFont2.weight);
      // logo
      pdf.addImage(fflogo, 'PNG', 80, 5, 50, 11);
      
      // business-details
      pdf.setLineWidth(0.5);
      pdf.setDrawColor(0, 0, 0);
      pdf.setLineWidth(0.5);
      pdf.setDrawColor('3E7FD7');
      pdf.roundedRect(150, 20, 50, 25, 2, 2, 'S');
      pdf.setFontSize(12);
      pdf.setFont(customFont2.name, 'normal');
      pdf.text('Overall Score' , 160, 30);
      pdf.setTextColor('3E7FD7');
      pdf.setFontSize(18);
      pdf.text(`${Report.searchResponse.shippersFreightScore.freightScoreDTO.overAll}`, 168, 38);
      pdf.setFont(customFont.name, 'normal');
      pdf.setFontSize(12);

      // gauges
      pdf.setTextColor('000000');
      pdf.addImage(img3.src, 'PNG', 0, 89, 90, 55);
      pdf.setFont(customFont2.name, 'normal');
      pdf.text('Overall Score', 32, 85);
      pdf.text('Account Level', 92, 85);
      pdf.text('Location Level', 152, 85);
      pdf.setFont(customFont.name, 'normal');
      pdf.text('Score', 40, 138);
      pdf.text('Score', 100, 138);
      pdf.text('Score', 160, 138);
      
      pdf.setFontSize(16);
      pdf.text(`${_.get(Report, 'searchResponse.shippersFreightScore.freightScoreDTO.overAll')}`, 41, 133);
      pdf.text(`${_.get(Report, 'searchResponse.shippersFreightScore.freightScoreDTO.accountLevel')}`, 101, 133);
      pdf.text(`${_.get(Report, 'searchResponse.shippersFreightScore.freightScoreDTO.locationLevel')}`, 161, 133);

      pdf.addImage(img.src, 'PNG', 60, 89, 90, 55);
      pdf.addImage(img2.src, 'PNG', 120, 89, 90, 55);
      pdf.setFont(customFont2.name, "normal");
      pdf.setTextColor('3E7FD7');
      pdf.text('Account Level', 15, 160);
      pdf.setFont(customFont.name, "normal");
      pdf.setTextColor('000000');
      pdf.setFontSize(12);
      const headingsdata = [
        { name: 'Account No:', values: Report.accNumber },
        { name: 'Report Generated By:', values: Report.user.firstName  },
        { name: 'Report Generated:', values: moment(Report.createdAt).format('MM-DD-YYYY hh:mm a') },
        { name: 'Shipper Name:', values: Report.shipperName },
        { name: 'Score Type:'},
        { name: 'Location:', values: Report.address },
      ];
      let start = 30;
      let gap = 8;

      headingsdata.forEach((data) => {
        pdf.setFontSize(14);
        pdf.setTextColor('3E7FD7');
        pdf.setFont(customFont2.name, "normal");
        pdf.text(data.name, 15, start);
        pdf.setTextColor('00000');
        pdf.setFont(customFont.name, "normal");
        start += gap;
      });

      pdf.text(`#${Report.accNumber}` , 47, 30);
      pdf.text(`${Report.user.firstName.toUpperCase()} ${Report.user.lastName.toUpperCase()}`, 69, 38);
      pdf.text(`${moment(Report.createdAt).format('MM-DD-YYYY hh:mm A')}`, 62, 46);
      pdf.text(`${Report.shipperName}`, 53, 54);
      pdf.text(`${Report.viewType === 1 ? this.orgNames +" "+ 'VIEW' :'MARKET VIEW'}`, 44, 62);
      pdf.text(`${Report.address}`, 39, 70);

      // account level data

      const data = [];
      const data2 = [];
      Report.searchResponse.accountLevelFFNames.forEach((d: any, ind) => {
        // eslint-disable-next-line prefer-const
        let id = ind;
        Report.searchResponse.accountLevel.points.forEach((point: any, index) => {
          if (id === index) {
            // eslint-disable-next-line prefer-const
            data.push([d.name, d.possible, point.value, point.earned]);
          }
          return '';
        });
      });
      const accountTotal = [
        'Total',
        `${Report.searchResponse.possiblePoints.accountLevelPossiblePoints}`,
        '',
        `${Report.searchResponse.accountLevel.maximumTotalEarnedPoints}`
      ];
      const headings = ['Freight Facts', 'Points Possible', 'Values', 'Points Earned'];
      const styleDef = {
        fillColor: 'white',
        textColor: 'black',
        lineWidth: 0.5,
      }

      // account level table
      let accountTable = 182;
      let div = 10;
      pdf.setDrawColor(0, 0, 0);
      pdf.setLineWidth(0.112);
      pdf.line(15, 165, 200, 165);
      pdf.setFontSize(12);
      pdf.setFillColor('E9E9E9');
      pdf.rect(15, 245, 185, 8, 'F');
      pdf.setFont(customFont2.name, "normal");
      pdf.text(headings[0], 18, 171);
      pdf.text(headings[1], 80, 171);
      pdf.text(headings[2], 120, 171);
      pdf.text(headings[3], 164, 171);
      pdf.setFont(customFont.name, "normal");
      pdf.setFontSize(12);
      pdf.line(15, 175, 200, 175);
      pdf.line(15, 165, 15, 253);
      pdf.line(78, 165, 78, 253);
      pdf.line(118, 165, 118, 253);
      pdf.line(158, 165, 158, 253);
      pdf.line(200, 165, 200, 253);
      _.get(Report, 'searchResponse.accountLevelFFNames').forEach((d) => {
        pdf.text(d.name=== 'Total Weight' ? 'Average Weight Per Shipment' : d.name , 18, accountTable);
        pdf.text(`${d.possible}`, 80, accountTable);
        accountTable += div;
      });
      accountTable = 182;
      var back = 176;
      let boxdiv = 10;
      var width = 41;
      var height = 8.5;
      const last = _.get(Report, 'searchResponse.accountLevel.points').length;
      _.get(Report, 'searchResponse.accountLevel.points').forEach((d2, index) => {
        pdf.text(`${this.changeValue(d2, index)}`, 122, accountTable);
        if (last !== index) {
          pdf.setFillColor(
            this.updateColor(d2.earned, index, 1)[0],
            this.updateColor(d2.earned, index, 1)[1],
            this.updateColor(d2.earned, index, 1)[2],
          );
          pdf.roundedRect(165, back, 27, 8, 4, 4, 'F');
          back += boxdiv;
        }
        pdf.text(`${d2.earned}`, 176, accountTable);
        pdf.line(15, accountTable + 3, 200, accountTable + 3);
        accountTable += div;
      });
      pdf.setFontSize(12);
      pdf.setFont(customFont2.name, "normal");
      pdf.text(accountTotal[0], 18, 250);
      pdf.text(accountTotal[1], 80, 250);
      pdf.text(accountTotal[2], 120, 250);
      pdf.text(accountTotal[3], 175, 250);
      pdf.line(15, 253, 200, 253);
      pdf.setFont(customFont.name, "normal");
      pdf.setFontSize(14);

      // location level table
      const locationTotal = [
        'Total',
        `${_.get(Report, 'searchResponse.possiblePoints.locationLevelPossiblePoints')}`,
        '',
        `${Report.searchResponse.locationLevel.maximumTotalEarnedPoints}`
      ];

      let locationTable = 42;
      // pdf.line(15, 210, 200, 210);
      // pdf.setFontSize(12);
      // pdf.line(15, 217, 200, 217);
      // pdf.line(15, 210, 15, 288.5);
      // pdf.line(78, 210, 78, 288.5);
      // pdf.line(118, 210, 118, 288.5);
      // pdf.line(158, 210, 158, 288.5);
      // pdf.line(200, 210, 200, 288.5);
      _.get(Report, 'searchResponse.locationLevelFFNames').forEach((d, index) => {
        if (index === 0) {
          pdf.addPage();
          pdf.setFontSize(16);
          pdf.setTextColor('3E7FD7');
          pdf.setFont(customFont2.name, "normal");
          pdf.text('Location Level', 15, 20);
          pdf.setFontSize(12);
          pdf.setTextColor('00000');
          pdf.line(15, 25, 200, 25);
          pdf.setFillColor('E9E9E9');
          pdf.rect(15, 185, 185, 10, 'F');
          pdf.text(headings[0], 18, 32);
          pdf.text(headings[1], 80, 32);
          pdf.text(headings[2], 120, 32);
          pdf.text(headings[3], 164, 32);
          pdf.text(locationTotal[0], 18, 192);
          pdf.text(locationTotal[1], 80, 192);
          pdf.text(locationTotal[2], 120, 192);
          pdf.text(locationTotal[3], 175, 192);
          pdf.line(15, 195, 200, 195);
          pdf.setFont(customFont.name, "normal");
          pdf.line(15, 35, 200, 35);
          pdf.line(15, 25, 15, 195);
          pdf.line(78, 25, 78, 195);
          pdf.line(118, 25, 118, 195);
          pdf.line(158, 25, 158, 195);
          pdf.line(200, 25, 200, 195);
          pdf.setFontSize(12);
        }
        pdf.text(d.name=== 'Total Weight' ? 'Average Weight Per Shipment' : d.name , 18, locationTable);
        pdf.text(`${d.possible}`, 80, locationTable);
        locationTable += div;
        // if (index === 8) {
        //   locationTable = 15;
        //   pdf.addPage();
        //   pdf.line(15, 10, 15, 58);
        //   pdf.line(78, 10, 78, 58);
        //   pdf.line(118, 10, 118, 58);
        //   pdf.line(158, 10, 158, 58);
        //   pdf.line(200, 10, 200, 58);
        // }
      });
      locationTable = 42;
      let back2 = 36;
      const last2 = _.get(Report, 'searchResponse.locationLevel.points').length;
      _.get(Report, 'searchResponse.locationLevel.points').forEach((d2, index) => {
        // if (index < 9) {
        //   pdf.setPage(1);
        //   pdf.text(`${d2.value} ${d2.units}`, 120, locationTable);
        //     pdf.setFillColor(
        //       this.updateColor(d2.earned, index, 2)[0],
        //       this.updateColor(d2.earned, index, 2)[1],
        //       this.updateColor(d2.earned, index, 2)[2],
        //     );
        //     pdf.rect(158.5, back2, width, height, 'F');
        //     back2 += div;
        //   pdf.line(15, locationTable + 1.5, 200, locationTable + 1.5);
        //   pdf.text(`${d2.earned}`, 160, locationTable);
        //   locationTable += div;
        // }
        // if (index === 8) {
        //   pdf.setPage(2);
        //   pdf.setFontSize(14);
        //   pdf.text(locationTotal[0], 18, 55);
        //   pdf.text(locationTotal[1], 80, 55);
        //   pdf.text(locationTotal[2], 120, 55);
        //   pdf.text(locationTotal[3], 160, 55);
        //   pdf.line(15, 58, 200, 58);
        //   pdf.setFontSize(12);
        //   locationTable = 15;
        //   pdf.line(15, 10, 200, 10);
        //   div = 8;
        //   back2 = 10;
        // }
        // if (index > 8) {

          pdf.text(`${this.changeValue(d2, index)}`, 121, locationTable);
          if (last2 !== index) {
            pdf.setFillColor(
              this.updateColor(d2.earned, index, 2)[0],
              this.updateColor(d2.earned, index, 2)[1],
              this.updateColor(d2.earned, index, 2)[2],
            );
            pdf.roundedRect(165, back2, 27, 8, 4, 4, 'F');
            back2 += div;
          }
          pdf.line(15, locationTable + 3, 200, locationTable + 3);
          pdf.text(`${d2.earned}`, 176, locationTable);
          locationTable += div;
        // }
      });

      // pdf.addPage();
      // accountTable = 42;
      // back = 36;
      // pdf.setFontSize(16);
      // pdf.setTextColor('3E7FD7');
      // pdf.setFont(customFont2.name, "normal");
      // pdf.text('Overall', 15, 20);
      // pdf.setFontSize(12);
      // pdf.setTextColor('00000');
      // pdf.line(15, 25, 200, 25);
      // pdf.text(headings[0], 18, 32);
      // pdf.text(headings[1], 80, 32);
      // pdf.text(headings[2], 120, 32);
      // pdf.text(headings[3], 164, 32);
      // pdf.setFont(customFont.name, "normal");
      // pdf.line(15, 35, 200, 35);
      // pdf.line(15, 25, 15, 255);
      // pdf.line(78, 25, 78, 255);
      // pdf.line(118, 25, 118, 255);
      // pdf.line(158, 25, 158, 255);
      // pdf.line(200, 25, 200, 255);
      // pdf.line(15, 255, 200, 255);
      // this.overAllNames.forEach((d) => {
      //   pdf.text(d.name=== 'Total Weight' ? 'Average Weight Per Shipment' : d.name , 18, accountTable);
      //   pdf.text(`${d.possible}`, 80, accountTable);
      //   accountTable += div;
      // });
      // accountTable = 42;
      // const last3 = this.overAllScore.length;
      // this.overAllScore.forEach((d2, index) => {
      //   pdf.text(`${this.changeValue(d2, index)}`, 122, accountTable);
      //   if (last3 !== index) {
      //     pdf.setFillColor(
      //       this.updateColor(d2.earned, index, 3)[0],
      //       this.updateColor(d2.earned, index, 3)[1],
      //       this.updateColor(d2.earned, index, 3)[2],
      //     );
      //     pdf.roundedRect(165, back, 27, 8, 4, 4, 'F');
      //     back += boxdiv;
      //   }
      //   pdf.text(`${d2.earned}`, 176, accountTable);
      //   pdf.line(15, accountTable + 3, 200, accountTable + 3);
      //   accountTable += div;
      // });
      // account level table
      // autoTable(pdf, {
      //   headStyles: styleDef,
      //   bodyStyles: styleDef,
      //   alternateRowStyles: styleDef,
      //   head: [headings],
      //   body: data,
      //   startY: 129,
      // });

        // const table = canvas1.toDataURL('image/png');
        // const imm = new Image();
        // imm.src = table;
        // // doc.text(imagee, 30, 40);
        // pdf.addImage(imm.src, 'PNG', 15, 129, 160, 55);
  
      
      // location level data
      _.get(Report, 'searchResponse.locationLevelFFNames').forEach((d: any, ind) => {
        // eslint-disable-next-line prefer-const
        let id = ind;
          _.get(Report, 'searchResponse.locationLevel.points').forEach((point: any, index) => {
          if (id === index) {
            // eslint-disable-next-line prefer-const
            data2.push([d.name, d.possible, point.value, point.earned]);
          }
          return '';
        });
      });
      data2.push([
        'Total',
        `${_.get(Report, 'searchResponse.possiblePoints.locationLevelPossiblePoints')}`,
        '',
        `${_.get(Report, 'searchResponse.possiblePoints.maximumTotalEarnedPoints')}`]);

      // location level table

      // const table2 = canvas2.toDataURL('image/png');
      // const imm2 = new Image();
      // imm2.src = table2;
      // // doc.text(imagee, 30, 40);
      // pdf.addImage(imm2.src, 'PNG', 15, 210, 160, 55);

      // autoTable(pdf, {
      //   headStyles: styleDef,
      //   bodyStyles: styleDef,
      //   alternateRowStyles: styleDef,
      //   head: [headings],
      //   body: data2,
      //   startY: 210,
      // });
      pdf.autoPrint();
      const link: any = pdf.output('bloburl');
      window.open(link);
    }
  }
  back(){
    this.location.back();
  }
  updateGauge(val1: any, val2: any, val3: any) {
    setTimeout(() => {
      this.childComponent1.gaugeCont(val1);
      this.childComponent2.gaugeCont(val2);
      this.childComponent3.gaugeCont(val3);
    }, 0)
  }
  updateTab() {
    this.updateGauge(
      this.Score.freightScore.accountLevel,
      this.Score.freightScore.locationLevel,
      this.Score.freightScore.overAll
    );
  }
  getAccess() {
    const {
      AppRole: appRoleName,
      orgnizations: {
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));
    switch (appRoleName) {
      case 'Admin':
      if (!organizationRoleName) {
        this.superAdmin = true;
        this.orgNames = localStorage.getItem('orgName').toUpperCase();
        console.log("orgname", this.orgName)

      }
      if (organizationRoleName === 'Admin') {
        switch (organizationTypeName) {
          case 'Carrier':
            this.ShipperapiAccess = false;
            this.orgNames = localStorage.getItem('orgNames').toUpperCase();

            return;
        }
        return;
      }
      return;
      case 'User':
        switch (organizationTypeName) {
          case 'Carrier':
            this.ShipperapiAccess = false;
            return;
        }
        return;
    }
  }

  loadPage() {
    this.store.dispatch(showSpinner());
    this.showresult = false;
    this.reportId = localStorage.getItem('reportId');
    this.orgService.getHistoryReport(this.reportId, this.ShipperapiAccess, this.superAdmin, this.userId).subscribe((res: any) => {
      if (res.success) {
        this.showresult = true;
        this.store.dispatch(hideSpinner());
        this.Report = res.data[0];
        this.overAllNames = this.Report.searchResponse.accountLevelFFNames.concat(this.Report.searchResponse.locationLevelFFNames);
        this.overAllScore = this.Report.searchResponse.accountLevel.points.concat(this.Report.searchResponse.locationLevel.points);
        this.updateGauge(
          this.Report.searchResponse.shippersFreightScore.freightScoreDTO.accountLevel,
          this.Report.searchResponse.shippersFreightScore.freightScoreDTO.locationLevel,
          this.Report.searchResponse.shippersFreightScore.freightScoreDTO.overAll
        );
      }
    })
  }
  async ngOnInit() {
    this.userId = this.router.url.split('/')[3];
    this.getAccess();
    this.loadPage();
    this.orgNames = localStorage.getItem('orgName').toUpperCase();
    this.authService.getUserProfile().subscribe();
  }
}