import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-uploadlogo',
  templateUrl: './uploadlogo.component.html',
  styleUrls: ['./uploadlogo.component.scss'],
})
export class UploadlogoComponent {
  @Input() imageUrl: string;
  @Input() size;
  @Input() shape;
  @Input() label: string;
  @Input() showIcon;
  @Input() class: string;
  @Input() name: string;
  @Output() fileSelected = new EventEmitter<File>();
  @Output() logoOnClick = new EventEmitter<File>();
  onFileSelect(event: any) {
    const file = event.target.files[0] as File;
    this.fileSelected.emit(file);
  }
  onLogoClicked(event: any) {
    
    this.logoOnClick.emit(event);
  }
}
