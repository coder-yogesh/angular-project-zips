import { Component, EventEmitter, Input, Output, ViewEncapsulation } from "@angular/core";
import { FormGroup } from "@angular/forms";

@Component({
  selector: "app-check-box",
  templateUrl: "./check-box.component.html",
  styleUrls: ["./check-box.component.scss"],
  encapsulation: ViewEncapsulation.None,
})
export class CheckBoxComponent {
  @Input()
  formGroup: FormGroup;
  @Input() name = "";
  @Input() class = "";
  @Input() error = "";
  @Input() value :any=null;
  @Input() disabled = false;
  @Input() label:string = null;
  // eslint-disable-next-line @angular-eslint/no-output-on-prefix
  @Output() onChangeHappened = new EventEmitter<any>();
  onChangeEvent(event){
    this.onChangeHappened.emit()
  }

}
