import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Calendar } from 'primeng/calendar';

@Component({
  selector: 'app-input-calender',
  templateUrl: './input-calender.component.html',
  styleUrls: ['./input-calender.component.scss'],
})
export class InputCalenderComponent {
  @Input()
  formGroup: FormGroup;
  @Input() class = '';
  @Input() name = '';
  @Input() disabled = false;
  @Input() showIcon = true;
  @Input() showTime = false;
  @Input() timeOnly = false;
  @Input() hourFormat = '24';
  @Input() minDate: Date = null;
  @Input() maxDate: Date = null;
  @Input() showErrorMessage = true;
  @Input() error = '';
  @Input() placeholder: string = null;
  @Input() styleClass: string = null;
  @Input() selectionMode: 'multiple' | 'single' | 'range' = 'single';
  @Input() label = '';
  @Input() showClear = false;
  @Input() className = '';
  @Input() hideOnDateTimeSelect = true;
  @Input() requiredStar = false;
  @Input() SaveDate = false;
  date: Date;
  // eslint-disable-next-line @angular-eslint/no-output-native
  @Output() select = new EventEmitter<any>();
  @Output() clear = new EventEmitter<any>();
  @Output() save: EventEmitter<{ value1: any, value2: any }> = new EventEmitter();
  @ViewChild('calender') calender: Calendar;
  saveDate(event: any) {
    this.save.emit({ value1: event, value2: this.calender });
  }
  onSelect(): void {
    this.select.emit();
  }
  onClear(): void {
    this.clear.emit();
  }
}
