import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.scss']
})
export class DeleteComponent  {
  @Input() deleteModal = false;
  @Input() name = null;
  // eslint-disable-next-line @angular-eslint/no-output-native
  @Output() close = new EventEmitter();
  @Output() delete = new EventEmitter();
  

  
  closeModal(){
    this.close.emit();
  }
  ConfirmDelete(){
    this.delete.emit();
  }
}
