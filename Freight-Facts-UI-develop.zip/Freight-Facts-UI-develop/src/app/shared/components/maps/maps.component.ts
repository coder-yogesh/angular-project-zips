import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrls: ['./maps.component.scss'],
})
export class MapsComponent implements OnInit {
  @Input() details;

  ngOnInit(): void {
    this.onSubmit();
  }

  onSubmit() {
    const directionsService = new google.maps.DirectionsService();
    const directionsRenderer = new google.maps.DirectionsRenderer();

    directionsRenderer.setMap(null); // Clear any existing route

    // Geocode the source and destination addresses
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: this.details?.origin }, (results, status) => {
      if (status === google.maps.GeocoderStatus.OK && results.length > 0) {
        const sourceLocation = results[0].geometry.location;

        geocoder.geocode(
          { address: this.details?.destination },
          (results, status) => {
            if (
              status === google.maps.GeocoderStatus.OK &&
              results.length > 0
            ) {
              const destinationLocation = results[0].geometry.location;

              // Render the map and display the source, destination, and route
              this.renderMap(
                sourceLocation,
                destinationLocation,
                directionsService,
                directionsRenderer
              );
            }
          }
        );
      }
    });
  }

  private renderMap(
    sourceLocation: google.maps.LatLng,
    destinationLocation: google.maps.LatLng,
    directionsService: google.maps.DirectionsService,
    directionsRenderer: google.maps.DirectionsRenderer
  ) {
    const styles = [
      {
        featureType: 'water',
        elementType: 'geometry',
        stylers: [
          { color: '#5469d4' }, // Customize water color
        ],
      },
      {
        featureType: 'landscape',
        elementType: 'geometry',
        stylers: [
          { color: '#E5E5E5' }, // Customize land color
        ],
      },
    ];

    const styledMapType = new google.maps.StyledMapType(styles, {
      name: 'Styled Map',
    });
    const map = new google.maps.Map(document.getElementById('map'), {
      center: sourceLocation,
      zoom: 10,
      mapTypeControl: false,
      streetViewControl: false,
      mapTypeControlOptions: {
        mapTypeIds: ['roadmap', 'satellite', 'hybrid', 'terrain', 'styled_map'],
      },
    });

    map.mapTypes.set('styled_map', styledMapType);
    map.setMapTypeId('styled_map');
    directionsRenderer.setMap(map);

    const request = {
      origin: sourceLocation,
      destination: destinationLocation,
      travelMode: google.maps.TravelMode.DRIVING,
    };

    directionsService.route(request, (result, status) => {
      if (status === google.maps.DirectionsStatus.OK) {
        directionsRenderer.setDirections(result);
      }
    });
  }
}
