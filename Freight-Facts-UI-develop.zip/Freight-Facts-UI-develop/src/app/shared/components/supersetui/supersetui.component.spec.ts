import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupersetuiComponent } from './supersetui.component';

describe('SupersetuiComponent', () => {
  let component: SupersetuiComponent;
  let fixture: ComponentFixture<SupersetuiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupersetuiComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SupersetuiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
