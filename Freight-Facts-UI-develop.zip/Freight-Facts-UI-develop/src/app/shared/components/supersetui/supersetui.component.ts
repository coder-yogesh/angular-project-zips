import { Component, ElementRef } from '@angular/core';
import { embedDashboard } from '@superset-ui/embedded-sdk';
import { SupersetuiService } from 'src/app/modules/organization/services/supersetui.service';

@Component({
  selector: 'app-supersetui',
  templateUrl: './supersetui.component.html',
  styleUrls: ['./supersetui.component.scss']
})
export class SupersetuiComponent {
  constructor(
    private elementRef: ElementRef,
    private embedService: SupersetuiService
  ) {}
  ngOnInit(): void {
    this.embedSupersetDashboard();
  }
  embedSupersetDashboard(): void {
    const dashboardElement =
      this.elementRef.nativeElement.querySelector('#dashboard');
    if (dashboardElement) {
      this.embedService.embedDashboard().subscribe(
        () => {
          // Adjust the size of the embedded iframe
          const iframe = dashboardElement.querySelector('iframe');
          if (iframe) {
            iframe.style.width = '100%'; // Set the width as needed
            iframe.style.height = '88vh'; // Set the height as needed
          }
        },
        (error) => {
          console.error(error);
        }
      );
    }
  }

}
