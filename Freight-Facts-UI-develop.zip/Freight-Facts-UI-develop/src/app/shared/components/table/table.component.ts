import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { Subject } from 'rxjs';
import * as _ from 'lodash';
import { Paginator } from 'primeng/paginator';
import { formatDate } from '@angular/common';
import { metaData } from 'src/app/modules/organization/interfaces/ruleset.model';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent {
  @ViewChild('paginator') paginator: Paginator;
  @Input() responseData: any = [];
  @Input() pageinfo: boolean;
  @Input() config: any = {};
  @Input() metaData: any = {};
  @Input() currentPage = 0;
  @Output() actionHappens = new EventEmitter();
  columns: object[] = [];
  records: object[] = [];
  hasRecords = false;
  showPagination = false;
  error = '';
  prevMeta: any = {
    pageSize: 5,
    pageNumber: 0,
    totalRecords: 0,
    totalPages: 1,
  };
  loading = true;
  searchText = '';
  tableClass: string;
  showOptions: boolean;
  //Initial pagination values
  meta: any = {
    pageSize: 5,
    pageNumber: 0,
    totalRecords: 0,
    totalPages: 1,
  };
  updateCurrentPageStatus = true;

  ngOnInit(): void {
    this.columns = this.config.columns;
    this.tableClass = this.config.class;
    this.records = this.responseData;

    this.meta = this.metaData;
    this.hasRecords = !_.isEmpty(this.records);
    this.error = '';
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['responseData'] && changes['responseData'].currentValue) {
      this.records = this.responseData;
    }
    if (changes['config'] && changes['config'].currentValue) {
      this.columns = this.config.columns;
    }

    if (changes['metaData'] && changes['metaData'].currentValue) {
      this.meta = this.metaData;
      setTimeout(() => {
        if(this.prevMeta.pageNumber !== this.meta.pageNumber){
          this.changePageNumber();
        }
        this.prevMeta = this.meta;
      },0)
    }
  }
  changePageNumber(){
    this.paginator?.changePage(this.meta?.pageNumber);
  }
  onError(error: string): void {
    this.error = error;
  }
  actionData(row: any, action: any): any {
    if (!action.func) {
      return action;
    }
    return action.func(row, action);
  }

  actionClick(type: string, data: any): void {
    if (type === 'options') {
      this.showOptions = true;
      // this.optionsData = [];
    }
    this.actionHappens.emit({ type, data });
  }
}
