export const AdminRoutingUrls: {
  url: string;
  value: string;
  icon: string;
  iconActive: string;
}[] = [
  {
    url: '/freightfacts/dashboard',
    value: 'Dashboard',
    icon: 'assets/images/logos/dashboard.svg',
    iconActive: 'assets/images/logos/dashboardActive.svg',
  },
  {
    url: '/freightfacts/organizations',
    value: 'Organizations',
    icon: 'assets/images/logos/organization.svg',
    iconActive: 'assets/images/logos/organizationActive.svg',
  },
  {
    url: '/freightfacts/scoresettings',
    value: 'Score Settings',
    icon: 'assets/images/logos/ruler.svg',
    iconActive: 'assets/images/logos/rulesActive.svg',
  },
  // {
  //   url: '/freightfacts/insights',
  //   value: 'Insights',
  //   icon: 'assets/images/logos/insights_blue.svg',
  //   iconActive: 'assets/images/logos/insights_black.svg',
  // },
];

export const CarrierAdminRoutingUrls: {
  url:string;
  value: string;
  icon: string;
  iconActive: string;
}[] = [
  // {
  //   url: '/freightfacts/home',
  //   value: 'Home',
  //   icon: 'assets/images/logos/Home.svg',
  //   iconActive: 'assets/images/logos/HomeActive.svg'
  // },
  {
    url: '/freightfacts/dashboard',
    value: 'Dashboard',
    icon: 'assets/images/logos/dashboard.svg',
    iconActive: 'assets/images/logos/dashboardActive.svg',
  },
  {
    url: '/freightfacts/insights',
    value: 'Insights',
    icon: 'assets/images/logos/insights_blue.svg',
    iconActive: 'assets/images/logos/insights_black.svg',
  },
  
  {
    url: '/freightfacts/history',
    value: 'History',
    icon: 'assets/images/logos/History.svg',
    iconActive: 'assets/images/logos/HistoryActive.svg',
  },
  {
    url: '/freightfacts/users',
    value: 'Users',
    icon: 'assets/images/logos/profile-user.svg',
    iconActive: 'assets/images/logos/profile-userActive.svg',
  },
  {
    url: '/freightfacts/dataupload',
    value: 'Data Upload',
    icon: 'assets/images/logos/Upload.svg',
    iconActive: 'assets/images/logos/UploadActive.svg',
  },
  {
    url: '/freightfacts/scoresettings',
    value: 'Score Settings',
    icon: 'assets/images/logos/ruler.svg',
    iconActive: 'assets/images/logos/rulesActive.svg',
  },
  
];

export const ShipperandThreePLAdminRoutingUrls: {
  url:string;
  value: string;
  icon: string;
  iconActive: string;
}[] = [
  // {
  //   url: '/freightfacts/home',
  //   value: 'Home',
  //   icon: 'assets/images/logos/Home.svg',
  //   iconActive: 'assets/images/logos/HomeActive.svg'
  // },
  {
    url: '/freightfacts/dashboard',
    value: 'Dashboard',
    icon: 'assets/images/logos/dashboard.svg',
    iconActive: 'assets/images/logos/dashboardActive.svg',
  },
 
  {
    url: '/freightfacts/history',
    value: 'History',
    icon: 'assets/images/logos/History.svg',
    iconActive: 'assets/images/logos/HistoryActive.svg',
  },
  {
    url: '/freightfacts/users',
    value: 'Users',
    icon: 'assets/images/logos/profile-user.svg',
    iconActive: 'assets/images/logos/profile-userActive.svg',
  }
];

export const CarrierUserRoutingUrls: {
  url: string;
  value: string;
  icon: string;
  iconActive: string;
}[] = [
  // {
  //   url: '/freightfacts/home',
  //   value: 'Home',
  //   icon: 'assets/images/logos/Home.svg',
  //   iconActive: 'assets/images/logos/HomeActive.svg'
  // },
  {
    url: '/freightfacts/dashboard',
    value: 'Dashboard',
    icon: 'assets/images/logos/dashboard.svg',
    iconActive: 'assets/images/logos/dashboardActive.svg',
  },
  {
    url: '/freightfacts/insights',
    value: 'Insights',
    icon: 'assets/images/logos/insights_blue.svg',
    iconActive: 'assets/images/logos/insights_black.svg',
  },
  {
    url: '/freightfacts/history',
    value: 'History',
    icon: 'assets/images/logos/History.svg',
    iconActive: 'assets/images/logos/HistoryActive.svg',
  },
  {
    url: '/freightfacts/dataupload',
    value: 'Data Upload',
    icon: 'assets/images/logos/Upload.svg',
    iconActive: 'assets/images/logos/UploadActive.svg',
  },
 
];

export const Shipperand3plUserRoutingUrls: {
  url: string;
  value: string;
  icon: string;
  iconActive: string;
}[] = [
  // {
  //   url: '/freightfacts/home',
  //   value: 'Home',
  //   icon: 'assets/images/logos/Home.svg',
  //   iconActive: 'assets/images/logos/HomeActive.svg'
  // },
  {
    url: '/freightfacts/dashboard',
    value: 'Dashboard',
    icon: 'assets/images/logos/dashboard.svg',
    iconActive: 'assets/images/logos/dashboardActive.svg',
  },
  {
    url: '/freightfacts/history',
    value: 'History',
    icon: 'assets/images/logos/History.svg',
    iconActive: 'assets/images/logos/HistoryActive.svg',
  },
];
