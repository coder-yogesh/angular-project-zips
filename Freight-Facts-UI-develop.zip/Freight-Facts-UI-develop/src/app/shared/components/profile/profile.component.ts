import { Component,Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { regularExpressions } from 'src/app/core/common/regularexpressions';
import {
  inputValidations,
  patterntValidations,
  userNameValidations,
} from 'src/app/core/common/utils';
import { ProfileService } from '../../services/profile.service';

import { Store } from '@ngrx/store';
import { SpinnerState } from 'src/app/store/state/spinner.state';
import {
  showSpinner,
  hideSpinner,
} from 'src/app/store/actions/spinner.actions';
import { ToastrService } from 'ngx-toastr';
import { UserProfileInfoService } from '../../services/user-profile-info.service';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})

export class ProfileComponent {
  @Input() imageUrl: string;
  @Input() label: string;
  profileForm: FormGroup;
  profileFor: FormGroup;
  selectedImageUrl: any = null;
  imageAsFile: any = null;
  emailFirstLetter: string;
  userName:string
  userInfo:any
  userProfileFirstChat:any;
  emailValidationPattern = regularExpressions.emailExp;
   data :any;
   showsaveButtton:boolean
   showSaveBtn: boolean = true;
   userProfile: any = {
    imageUrl: '',
    name: '',
    label: 'vdv',
  };
  firstChar: any;

  constructor(private fb: FormBuilder,
    private service:ProfileService,
    private toastr: ToastrService,
    private userService :UserProfileInfoService,
    private store: Store<{ spinner: SpinnerState }>
    ) {
   
    this.profileForm = this.fb.group({
      id: [null],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: [
        null,
        [Validators.required, Validators.pattern(this.emailValidationPattern)],
      ],
    });
  }
 ngOnInit(){
  this.getUserProfileData()
 }
 getUserProfileData(){
  this.service.getUserProfile().subscribe((res:any)=>{
    this.userInfo=res.data
    this.profileForm.patchValue({id: res.data.id,
      firstName: res.data.firstName,
      lastName: res.data.lastName,
      email:res.data.email,
      })
      this.firstChar = res.data.firstName;
      this.selectedImageUrl=res.data.profilePicture=='null' ? null : res.data.profilePicture
      this.userName= res.data.firstName + ' ' + res.data.lastName
      this.data=res.data.email
      this.emailFirstLetter = this.data[0]?.toUpperCase();
  })
}
  //pattern validation
  inputValidationsErrors = (profileForm: FormGroup, type: string) => {
    return inputValidations(profileForm, type);
  };
  //email pattern validation
  inputEmailPatternValidationsErrors = (
    profileForm: FormGroup,
    type: string
  ) => {
    return patterntValidations(profileForm, type);
  };

  // select image from file manager
  onFileSelected(file: File) {
    this.imageAsFile = file;
    const reader = new FileReader();
    reader.onload = (e: any) => {
      this.selectedImageUrl = e.target.result;
    };

    reader.readAsDataURL(file);
  }
  chekChanges(form){
   let a   = (this.userInfo.firstName == form.value.firstName && 
    this.userInfo.lastName == form.value.lastName &&
    this.userInfo.email == form.value.email &&
    this.userInfo.profilePicture ==this.selectedImageUrl
    )
    
    
    return a;
  }

  // save profile
  saveProfile() {

    this.store.dispatch(showSpinner());
    
    const { id, firstName, lastName, email } = this.profileForm.value;
    const userInfoData=new FormData()
    userInfoData.append('id',id)
    userInfoData.append('firstName',firstName)
    userInfoData.append('lastName',lastName)
    userInfoData.append('email',email)
    userInfoData.append('profilePicture',this.imageAsFile)
      this.service.updateUserInfo(userInfoData).subscribe((res:any)=>{
      this.userInfo=res?.data
      this.selectedImageUrl=res?.data?.profilePicture
      this.userName= res.data.firstName + ' ' + res.data.lastName
      // localStorage.setItem('userName',this.userName)
      // console.log("userName", this.userName)
      this.userService.updateUserProfileData(res?.data)
      setTimeout(() => {
        this.store.dispatch(hideSpinner());
        this.toastr.success(res?.message);
        this.firstChar = res.data.firstName
      },800)
     })
  }
  // close form
  Close() {
    this.profileForm.patchValue(this.userInfo);
    this.selectedImageUrl=this.userInfo.profilePicture
  }

  
  // onNameChange(event, form, type) {
  //   userNameValidations(event, form, type);
  // }
  onNameChange(event, form, type) {
    form.get(type).setValue(userNameValidations(event, form, type));
  }

  removeSpaces(event: KeyboardEvent): void {
    if (event.key === ' ') {
      event.preventDefault();
    }
  }
  
}
