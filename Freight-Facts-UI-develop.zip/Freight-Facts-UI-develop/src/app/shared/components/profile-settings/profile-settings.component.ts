import { Component } from '@angular/core';
import { ProfileService } from '../../services/profile.service';

@Component({
  selector: 'app-profile-settings',
  templateUrl: './profile-settings.component.html',
  styleUrls: ['./profile-settings.component.scss']
})
export class ProfileSettingsComponent {
  activeIndex:any;
   userProfileData:any

  constructor(private service:ProfileService){}

  ngOnInit(){
        this.getUserProfileData()
  }
  //  get user profile data from slah me
    getUserProfileData(){
      this.service.getUserProfile().subscribe((res:any)=>{
        this.userProfileData=res.data
      })
    }
  changeTab(event:any) {
    this.activeIndex = event.index;
    // const tabHeaderName = event.originalEvent.target.innerText;
  }
}
