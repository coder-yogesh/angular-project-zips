import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-unauthorized-page',
  templateUrl: './unauthorized-page.component.html',
  styleUrls: ['./unauthorized-page.component.scss'],
})
export class UnauthorizedPageComponent implements OnInit {
  showBtn = true;
  ngOnInit(): void {
    const {
      AppRole: appRoleName,
      orgnizations: {
        OrgRole: organizationRoleName,
        OrgType: organizationTypeName,
      },
    } = JSON.parse(localStorage.getItem('Roles'));

    if (appRoleName === 'User' && !organizationRoleName) {
      this.showBtn = false;
    }
  }
  constructor(private router: Router) {}
  logout() {
    localStorage.clear();
    this.router.navigateByUrl('/auth/signIn');
  }
}
