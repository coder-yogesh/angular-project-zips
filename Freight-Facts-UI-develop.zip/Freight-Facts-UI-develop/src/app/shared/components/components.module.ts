import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PrimeUiModule } from '../primeUi/prime-ui.module';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { MapsComponent } from './maps/maps.component';
import { InputTextComponent } from './inputs/input-text/input-text.component';
import { InputCalenderComponent } from './inputs/input-calender/input-calender.component';
import { DropdownComponent } from './inputs/dropdown/dropdown.component';
import { CheckBoxComponent } from './inputs/check-box/check-box.component';
import { ButtonComponent } from './inputs/button/button.component';
import { SideNavComponent } from './side-nav/side-nav.component';
import { LocationAutocompleteComponent } from './location-autocomplete/location-autocomplete.component';
import { HeaderComponent } from './header/header.component';
import { DeleteComponent } from './delete/delete.component';
import { MultiSelectComponent } from './inputs/multi-select/multi-select.component';
import { PasswordComponent } from './inputs/password/password.component';
import { TableComponent } from './table/table.component';
import { TablePipe } from '../pipes/table.pipe';
import { UnauthorizedPageComponent } from './unauthorized-page/unauthorized-page.component';
import { ProfileComponent } from './profile/profile.component';
import { UploadlogoComponent } from './uploadlogo/uploadlogo.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ProfileSettingsComponent } from './profile-settings/profile-settings.component';
import { GaugeComponent } from './Insights/gauge/gauge.component';
import { GraphsComponent } from './Insights/graphs/graphs.component';
import { ReportComponent } from './report/report.component';
import { SupersetuiComponent } from './supersetui/supersetui.component';
@NgModule({
  declarations: [
    LoadingSpinnerComponent,
    PageNotFoundComponent,
    InputTextComponent,
    InputCalenderComponent,
    DropdownComponent,
    CheckBoxComponent,
    ButtonComponent,
    MapsComponent,
    SideNavComponent,
    LocationAutocompleteComponent,
    HeaderComponent,
    TableComponent,
    DeleteComponent,
    MultiSelectComponent,
    PasswordComponent,
    TablePipe,
    UnauthorizedPageComponent,
    ProfileComponent,
    UploadlogoComponent,
    ChangePasswordComponent,
    ProfileSettingsComponent,
    GaugeComponent,
    GraphsComponent,
    ReportComponent,
    SupersetuiComponent,
    
  ],
  imports: [CommonModule, FormsModule, ReactiveFormsModule, PrimeUiModule],
  exports: [
    FormsModule,
    ReactiveFormsModule,
    LoadingSpinnerComponent,
    MapsComponent,
    InputTextComponent,
    InputCalenderComponent,
    DropdownComponent,
    CheckBoxComponent,
    ButtonComponent,
    SideNavComponent,
    HeaderComponent,
    PasswordComponent,
    TableComponent,
    DeleteComponent,
    TablePipe,
    LocationAutocompleteComponent,
    MultiSelectComponent,
    PageNotFoundComponent,
    UnauthorizedPageComponent,
    ProfileComponent,
    UploadlogoComponent,
    ChangePasswordComponent,
    ProfileSettingsComponent,
    GaugeComponent,
    GraphsComponent,
    ReportComponent,
    SupersetuiComponent,


  ],
})
export class ComponentsModule {}
