import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'table',
})
export class TablePipe implements PipeTransform {
  transform(value: any, pipeName: string): any {
    if (!value) {
      return '-';
    }

    // Add logic to apply the dynamic pipe
    function formatShortDate(value) {
      const isoDate = new Date(value);
      // Format the date as "MM/dd/yyyy"
      return `${(isoDate.getMonth() + 1).toString().padStart(2, '0')}/${isoDate
        .getDate()
        .toString()
        .padStart(2, '0')}/${isoDate.getFullYear()}`;
    }

    let formattedDate = '';
    switch (pipeName) {
      case 'titleCase':
        const maxLength = 30;
        let formattedValue = value;

        // Trim the value if it exceeds the maximum length
        if (formattedValue.length > maxLength) {
          formattedValue = formattedValue.slice(0, maxLength) + '...';
        }

        // Convert the trimmed value's first character to uppercase
        formattedValue =
          formattedValue.charAt(0).toUpperCase() + formattedValue.slice(1);

        return formattedValue;
      case 'shortDate':
        formattedDate = formatShortDate(value);
        return formattedDate;
      default:
        return value;
    }
  }
}
