import { TruefalsePipe } from './truefalse.pipe';

describe('TruefalsePipe', () => {
  it('create an instance', () => {
    const pipe = new TruefalsePipe();
    expect(pipe).toBeTruthy();
  });
});
