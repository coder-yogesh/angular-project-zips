import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private baseUrl: string = environment.API_URL;
  constructor(private http:HttpClient) {}

  // slash me
  getUserProfile()  {
    return this.http.get(this.baseUrl + 'users/me');
  }
  
  // new password creation
  createNewPassword(userUpdatedData){
    return this.http.post(this.baseUrl + 'users/changePassword',userUpdatedData)
  }
  // update profile
  updateUserInfo(userData){
    return this.http.put(this.baseUrl + 'users/my-profile',userData)
  }
}
