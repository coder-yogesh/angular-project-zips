import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserProfileInfoService {
  userData: any = {};

  constructor() {}

  updateUserProfileData(data) {
    this.userData = data;
  }

  getUserProfile() {
    if (this.userData.firstName != undefined) {
      this.userData['name'] =
        this.userData?.firstName + ' ' + this.userData?.lastName;
      return this.userData;
    } else {
      return null;
    }
  }
}
