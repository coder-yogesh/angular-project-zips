export const environment = {
    production: false,
    API_URL: 'http://104.154.87.95:8080/',
    ORG_API_URL: 'http://localhost:8090/',
}