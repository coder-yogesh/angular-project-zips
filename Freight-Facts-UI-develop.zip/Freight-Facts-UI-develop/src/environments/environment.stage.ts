export const environment = {
    production: false,
    API_URL: 'http://34.122.82.121:8080/',
    ORG_API_URL: 'http://localhost:8090/',
}