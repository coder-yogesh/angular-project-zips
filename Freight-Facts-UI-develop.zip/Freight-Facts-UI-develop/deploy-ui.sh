echo "Building the UI docker image"
docker build -t ff-ui:latest -f Dockerfile.stage .

echo "Stopping existing UI container"
docker stop ff-ui
docker rm ff-ui

echo "deploying the UI docker image"
docker run --name ff-ui -p 8081:80 -d ff-ui:latest

echo "Deployed"

echo "Removing previous containers and images"
docker container prune -f
docker image prune -f


echo "Sucessfully removed old containers and images"

