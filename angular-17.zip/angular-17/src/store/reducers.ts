import { Action, createReducer, on } from "@ngrx/store";
import { historyList, loadUserDetails, loadUserFailure, loadUserSuccess, setUserData, userList } from "./actions";


export interface State {
    user: any;
    error: any;
}

export const initialState: State = {
    user: {},
    error: undefined
}

export interface users {
    userList: any;
}
export const initialUsers: users = {
    userList: [],
}
export interface userDetails {
    userDetails: any; // Replace `any` with a specific type if available
}

export const initialUser: userDetails = {
    userDetails: {},
};

export interface historyList {
    historyList: any;
}

export const initialHistory: historyList = {
    historyList: {},
}

export const userDetailsReducer = createReducer(
    initialState,
    on(loadUserDetails, (state) => ({ ...state })),
    on(loadUserSuccess, (state, { items }) => ({ ...state, items })),
    on(loadUserFailure, (state, { error }) => ({ ...state, error }))
)

export const userListReducer = createReducer(
    initialUsers,
    on(userList, (state, { userList }) => ({
        ...state,
        userList: userList
    })),
)

export const userData = createReducer(
    initialUser,
    on(setUserData, (state, { user }) => ({
        ...state,
        userData: user
    }))
)

export const historyListReducer = createReducer(
    initialHistory,
    on(historyList, (state, { history }) => ({
        ...state,
        historyList: history
    }))
)

// export function userReducer(state: State | undefined, action: Action) {
//     return userData(state, action);
// }