import { createAction, props } from "@ngrx/store";


export const loadUserDetails = createAction('[user details] load user');

export const loadUserSuccess = createAction(
    '[user details] load user success',
    props<{ items: any}>()
);

export const loadUserFailure = createAction(
    '[user details] load user failure',
    props<{ error: any}>()
);


export const setUserData = createAction(
    '[user] data',
    props<{ user: any }>()
)

export const userList = createAction(
    '[users list] data',
    props<{ userList: any }>()
)

export const historyList = createAction(
    '[history list] data',
    props<{ history: any }>()
)