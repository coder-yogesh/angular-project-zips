import { Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { AuthService } from "../app/modules/auth/services/auth.services";
import { loadUserDetails, loadUserFailure, loadUserSuccess } from "./actions";
import { catchError, map, mergeMap, of } from "rxjs";

@Injectable()
export class UserDetailsEffect{
    constructor (private actions$: Actions, private dataService: AuthService) {}
    loadUser$ = createEffect(() =>
        this.actions$.pipe(
            ofType(loadUserDetails),
            mergeMap(() => 
                this.dataService.userProfile().pipe(
                    map((items) => loadUserSuccess({ items })),
                    catchError((error) => of(loadUserFailure({ error })))
                )
            )
    )
    )
}