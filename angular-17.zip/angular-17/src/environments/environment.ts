export const environement = {
    json_server: 'http://localhost:3000/',
    api_url: 'http://localhost:8080/',
}