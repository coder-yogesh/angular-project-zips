import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../auth/services/auth.services';
import { PrimeUiModule } from '../../../../shared/prime-ui.module';
import { TableComponent } from "../../../../shared/components/table/table.component";
import { Store } from '@ngrx/store';
import { State } from '../../../../../store/reducers';
import { Observable, catchError } from 'rxjs';
import { userList } from '../../../../../store/actions';
import { Form, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-user-list',
  standalone: true,
  imports: [PrimeUiModule, TableComponent],
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.scss'
})
export class UserListComponent implements OnInit {
  userListStore: Observable<any>;
  userForm: FormGroup;
  userModel = false;
  deleteModel = false;
  orgId: any;
  deleteId: any;
  roles: any = [
    { name: 'Admin', id: 1 },
    { name: 'User', id: 2 }
  ]
  filter: any = [
    'name',
    'email'
  ]
  loading: boolean | undefined;
  constructor (
    private messageService: MessageService,
    private userService: AuthService,
    private fb: FormBuilder,
    private store: Store<{ usersList: State }>
  ) {
    this.userForm = this.fb.group({
      id: [''],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: [
        '',
        [Validators.required, Validators.email]
      ],
      role: [null, Validators.required]
    })
    this.userListStore = this.store.select('usersList');
  }
  userList: any = [];
  header = 'Create user';
  columns: any =
  {
    columns:
     [
    {
      header: 'Name',
      field: 'name',
      pipe: 'titleCase',
    },
    {
      header: 'Email',
      field: 'email',
      pipe: 'null'
    },
    {
      header: 'Role',
      field: 'role'
    },
    {
      header: 'Actions',
      type: 'actions',
      actions: [
        {
          type: 'edit',
          text: 'Edit',
          icon: 'pi pi-pencil'
        },
        {
          type: 'delete',
          text: 'Delete',
          icon: 'pi pi-trash'
        }
      ]
    }
  ]
  }
  error = '';
  searchUser(value: any) {
    console.log('sdd', value.data)
    const s = this.userList.filter((item: any) => {
      console.log(item.name.includes(value.data))
      return item;
    });
    console.log('filter', s);
  }
  editUser(data: any) {
    this.header = 'Edit user';
    this.userModel = true;
    this.roles.find(
      (item: any) => {
        console.log('dafa', item.name, data.role);
      }
    )
    const updateRole = this.roles.find(
      (item: any) => item.name == data.role
    );
    this.userForm.patchValue({
      id: data.id,
      firstName: data.firstName,
      lastName: data.lastName,
      email: data.email,
      role: updateRole
    });
  }
  deleteUser(id: any) {
    console.log('dddd', id);
    this.deleteModel = true;
    this.deleteId = id;
  }
  confirmDeleteUser() {
    this.userService.deleteUser(this.orgId, this.deleteId).subscribe((res) => {
      this.messageService.add({ severity: 'success', detail: res.message })
      this.deleteModel = false;
      this.loadUsersList();
    })
  }
  actionFromTable(data: any) {
    switch(data.type) {
      case 'edit':
        this.editUser(data.data);
        return;
      case 'delete':
        this.deleteUser(data.data.id);
        return;
    }
  }
  updateStore() {
    this.userListStore.subscribe((res) => {
      this.userList = res.userList.data.organizationMembers.map((data: any) => ({
        name: `${data.firstName} ${data.lastName}`,
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        role: data.organizationRole.name,
        id: data.id
      }));
    })
  }
  close() {
    this.userModel = false;

  }
  createUser() {
    this.header = 'Create user';
    this.userModel = true;
    this.userForm.reset();
  }
  submitForm(form: any) {
    const {
      firstName,
      lastName,
      email,
      role
    } = form.value;
    const createForm = new FormData();
    createForm.append('firstName', firstName);
    createForm.append('lastName', lastName);
    createForm.append('email', email);
    createForm.append('organizationRole', role.id);
    // createForm.append('applicationRole', '');
    // createForm.append('profilePicture', '');
    this.loading = true;
    console.log('create', this.userForm.value);
    if (this.userForm.value.id === null) {
      this.userService.createUser(this.orgId, createForm)
        .subscribe((res: any) => {
          this.messageService.add({ severity: 'success', detail: res.message })
          this.loading = false;
          this.userModel = false;
          this.loadUsersList();
        });
    } else {
      this.loading = true;
      createForm.append('id', this.userForm.value.id);
      this.userService.updateUser(this.orgId, createForm).subscribe((res: any) => {
        this.messageService.add({ severity: 'success', detail: res.message })
        this.loading = false;
        this.userModel = false;
        this.loadUsersList();
      })
    }
  }
  checkForm(value: any) {
    return this.userForm.get(`${value}`)?.errors && this.userForm.get(`${value}`)?.touched;
  }
  checkChanges(data: any) {
    return this.userList.some(
      (a: any) =>
        a.firstName === data.value.firstName &&
        a.lastName === data.value.lastName &&
        a.email === data.value.email &&
        a.role === data.value.role?.name
    )
  }
  loadUsersList() {
    this.userService.getuserList(
      {
        id: this.orgId,
        pageNumber: '',
        pageSize: '',
        search: ''
      }
    ).subscribe((res) => {
      this.store.dispatch(userList({ userList: res }));
      this.updateStore();
    })
  }
  ngOnInit() {
    this.userService.errorLoader.subscribe((res) => {
      if(res){
        this.loading=false
      }
    }); 
    const {
      orgnizations: { id : orgId }
    } = JSON.parse(localStorage.getItem('Roles') || 'null');
    this.orgId = orgId;
    this.loadUsersList();
  }
}
