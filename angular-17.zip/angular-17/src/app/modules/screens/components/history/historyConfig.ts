export const historyConfig = {
    columns: [
        {
            field: 'sno',
            header: 'S.No'
        },
        {
            field: 'businessName',
            header: 'Businees Name',
        },
        {
            field: 'overall',
            header: 'Overall Score'
        },
        {
            header: 'Actions',
            type: 'actions',
            actions: [
                {
                    type: 'view',
                    icon: 'pi pi-eye'
                }
            ]
        }
    ]
}