import { Component, OnInit } from '@angular/core';
import { TableComponent } from "../../../../shared/components/table/table.component";
import { historyConfig } from './historyConfig';
import { AuthService } from '../../../auth/services/auth.services';
import { PrimeUiModule } from '../../../../shared/prime-ui.module';
import { Store } from '@ngrx/store';
import { State } from '../../../../reducers';
import { Observable } from 'rxjs';
import { historyList } from '../../../../../store/actions';
import _ from 'lodash';

@Component({
  selector: 'app-history',
  standalone: true,
  imports: [TableComponent, PrimeUiModule],
  templateUrl: './history.component.html',
  styleUrl: './history.component.scss'
})
export class HistoryComponent implements OnInit {
  historyListStore: Observable<any>;
  conifg = historyConfig;
  reportModel: boolean = false;
  loading: boolean = false;
  report: any = {};
  overall = 50;
  historyList = [];
  filter: any = [
    'businessName',
    'sno'
  ];
  selectedLevel = 'account';
  scoreArray: any = [];
  score: any = '';
  constructor(
    private service: AuthService,
    private store: Store<{ historyList: State }>
  ) {
    this.historyListStore = this.store.select('historyList');
  }
  values(value: any) {
    if (value === 'account') {
      this.selectedLevel = value;
      const scores = this.report.searchResponse.accountLevel.points;
      const names = this.report.searchResponse.accountLevelFFNames;
      this.scoreArray = names.map((data: any, index: any) => {
        return {
          name: data.name,
          possible: data.possible,
          value: scores[index].value
        }
      });
    }
    if (value === 'location') {
      this.selectedLevel = value;
      const scores = this.report.searchResponse.locationLevel.points;
      const names = this.report.searchResponse.locationLevelFFNames;
      this.scoreArray = names.map((data: any, index: any) => {
        return {
          name: data.name,
          possible: data.possible,
          value: scores[index].value
        }
      });
    }
  }
  actionFromTable(event: any) {
    if (event.type === 'view') {
      this.loading = true;
      this.reportModel = true;
      this.service.reportDetails(event.data.id).subscribe((res: any) => {
        this.loading = false;
        this.report = res.data[0];
        this.score = this.report.searchResponse.shippersFreightScore.freightScoreDTO;
        const scores = this.report.searchResponse.accountLevel.points;
        const names = this.report.searchResponse.accountLevelFFNames;
        this.scoreArray = names.map((data: any, index: any) => {
          return {
            name: data.name,
            possible: data.possible,
            value: scores[index].value
          }
        });
        console.log('dsafas', this.report);
      })
    }
  }
  ngOnInit(): void {
    this.service.historyList({
      page: '',
      rows: '',
      shipperName: '',
      startDate: '',
      endDate: '',
      accNumber: '',
      street: '',
      city: '',
      state: '',
      postalCode: ''
    }).subscribe((res: any) => {
      const history = res.data.scoreResponseDTOS.map((item: any, index: any) => {
        return {
          sno: index + 1,
          businessName: item.shipperName,
          id: item.id,
          user: item.user,
          overall: String(item.overAllScore)
        }
      })
      this.store.dispatch(historyList({ history: history }));
      this.historyListStore.subscribe((res: any) => {
        this.historyList = res.historyList;
      })
    })
  }
}
