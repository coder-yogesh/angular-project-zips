import { Component } from '@angular/core';
import { PermissionsService } from '../../../../auth.guard';
import { PrimeUiModule } from '../../../../shared/prime-ui.module';
import { NavBarComponent } from '../../../../shared/components/nav-bar/nav-bar.component';
import { RouterOutlet } from '@angular/router';
import { UsersComponent } from "../users/users.component";
import { Store } from '@ngrx/store';
import { State } from '../../../../../store/reducers';
import { Observable } from 'rxjs';
import { loadUserDetails } from '../../../../../store/actions';
// import { ComponentModule } from "../../../../shared/components.module";

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [PrimeUiModule, NavBarComponent, RouterOutlet, UsersComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  userDetails$: Observable<any>;
  user: any = {};
  constructor (
    private permis: PermissionsService,
    private store: Store<{ userData: State }>
  ) {
    this.userDetails$ = this.store.select('userData');
    this.userDetails$.subscribe((res) => {
      if (res.userData) {
        this.user = res.userData.data;
      }
    })
  }
}
