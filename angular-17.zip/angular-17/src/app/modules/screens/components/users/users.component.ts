import { Component, OnInit } from '@angular/core';
import { PrimeUiModule } from '../../../../shared/prime-ui.module';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { State } from '../../../../../store/reducers';
import { loadUserDetails } from '../../../../../store/actions';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../../../auth/services/auth.services';
import { passwordAndConfirmPasswordValidation } from '../../../../core/common/utils';
import { UserProfileInfoService } from '../../../../shared/service/user_profile_info';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [PrimeUiModule],
  templateUrl: './users.component.html',
  styleUrl: './users.component.scss'
})
export class UsersComponent implements OnInit {
  userDetails$: Observable<any>;
  userForm: FormGroup;
  passwordForm: FormGroup;
  userDetails:any = {};
  show = false;
  passwordErr = false;
  loading = false;
  userDetailsStore: Observable<any>;
  constructor (
    private messageService: MessageService,
    private authService: AuthService,
    private store: Store<{ userDetails: State, userData: State }>,
    private userService: UserProfileInfoService,
    private fb: FormBuilder) {
    this.userForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: new FormControl({ value: '', disabled: true })
    });
    this.passwordForm = this.fb.group({
      password: ['', Validators.required],
      newPassword: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    })
    this.userDetails$ = store.select('userDetails');
    this.userDetailsStore = store.select('userData');
  }
  checkValidPassword(form: any, newPassword: any, confirmPassword: any) {
    return passwordAndConfirmPasswordValidation(form, newPassword, confirmPassword);
  }
  submitDetails(user: any) {
    this.loading = true;
    const userInfoData = new FormData()
    userInfoData.append('id', this.userDetails.id)
    userInfoData.append('firstName', user.value.firstName)
    userInfoData.append('lastName', user.value.lastName)
    userInfoData.append('email', this.userDetails.email)
    userInfoData.append('profilePicture', this.userDetails.profilePicture);
    this.authService.updateProfile(userInfoData).subscribe((res: any) => {
      setTimeout(() => {
        this.messageService.add({ severity: 'success', detail: res.message })
        this.userService.updateUserProfileData(res?.data);
        this.loading = false;
        this.updateUserStore()
      }, 300)
    });
  }
  submitPassword(form: FormGroup) {
    const payload = {
      username: this.userDetails.email,
      currentPassword: form.value.password,
      newPassword: form.value.newPassword
    }
    this.authService.updatePassword(payload).subscribe((res: any) => {
      this.messageService.add({ severity: 'success', detail: res.message })
      console.log('dsafda', res);
      this.closePassword();
    })
  }
  chekChanges(form: any){
    let a   = (this.userDetails.firstName == form.value.firstName && 
     this.userDetails.lastName == form.value.lastName
     )
     return a;
  }
  closePassword() {
    this.show = false;
    this.passwordForm.reset();
  }
  updateUserStore() {
    this.userDetailsStore.subscribe((res)=> {
      if (res.userData) {
        this.userDetails = res.userData.data;
        this.userForm.patchValue(res.userData.data);
      }
    });
  }
  ngOnInit(): void {
    this.updateUserStore();
  }
}
