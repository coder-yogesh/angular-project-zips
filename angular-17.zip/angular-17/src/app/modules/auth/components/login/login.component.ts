import { Component, NgZone, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.services';
import { PrimeUiModule } from '../../../../shared/prime-ui.module';
import { ActivatedRoute, Router } from '@angular/router';
import { PermissionsService } from '../../../../auth.guard';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { State } from '../../../../../store/reducers';
import { loadUserDetails } from '../../../../../store/actions';
import { MessageService } from 'primeng/api';
import { HttpClient } from '@angular/common/http';
import { TranslateService } from '../../../../core/common/language';
import { countryLanguages } from '../../../../core/common/language-json';
@Component({
  selector: 'app-login',
  standalone: true,
  imports: [PrimeUiModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent implements OnInit {
  load = false;
  languages = countryLanguages;
  googleTranslateSelectObserver: MutationObserver | null = null;
  selectedLanguage: string = 'en';
  loginForm: FormGroup;
  // user: Observable<any>;
  constructor (
    private translateService: TranslateService,
    private http: HttpClient,
    private messageService: MessageService,
    private fb: FormBuilder,
    private service: AuthService,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private store: Store<{ userDetails: State }>,
    private permis: PermissionsService) {
      // this.user = this.store.select('userDetails');
      this.loginForm = this.fb.group({
        username: ['', Validators.required],
        password: ['', Validators.required]
      })
  }
  submit(form: any) {
    this.load = true;
    this.service.errorLoader.subscribe((res) => {
      if(res){
        this.load=false
      }
    }); 
    this.service.loginUser(form.value).subscribe((res: any) => {
      this.load = false;
      if (res.data) {
        this.messageService.add({ severity: 'success', detail: res.message })
        this.permis.login(res.data);
      }
    });
  }
  // setupObserver() {
  //   const target = document.querySelector('.goog-te-combo');
  //   if (target) {
  //     this.googleTranslateSelectObserver = new MutationObserver((mutations) => {
  //       mutations.forEach((mutation) => {
  //         if (mutation.addedNodes[0]) {
  //           const addedNode = mutation.addedNodes[0] as HTMLSelectElement;
  //           if (this.translateService.currentLanguage === addedNode.value) {
  //             this.translateService.translate(addedNode.value);
  //           }
  //         }
  //       });
  //     });
  //     this.googleTranslateSelectObserver.observe(target, { childList: true });
  //   }
  // }
  // ngOnDestroy() {
  //   if (this.googleTranslateSelectObserver) {
  //     this.googleTranslateSelectObserver.disconnect();
  //   }
  // }
  changeLanguage(code: any) {
    console.log('dsafas', code.value.code);
    this.translateService.translate(code.value.code);
  }
  ngOnInit(): void {
    this.translateService.loadScript();
    // this.translateService.scriptLoadEvent.subscribe(() => {
    //   this.setupObserver();
    // })
  }
}
