import { HttpClient, HttpParams } from "@angular/common/http";
// import { HttpClientModule } from '@angular/common/http';
import { EventEmitter, Injectable } from "@angular/core";
import { environement } from "../../../../environments/environment";
import { Observable, map } from "rxjs";
import { Store } from "@ngrx/store";
import { State } from "../../../../store/reducers";
import { loadUserDetails } from "../../../../store/actions";
import { UserProfileInfoService } from "../../../shared/service/user_profile_info";
// import { translate } from "@vitalets/google-translate-api";


@Injectable({
    providedIn: 'root'
})
export class AuthService {
    
    private apiurl: string = environement.api_url;
    private jsonurl: string = environement.json_server;
    errorLoader = new EventEmitter<boolean>()
    userDetails$: Observable<any>;
    constructor (private http: HttpClient, private store: Store<{ userDetails: State }>) {
        this.userDetails$ = store.select('userDetails');
    }
    loginUser(user: any) {
        return this.http.post(`${this.apiurl}api/auth/signin`, user);
    }
    userProfile() {
        return this.http.get(`${this.apiurl}users/me`);
    }
    updateProfile(user: any) {
        return this.http.put(`${this.apiurl}users/my-profile`, user);
    }
    updatePassword(password: any) {
        return this.http.post(`${this.apiurl}users/changePassword`, password);
    }
    createUser(userId: any, data: any) {
        return this.http.post(`${this.apiurl}organizations/${userId}/members`, data);
    }
    deleteUser(orgId: any, id: any): Observable<any> {
        return this.http.delete(
          this.apiurl + `organizations/${orgId}/members/${id}`
        );
    }
    updateUser(orgId: any, data: any): Observable<any> {
        return this.http.post(
          this.apiurl + `organizations/${orgId}/members`,
          data
        );
    }
    getuserList(data: any): Observable<any> {
        let params = new HttpParams();
        params = params
          .append('pageNumber', data.pageNumber)
          .append('pageSize', data.pageSize)
          .append('search', data.search);
        return this.http.get(
          `${this.apiurl}organizations/${data.id}/members/all`,
          { params: params }
        );
    }
    historyList(pageNation: any) {
        let params = new HttpParams();
        params = params
            .append('pageNumber', pageNation.page)
            .append('pageSize', pageNation.rows)
            .append('startDate', pageNation.startDate)
            .append('endDate', pageNation.endDate)
            .append('shipperName', pageNation.shipperName)
            .append('accNumber', pageNation.accNumber)
            .append('street', pageNation.street)
            .append('city', pageNation.city)
            .append('state', pageNation.state)
            .append('postalCode', pageNation.postalCode)
        return this.http.get(this.apiurl + 'history', {
            params: params,
        });
    }
    reportDetails(id: any) {
       return this.http.get(this.apiurl + `history/report/${id}`)
    }
    newserver(name: any) {
        console.log('dfaf', name)
        const newurl = 'http://localhost:3000/';
        return this.http.get(newurl + 'api/data');
    }
}