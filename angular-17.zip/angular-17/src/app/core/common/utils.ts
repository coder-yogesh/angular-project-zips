import { FormGroup } from '@angular/forms';

export const passwordAndConfirmPasswordValidation = (
    form: any,
    password: any,
    confirmPassword: any
  ) => {
    return (
      (form.get(password).touched ||
        form.get(password).dirty ||
        form.get(confirmPassword).touched ||
        form.get(confirmPassword).dirty) &&
      form.get(password).value !== form.get(confirmPassword).value &&
      form.get(password).value &&
      form.get(confirmPassword).value
    );
};