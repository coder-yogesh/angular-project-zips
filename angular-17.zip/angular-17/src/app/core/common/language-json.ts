export const countryLanguages = [
  {
    "code": "en",
    "name": "English",
    "cname": "英语",
    "ename": "English"
  },
  {
    "code": "af",
    "name": "Afrikaans",
    "cname": "南非语",
    "ename": "Afrikaans"
  },
  {
    "code": "am",
    "name": "Amharic",
    "cname": "",
    "ename": "Amharic"
  },
  {
    "code": "bn",
    "name": "Bengali",
    "cname": "",
    "ename": "Bengali"
  },
  {
    "code": "bs",
    "name": "Bosnian",
    "cname": "",
    "ename": "Bosnian"
  },
  {
    "code": "sq",
    "name": "Albanian",
    "cname": "阿尔巴尼亚语",
    "ename": "Albanian"
  },
  {
    "code": "ar",
    "name": "Arabic",
    "cname": "阿拉伯语",
    "ename": "Arabic"
  },
  {
    "code": "hy",
    "name": "Armenian",
    "cname": "亚美尼亚语",
    "ename": "Armenian"
  },
  {
    "code": "az",
    "name": "Azerbaijani",
    "cname": "阿塞拜疆语",
    "ename": "Azerbaijani"
  },
  {
    "code": "eu",
    "name": "Basque",
    "cname": "巴斯克语",
    "ename": "Basque"
  },
  {
    "code": "be",
    "name": "Belarusian",
    "cname": "白俄罗斯语",
    "ename": "Belarusian"
  },
  {
    "code": "bg",
    "name": "Bulgarian",
    "cname": "保加利亚语",
    "ename": "Bulgarian"
  },
  {
    "code": "ca",
    "name": "Catalan",
    "cname": "加泰罗尼亚语",
    "ename": "Catalan"
  },
  {
    "code": "ceb",
    "name": "Cebuano",
    "cname": "",
    "ename": "Cebuano"
  },
  {
    "code": "zh-CN",
    "name": "Chinese (Simplified)",
    "cname": "中文 (简体)",
    "ename": "Chinese (Simplified)"
  },
  {
    "code": "zh-TW",
    "name": "Chinese (Traditional)",
    "cname": "中文 (繁体)",
    "ename": "Chinese (Traditional)"
  },
  {
    "code": "co",
    "name": "Corsican",
    "cname": "中文 (繁体)",
    "ename": "Corsican"
  },
  {
    "code": "hr",
    "name": "Croatian",
    "cname": "克罗地亚语",
    "ename": "Croatian"
  },
  {
    "code": "cs",
    "name": "Czech",
    "cname": "捷克语",
    "ename": "Czech"
  },
  {
    "code": "da",
    "name": "Danish",
    "cname": "丹麦语",
    "ename": "Danish"
  },
  {
    "code": "nl",
    "name": "Dutch",
    "cname": "荷兰语",
    "ename": "Dutch"
  },
  {
    "code": "eo",
    "name": "Esperanto",
    "cname": "",
    "ename": "Esperanto"
  },
  {
    "code": "et",
    "name": "Estonian",
    "cname": "爱沙尼亚语",
    "ename": "Estonian"
  },
  {
    "code": "tl",
    "name": "Filipino",
    "cname": "菲律宾语",
    "ename": "Filipino"
  },
  {
    "code": "fi",
    "name": "Finnish",
    "cname": "芬兰语",
    "ename": "Finnish"
  },
  {
    "code": "fr",
    "name": "French",
    "cname": "法语",
    "ename": "French"
  },
  {
    "code": "fy",
    "name": "Frisian",
    "cname": "",
    "ename": "Frisian"
  },
  {
    "code": "de",
    "name": "German",
    "cname": "德语",
    "ename": "German"
  },
  {
    "code": "gl",
    "name": "Galician",
    "cname": "",
    "ename": "Galician"
  },
  {
    "code": "ka",
    "name": "Georgian",
    "cname": "",
    "ename": "Georgian"
  },
  {
    "code": "el",
    "name": "Greek",
    "cname": "希腊语",
    "ename": "Greek"
  },
  {
    "code": "gu",
    "name": "Gujarati",
    "cname": "",
    "ename": "Gujarati"
  },
  {
    "code": "ha",
    "name": "Hausa",
    "cname": "",
    "ename": "Hausa"
  },
  {
    "code": "haw",
    "name": "Hawaiian",
    "cname": "",
    "ename": "Hawaiian"
  },
  {
    "code": "iw",
    "name": "Hebrew",
    "cname": "",
    "ename": "Hebrew"
  },
  {
    "code": "hi",
    "name": "Hindi",
    "cname": "",
    "ename": "Hindi"
  },
  {
    "code": "ht",
    "name": "Haitian Creole",
    "cname": "",
    "ename": "Haitian Creole"
  },
  {
    "code": "hmn",
    "name": "Hmong",
    "cname": "",
    "ename": "Hmong"
  },
  {
    "code": "hu",
    "name": "Hungarian",
    "cname": "匈牙利语",
    "ename": "Hungarian"
  },
  {
    "code": "is",
    "name": "Icelandic",
    "cname": "",
    "ename": "Icelandic"
  },
  {
    "code": "ig",
    "name": "Igbo",
    "cname": "",
    "ename": "Igbo"
  },
  {
    "code": "id",
    "name": "Indonesian",
    "cname": "印度尼西亚语",
    "ename": "Indonesian"
  },
  {
    "code": "ga",
    "name": "Irish",
    "cname": "爱尔兰语",
    "ename": "Irish"
  },
  {
    "code": "it",
    "name": "Italian",
    "cname": "意大利语",
    "ename": "Italian"
  },
  {
    "code": "ja",
    "name": "Japanese",
    "cname": "日语",
    "ename": "Japanese"
  },
  {
    "code": "jw",
    "name": "Javanese",
    "cname": "",
    "ename": "Javanese"
  },
  {
    "code": "kn",
    "name": "Kannada",
    "cname": "",
    "ename": "Kannada"
  },
  {
    "code": "kk",
    "name": "Kazakh",
    "cname": "",
    "ename": "Kazakh"
  },
  {
    "code": "km",
    "name": "Khmer",
    "cname": "",
    "ename": "Khmer"
  },
  {
    "code": "rw",
    "name": "Kinyarwanda",
    "cname": "",
    "ename": "Kinyarwanda"
  },
  {
    "code": "ko",
    "name": "Korean",
    "cname": "韩语",
    "ename": "Korean"
  },
  {
    "code": "ku",
    "name": "Kurdish",
    "cname": "",
    "ename": "Kurdish"
  },
  {
    "code": "ky",
    "name": "Kyrgyz",
    "cname": "",
    "ename": "Kyrgyz"
  },
  {
    "code": "lo",
    "name": "Lao",
    "cname": "",
    "ename": "Lao"
  },
  {
    "code": "lv",
    "name": "Latvian",
    "cname": "",
    "ename": "Latvian"
  },
  {
    "code": "lt",
    "name": "Lithuanian",
    "cname": "立陶宛语",
    "ename": "Lithuanian"
  },
  {
    "code": "lb",
    "name": "Luxembourgish",
    "cname": "",
    "ename": "Luxembourgish"
  },
  {
    "code": "mk",
    "name": "Macedonian",
    "cname": "",
    "ename": "Macedonian"
  },
  {
    "code": "mg",
    "name": "Malagasy",
    "cname": "",
    "ename": "Malagasy"
  },
  {
    "code": "ms",
    "name": "Malay",
    "cname": "马来西亚语",
    "ename": "Malay"
  },
  {
    "code": "ml",
    "name": "Malayalam",
    "cname": "",
    "ename": "Malayalam"
  },
  {
    "code": "mt",
    "name": "Maltese",
    "cname": "",
    "ename": "Maltese"
  },
  {
    "code": "mi",
    "name": "Maori",
    "cname": "",
    "ename": "Maori"
  },
  {
    "code": "mr",
    "name": "Marathi",
    "cname": "",
    "ename": "Marathi"
  },
  {
    "code": "mn",
    "name": "Mongolian",
    "cname": "",
    "ename": "Mongolian"
  },
  {
    "code": "my",
    "name": "Myanmar (Burmese)",
    "cname": "",
    "ename": "Myanmar"
  },
  {
    "code": "ne",
    "name": "Nepali",
    "cname": "",
    "ename": "Nepali"
  },
  {
    "code": "no",
    "name": "Norwegian",
    "cname": "挪威语",
    "ename": "Norwegian"
  },
  {
    "code": "ny",
    "name": "Nyanja (Chichewa)",
    "cname": "",
    "ename": "Nyanja"
  },
  {
    "code": "or",
    "name": "Odia (Oriya)",
    "cname": "",
    "ename": "Odia"
  },
  {
    "code": "ps",
    "name": "Pashto",
    "cname": "",
    "ename": "Pashto"
  },
  {
    "code": "fa",
    "name": "Persian",
    "cname": "",
    "ename": "Persian"
  },
  {
    "code": "pl",
    "name": "Polish",
    "cname": "波兰语",
    "ename": "Polish"
  },
  {
    "code": "pt",
    "name": "Portuguese",
    "cname": "葡萄牙语",
    "ename": "Portuguese"
  },
  {
    "code": "pa",
    "name": "Punjabi",
    "cname": "",
    "ename": "Punjabi"
  },
  {
    "code": "ro",
    "name": "Romanian",
    "cname": "罗马尼亚语",
    "ename": "Romanian"
  },
  {
    "code": "ru",
    "name": "Russian",
    "cname": "俄语",
    "ename": "Russian"
  },
  {
    "code": "sm",
    "name": "Samoan",
    "cname": "",
    "ename": "Samoan"
  },
  {
    "code": "gd",
    "name": "Scots Gaelic",
    "cname": "",
    "ename": "Scots Gaelic"
  },
  {
    "code": "sr",
    "name": "Serbian",
    "cname": "",
    "ename": "Serbian"
  },
  {
    "code": "st",
    "name": "Sesotho",
    "cname": "",
    "ename": "Sesotho"
  },
  {
    "code": "sn",
    "name": "Shona",
    "cname": "",
    "ename": "Shona"
  },
  {
    "code": "sd",
    "name": "Sindhi",
    "cname": "",
    "ename": "Sindhi"
  },
  {
    "code": "si",
    "name": "Sinhala (Sinhalese)",
    "cname": "",
    "ename": "Sinhala"
  },
  {
    "code": "sk",
    "name": "Slovak",
    "cname": "",
    "ename": "Slovak"
  },
  {
    "code": "sl",
    "name": "Slovenian",
    "cname": "",
    "ename": "Slovenian"
  },
  {
    "code": "so",
    "name": "Somali",
    "cname": "",
    "ename": "Somali"
  },
  {
    "code": "su",
    "name": "Sundanese",
    "cname": "",
    "ename": "Sundanese"
  },
  {
    "code": "sw",
    "name": "Swahili",
    "cname": "",
    "ename": "Swahili"
  },
  {
    "code": "es",
    "name": "Spanish",
    "cname": "西班牙语",
    "ename": "Spanish"
  },
  {
    "code": "sv",
    "name": "Swedish",
    "cname": "瑞典语",
    "ename": "Swedish"
  },
  {
    "code": "tg",
    "name": "Tajik",
    "cname": "",
    "ename": "Tajik"
  },
  {
    "code": "ta",
    "name": "Tamil",
    "cname": "",
    "ename": "Tamil"
  },
  {
    "code": "tt",
    "name": "Tatar",
    "cname": "",
    "ename": "Tatar"
  },
  {
    "code": "te",
    "name": "Telugu",
    "cname": "",
    "ename": "Telugu"
  },
  {
    "code": "tk",
    "name": "Turkmen",
    "cname": "",
    "ename": "Turkmen"
  },
  {
    "code": "th",
    "name": "Thai",
    "cname": "泰语",
    "ename": "Thai"
  },
  {
    "code": "tr",
    "name": "Turkish",
    "cname": "土耳其语",
    "ename": "Turkish"
  },
  {
    "code": "uk",
    "name": "Ukrainian",
    "cname": "乌克兰语",
    "ename": "Ukrainian"
  },
  {
    "code": "ur",
    "name": "Urdu",
    "cname": "",
    "ename": "Urdu"
  },
  {
    "code": "ug",
    "name": "Uyghur",
    "cname": "",
    "ename": "Uyghur"
  },
  {
    "code": "uz",
    "name": "Uzbek",
    "cname": "",
    "ename": "Uzbek"
  },
  {
    "code": "vi",
    "name": "Vietnamese",
    "cname": "",
    "ename": "Vietnamese"
  },
  {
    "code": "cy",
    "name": "Welsh",
    "cname": "",
    "ename": "Welsh"
  },
  {
    "code": "xh",
    "name": "Xhosa",
    "cname": "",
    "ename": "Xhosa"
  },
  {
    "code": "yi",
    "name": "Yiddish",
    "cname": "",
    "ename": "Yiddish"
  },
  {
    "code": "yo",
    "name": "Yoruba",
    "cname": "",
    "ename": "Yoruba"
  },
  {
    "code": "zu",
    "name": "Zulu",
    "cname": "",
    "ename": "Zulu"
  }
]