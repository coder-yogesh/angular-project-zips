// src/app/services/translate.service.ts
import { Injectable, EventEmitter } from '@angular/core';
import { countryLanguages } from './language-json';


declare global {
    interface Window {
      googleTranslateElementInit?: () => void;
      google?: any;
    }
}

@Injectable({
  providedIn: 'root',
})
export class TranslateService {
  scriptLoaded: boolean = false;
  private retryCount = 0;
  private maxRetries = 10;  // Max number of retries for checking dropdown availability
  private retryDelay = 500; // Delay between retries (in milliseconds)
  currentLanguage: string = 'en';
  scriptLoadEvent: EventEmitter<void> = new EventEmitter();

  loadScript() {
    const translatorScriptURL = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';

    // Define the global callback for Google Translate
    window.googleTranslateElementInit = () => {
        new window.google.translate.TranslateElement(
          { pageLanguage: 'en', autoDisplay: false },
          'app'
        );
        this.scriptLoaded = true;
        this.waitForGoogleTranslateDropdown(); // Start checking for the dropdown
      };
    

    const scriptElement = document.createElement('script');
    scriptElement.type = 'text/javascript';
    scriptElement.src = translatorScriptURL;
    scriptElement.onerror = () => {
        console.error('Failed to load Google Translate script');
        // Optionally, retry loading the script after a delay
        setTimeout(() => {
          document.body.appendChild(scriptElement); // Try loading the script again
        }, 2000); // Retry after 2 seconds
    };
    scriptElement.onload = () => {
        console.log('script loaded');
    //   this.handlePostLoad();
    };

    document.body.appendChild(scriptElement);
  }

  // Retry mechanism to check for the dropdown until it appears or max retries reached
  private waitForGoogleTranslateDropdown() {
    const selectElement = document.querySelector('.goog-te-combo') as HTMLSelectElement;
    if (selectElement) {
      console.log('Google Translate dropdown found');
      this.setInitialLanguage(selectElement); // Set initial language once found
    } else if (this.retryCount < this.maxRetries) {
      this.retryCount++;
      console.log(`Retrying to find Google Translate dropdown (${this.retryCount}/${this.maxRetries})`);
      setTimeout(() => this.waitForGoogleTranslateDropdown(), this.retryDelay);  // Retry after delay
    } else {
      console.warn('Google Translate dropdown not found after maximum retries');
    }
  }

  checkIfGoogleTranslateLoaded(): Promise<void> {
    return new Promise((resolve) => {
      if ((window as any).google && (window as any).google.translate) {
        resolve();
      } else {
        const interval = setInterval(() => {
          if ((window as any).google && (window as any).google.translate) {
            clearInterval(interval);
            resolve();
          }
        }, 100);
      }
    });
  }

  private setInitialLanguage(selectElement: HTMLSelectElement) {
    const savedLanguage = localStorage.getItem('_hyper_lang') || 'en';
    selectElement.value = savedLanguage;

    const event = new Event('change');
    selectElement.dispatchEvent(event);
  }

//   private handlePostLoad() {
//     const cookieLanguage = this.cookieService.getCookie('googtrans');
//     if (cookieLanguage.trim() === '') {
//       localStorage.removeItem('_hyper_lang');
//       localStorage.removeItem('app_language');
//     }
//   }
checkIfWidgetInitialized(): Promise<void> {
    return new Promise((resolve) => {
      if ((window as any).google && (window as any).google.translate) {
        resolve();
      } else {
        const interval = setInterval(() => {
          if ((window as any).google && (window as any).google.translate) {
            clearInterval(interval);
            resolve();
          }
        }, 100);
      }
    });
  }
  async translate(code: string, callback?: Function) {
    try {
      // Clear previous translation state
      localStorage.removeItem('_hyper_lang');
      localStorage.removeItem('app_language');
      this.setCookie('googtrans', `/en/${code}`, 365); // Set the new language in the cookie
  
      await this.checkIfGoogleTranslateLoaded(); // Ensure Google Translate is loaded
  
      // Trigger Google Translate dropdown change
      const select = document.querySelector('.goog-te-combo') as HTMLSelectElement;
      if (!select) {
        console.warn('Google Translate dropdown not found');
        return false;
      }
  
      // Handle the special case of switching from English
      if (code === 'en') {
        window.location.reload(); // Reload the page if switching to English
        return true;
      }
  
      select.value = code;
      const event = new Event('change', { bubbles: true });
      select.dispatchEvent(event);
  
      this.currentLanguage = code;
      localStorage.setItem('_hyper_lang', code); // Store the selected language
  
      if (callback) callback();
      return true;
    } catch (error) {
      console.error('Translation error:', error);
      return false;
    }
  }
  
  setCookie(name: string, value: string, days: number, path: string = '/') {
    let expires = '';
    if (days) {
      const date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      expires = `expires=${date.toUTCString()};`;
    }
    document.cookie = `${name}=${value};${expires}path=${path};Secure;SameSite=Lax`;
  }

  getLanguageInfoFromCode(code: string) {
    return countryLanguages.find((language: any) => language.code === code);
  }
}
