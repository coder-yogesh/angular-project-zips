import { HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptorFn, HttpRequest, HttpResponse } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { catchError, tap, throwError } from 'rxjs';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../modules/auth/services/auth.services';

export const demoInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const messageService = inject(MessageService); // Use Angular's DI to get MessageService
  const authToken = localStorage.getItem('token');
  const router = inject(Router);
  const authReq = authToken
    ? req.clone({
        setHeaders: {
          Authorization: `Bearer ${authToken}`
        }
      })
    : req;

  return next(authReq).pipe(
    tap((even: any) => {
      // if (even instanceof HttpResponse) {
      //     if (even.body.message) {
      //       return messageService.add({ severity: 'success', detail: even.body.message })
      //     }
      // }
    }),
    catchError((error: HttpErrorResponse) => {
      authService.errorLoader.emit(true);
      if (error.status == 401) {
        localStorage.clear();
        router.navigateByUrl('/login');
      }
      if (error?.status == 500) {
        if (error.error.error === 'Internal Server Error') {
          messageService.add({ severity: 'error', detail: 'Something went wrong. Please try again' });
        }
      }
      if (error.statusText && error.status === 0) {
        messageService.add({ severity: 'error', detail: 'Something went wrong' });
      }
      if (
        error.error.message &&
        error.error.message !== 'No Data Found' &&
        error.error.message !== 'Invalid JWT token' &&
        error.error.message !== 'Bad credentials'
      ) {
        messageService.add({ severity: 'error', detail: error.error.message });
      }
      if (error.error.message == 'Bad credentials') {
        messageService.add({
          severity: 'error',
          detail:'Invalid credentials. Please check your username and password.'
        });
      }
      return throwError(error);
    })
  );
};
