import { ApplicationConfig, importProvidersFrom } from '@angular/core';
import { provideRouter } from '@angular/router';
// import { provideHttpClient } from "@angular/common/http";
import { provideAnimations } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { demoInterceptor } from './core/interceptor/interceptor.interceptor';
import { routes } from './app.routes';
import { provideStore } from '@ngrx/store';
import { effects, metaReducers, reducers } from './reducers';
import { provideEffects } from '@ngrx/effects';
import { MessageService } from 'primeng/api';

export const appConfig: ApplicationConfig = {
  
  providers: [
    provideRouter(routes),
    provideAnimations(),
    provideHttpClient(withInterceptors([demoInterceptor])),
    provideStore(reducers, { metaReducers }),
    provideEffects(effects),
    MessageService
]
};
