import { Component, EventEmitter, Input, OnInit, Output, Pipe, SimpleChanges } from '@angular/core';
import { PrimeUiModule } from '../../prime-ui.module';
import { TablePipe } from '../../pipes/pipe';

interface Column {
  field: string;
  header: string;
  pipe: string;
  style: string;
  type: string;
  actions: any;
}
@Component({
  selector: 'app-table',
  standalone: true,
  imports: [PrimeUiModule, TablePipe],
  templateUrl: './table.component.html',
  styleUrl: './table.component.scss'
})
export class TableComponent implements OnInit {
  @Input() list = [];
  @Input() config: any = {};
  @Input() filter = [];
  @Output() eventHappend = new EventEmitter();
  columns: Column[] = [];
  records: object[] = [];
  searchValue: string | undefined;
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['list'] && changes['list'].currentValue) {
      this.records = this.list;
    }
    if (changes['config'] && changes['config'].currentValue) {
      this.columns = this.config.columns;
    }
  }
  actionData(row: any, action: any) {
    if (!action.func) {
      return action;
    }
    return action.func(row, action);
  }
  actionClick(type: any, data: any) {
    this.eventHappend.emit({ type, data });
  }
  ngOnInit(): void {
    this.columns = this.config.columns;
    this.records = this.list;
  }
}
