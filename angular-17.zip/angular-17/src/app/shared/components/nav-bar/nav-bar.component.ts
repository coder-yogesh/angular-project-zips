import { Component, OnInit, inject } from '@angular/core';
import { PrimeUiModule } from '../../prime-ui.module';
import { PermissionsService } from '../../../auth.guard';
import * as _ from 'lodash';
import { AuthService } from '../../../modules/auth/services/auth.services';
import { NavigationEnd, Router } from '@angular/router';
import { MegaMenuItem } from 'primeng/api';
import { Store } from '@ngrx/store';
import { Observable, map } from 'rxjs';
import { State } from '../../../../store/reducers';
import { UserProfileInfoService } from '../../service/user_profile_info';
import { setUserData } from '../../../counter.actions';

@Component({
  selector: 'app-nav-bar',
  standalone: true,
  imports: [PrimeUiModule],
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss'
})
export class NavBarComponent implements OnInit {
  private store = inject(Store<State>);
  
  isDarkMode = false;
  checked: boolean = false;
  user: any = {};
  // showNav = true;
  // userDetails$: Observable<any>;
  userData: Observable<any>;
  items: MegaMenuItem[] | undefined;
  load = false;
  token: any = '';
  userProfile: any = {
    imageUrl: '',
    name: '',
    label: 'vdv',
  };
  name = 'User';
  currentRoute: string | undefined;
  constructor (
    private router: Router,
    private permis: PermissionsService,
    public userService: UserProfileInfoService,
    private service: AuthService,
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.currentRoute = event.urlAfterRedirects;
      }
    });
    // if (window.location.href.split('/')[3] === 'login') {
    //   this.showNav = false;
    // }
    this.userData = this.store.select('userData');
    this.loadUser();
  }
  toggleTheme() {
    this.isDarkMode = !this.isDarkMode;
    document.body.classList.toggle('dark-theme', this.isDarkMode);
    localStorage.setItem('theme', this.isDarkMode ? 'dark' : 'light');
  }
  pageURL(url: any) {
    this.router.navigateByUrl(`${url}`);
  }
  isActive(route: string): boolean {
    console.log('dsafas', this.currentRoute, route);
    return this.currentRoute === route;
  }
  logout() {
    this.permis.logout();
  }
  loadUser() {
      this.items = [
        {
          label: 'Dashboard',
          icon: 'pi pi-home',
          route: 'page/dashboard'
        },
        {
          label: 'Users',
          icon: 'pi pi-users',
          route: 'page/userlist'
        },
        {
          label: 'History',
          icon: 'pi pi-list',
          route: 'page/history'
        },
        {
          label: 'Profile',
          icon: 'pi pi-user-edit',
          route: 'page/users'
        }
    ]
  }
  getUserProfile() {
    this.service.userProfile().subscribe((user: any) => {   
      this.store.dispatch(setUserData({ user: user }));   
      this.userProfile.name =
        user?.data?.firstName;
      this.userProfile.label =
        user?.data?.firstName?.charAt(0).toUpperCase() 
      this.userProfile.imageUrl = user?.data?.profilePicture
    });
  }
  ngOnInit(): void {
    const storedTheme = localStorage.getItem('theme');
  if (storedTheme) {
    this.isDarkMode = storedTheme === 'dark';
    document.body.classList.toggle('dark-theme', this.isDarkMode);
  }
    const token: any = localStorage.getItem('token');
    if (token) {
      this.getUserProfile();
    }
  }
}
