import { Component, OnInit } from '@angular/core';
import { PrimeUiModule } from '../../prime-ui.module';
import { AuthService } from '../../../modules/auth/services/auth.services';
import { PermissionsService } from '../../../auth.guard';

@Component({
  selector: 'app-side-nav',
  standalone: true,
  imports: [PrimeUiModule],
  templateUrl: './side-nav.component.html',
  styleUrl: './side-nav.component.scss'
})
export class SideNavComponent implements OnInit {
  user: any = {};
  constructor (private service: AuthService, private permis: PermissionsService,) {}
  logout() {
    this.permis.logout();
  }
  ngOnInit(): void {
    // this.service.userProfile().subscribe((res: any) => {
    //   this.user = res.data;
    // });
  }
}
