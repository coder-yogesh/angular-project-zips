import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { ReactiveFormsModule } from "@angular/forms";
import { FormsModule } from "@angular/forms";
import { ButtonModule } from "primeng/button";
import { InputTextModule } from "primeng/inputtext";
import { PasswordModule } from 'primeng/password';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import { MegaMenuModule } from 'primeng/megamenu';
import { ToastModule } from 'primeng/toast';
import { TableModule } from 'primeng/table';
import { DialogModule } from 'primeng/dialog';
import { DropdownModule } from 'primeng/dropdown';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { KnobModule } from 'primeng/knob';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { InputSwitchModule } from 'primeng/inputswitch';
// import { ComponentModule } from "./components.module";

@NgModule({
    exports: [
      // ComponentModule,
      CommonModule,
      InputTextModule,
      ReactiveFormsModule,
      FormsModule,
      ButtonModule,
      PasswordModule,
      MegaMenuModule,
      OverlayPanelModule,
      ToastModule,
      TableModule,
      DialogModule,
      DropdownModule,
      ProgressSpinnerModule,
      KnobModule,
      ToggleButtonModule,
      InputSwitchModule
    ],
})
export class PrimeUiModule {}
