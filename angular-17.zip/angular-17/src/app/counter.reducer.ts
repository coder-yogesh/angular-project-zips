import { Action, createReducer, on } from "@ngrx/store";
import { decrese, increse, reset, setUserData, storeData } from "./counter.actions";


export const initialState = 0;
export interface State {
    userData: any; // Replace `any` with a specific type if available
}

export const initialUser: State = {
    userData: null,
};

export const counterReducer = createReducer(
    initialState,
    on(increse, (state) => state + 1),
    on(decrese, (state) => state - 1),
    on(reset, (state) => 0)
)

export const userData = createReducer(
    initialUser,
    on(setUserData, (state, { user }) => ({
        ...state,
        userData: user
    }))
)

export function userReducer(state: State | undefined, action: Action) {
    return userData(state, action);
}