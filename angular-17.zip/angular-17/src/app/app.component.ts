import { Component, OnInit, inject } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { PrimeUiModule } from './shared/prime-ui.module';
import { NavBarComponent } from "./shared/components/nav-bar/nav-bar.component";
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { decrese, increse, reset, setUserData } from './counter.actions';
import { loadUserDetails } from '../store/actions';
import { SideNavComponent } from "./shared/components/side-nav/side-nav.component";
import { State } from './reducers';
import { userData } from './counter.reducer';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet, PrimeUiModule,
    NavBarComponent,
    SideNavComponent
],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements OnInit {
  private store = inject(Store<State>);
  count?: Observable<object>;
  title = 'angular-v17';
  showHeader: boolean = false;
  showNav = false;
  load = true;
  data: any = '';
  // userDetails$: Observable<any>;
  constructor(
    private router: Router 
  ) {
    // this.userDetails$ = this.store.select('userDetails');
    this.count = this.store.select('userData');
    const user = { name: 'John Doe', age: 30 };

    // // Dispatch the action to set user data
    this.store.dispatch(setUserData({ user }));
    // window.addEventListener('storage', (event) => {
    //   console.log('dsafas', event.storageArea);
    //   if (event.storageArea == localStorage) {
    //     const token = localStorage.getItem('token');

    //     if (token) {
    //       this.router.navigate(['/dashboard']);
    //     } else {
    //       this.router.navigate(['/login']);
    //     }
    //   }
    // });
  }
  callStore() {
    this.count?.subscribe((res) => {
      console.log('dsaf', res);
      this.data = res;
    })
  }
  // add() {
  //   this.store.dispatch(increse());
  // }
  // sub() {
  //   this.store.dispatch(decrese());
  // }
  // set() {
  //   this.store.dispatch(reset());
  // }
  ngOnInit(): void {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.showHeader = event.url === '/login' || event.url === '/';
      }
    });
  }
}
