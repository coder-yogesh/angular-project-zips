import { CanActivateFn, Router } from '@angular/router';
import { Injectable, inject } from '@angular/core';


@Injectable(
  { providedIn: 'root' }
)

export class PermissionsService {
  private isAuth: boolean = false;
  constructor(
    private router: Router
  ) {
    this.checkAuthStatus();

    // Listen for storage changes to handle logouts from other tabs
    window.addEventListener('storage', () => this.checkAuthStatus());
  }

  private checkAuthStatus(): void {
    this.isAuth = !!localStorage.getItem('token');
  }
  canActivateLogin(): boolean {
    this.checkAuthStatus();
    if (this.isAuth) {
      this.router.navigate(['page/dashboard']);
      return false;
    }
    // Guests should be able to access the login page
    return !this.isAuth;
  }

  canActivateDashboard(): boolean {
    this.checkAuthStatus();
    if (!this.isAuth) {
      this.router.navigate(['/login']);
      return false;
    }
    // Only authenticated users with roles other than 'guest' can access the dashboard
    return this.isAuth;
  }

  // Method to simulate login
  login(data: any) {
    this.isAuth = true;
    this.checkAuthStatus();
    this.router.navigate(['page/dashboard']);
    localStorage.setItem('token', data.accessToken);
    const {
      user: {
        organizations,
        appRole: {
          name: appRoleName
        }
      }
    } = data;
    const Roles = {
      AppRole: appRoleName,
      orgnizations: {
        id: organizations[0]?.organizationResponse?.id || '',
        OrgRole: organizations[0]?.organizationRoleDTO?.name || '',
        OrgType: organizations[0]?.organizationResponse?.type?.name || '',
        OrgName: organizations[0]?.organizationResponse?.name || '',
      },
    };
    localStorage.setItem('Roles', JSON.stringify(Roles));
  }

  // Method to simulate logout
  logout() {
    this.isAuth = false;
    this.checkAuthStatus();
    this.router.navigate(['/login']);
    // localStorage.clear();
    localStorage.removeItem("token")
    localStorage.removeItem("Roles")
  }
}

export const loginGuard: CanActivateFn = (route, state) => {
  return inject(PermissionsService).canActivateLogin();
};

export const dashboardGuard: CanActivateFn = (route, state) => {
  return inject(PermissionsService).canActivateDashboard();
};