import { isDevMode } from "@angular/core";
import { ActionReducerMap, MetaReducer } from "@ngrx/store";
import { counterReducer, userData } from "../counter.reducer";
import { historyListReducer, userDetailsReducer, userListReducer } from "../../store/reducers";
import { UserDetailsEffect } from "../../store/effects";



export interface State {

}

export const reducers: ActionReducerMap<State> = {
    counter: counterReducer,
    userData: userData,
    userDetails: userDetailsReducer,
    usersList: userListReducer,
    historyList: historyListReducer
}

export const metaReducers: MetaReducer<State>[] = isDevMode() ? [] : [];

export const effects = [UserDetailsEffect];