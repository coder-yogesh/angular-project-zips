import { createAction, props } from "@ngrx/store";


export const increse = createAction('[count] increment');
export const decrese = createAction('[count] decrese');
export const reset = createAction('[count] reset');

export const storeData = createAction('[data] user');

export const setUserData = createAction(
    '[user] data',
    props<{ user: any }>()
)