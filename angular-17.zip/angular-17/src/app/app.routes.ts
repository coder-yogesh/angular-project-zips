import { Routes } from '@angular/router';
import { LoginComponent } from './modules/auth/components/login/login.component';
import { DashboardComponent } from './modules/screens/components/dashboard/dashboard.component';
import { loginGuard, dashboardGuard } from './auth.guard';
import { UsersComponent } from './modules/screens/components/users/users.component';
import { UserListComponent } from './modules/screens/components/user-list/user-list.component';
import { HistoryComponent } from './modules/screens/components/history/history.component';


export const routes: Routes = [
    {
        path: '',
        redirectTo: '/login',
        pathMatch: 'full',
    },
    {
        path: 'login',
        canActivate: [loginGuard],
        component: LoginComponent,
    },
    {
        path: 'page',
        redirectTo: 'page/dashboard',
        pathMatch: 'full'
    },
    {
        path: 'page/dashboard',
        canActivate: [dashboardGuard],
        component: DashboardComponent,
    },
    {
        path: 'page/userlist',
        canActivate: [dashboardGuard],
        component: UserListComponent
    },
    {
        path: 'page/users',
        canActivate: [dashboardGuard],
        component: UsersComponent
    },
    {
        path: 'page/history',
        canActivate: [dashboardGuard],
        component: HistoryComponent
    }
];
