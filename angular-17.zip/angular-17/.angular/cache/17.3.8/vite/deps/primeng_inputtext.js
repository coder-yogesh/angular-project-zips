import {
  InputText,
  InputTextModule
} from "./chunk-GTJQSNII.js";
import "./chunk-KBCLPT66.js";
import "./chunk-V4I6KYGB.js";
import "./chunk-5IYYOYV5.js";
import "./chunk-CHRFX2HE.js";
import "./chunk-R7GQRDZ6.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
