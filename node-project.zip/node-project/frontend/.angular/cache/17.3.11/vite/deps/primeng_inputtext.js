import {
  InputText,
  InputTextModule
} from "./chunk-3WD7UFKB.js";
import "./chunk-GXHMSPRK.js";
import "./chunk-E2NJHK34.js";
import "./chunk-34TDFX6S.js";
import "./chunk-GRRFGR25.js";
import "./chunk-PZQZAEDH.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
