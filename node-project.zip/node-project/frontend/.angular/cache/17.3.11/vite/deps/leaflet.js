import {
  require_leaflet_src
} from "./chunk-LIZXPNWJ.js";
import "./chunk-PZQZAEDH.js";
export default require_leaflet_src();
//# sourceMappingURL=leaflet.js.map
