import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-4RMBBCER.js";
import "./chunk-7MN53QO5.js";
import "./chunk-UT6VC2SP.js";
import "./chunk-6D4HCYGP.js";
import "./chunk-NKQEWZDW.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-E2NJHK34.js";
import "./chunk-34TDFX6S.js";
import "./chunk-GRRFGR25.js";
import "./chunk-PZQZAEDH.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
