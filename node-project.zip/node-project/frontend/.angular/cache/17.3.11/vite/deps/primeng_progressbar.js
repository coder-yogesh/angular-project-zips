import {
  ProgressBar,
  ProgressBarModule
} from "./chunk-YXH4U5FU.js";
import "./chunk-E2NJHK34.js";
import "./chunk-34TDFX6S.js";
import "./chunk-GRRFGR25.js";
import "./chunk-PZQZAEDH.js";
export {
  ProgressBar,
  ProgressBarModule
};
//# sourceMappingURL=primeng_progressbar.js.map
