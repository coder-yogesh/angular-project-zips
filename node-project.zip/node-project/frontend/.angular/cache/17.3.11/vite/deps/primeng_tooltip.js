import {
  Tooltip,
  TooltipModule
} from "./chunk-SGF4M7T2.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-E2NJHK34.js";
import "./chunk-34TDFX6S.js";
import "./chunk-GRRFGR25.js";
import "./chunk-PZQZAEDH.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
