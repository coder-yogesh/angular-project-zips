import {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
} from "./chunk-3XJY4K7R.js";
import "./chunk-XFFFO5WI.js";
import "./chunk-SJSJYM7L.js";
import "./chunk-4RMBBCER.js";
import "./chunk-7MN53QO5.js";
import "./chunk-UT6VC2SP.js";
import "./chunk-6D4HCYGP.js";
import "./chunk-GXHMSPRK.js";
import "./chunk-4VGWQ4L7.js";
import "./chunk-ECTJCBTB.js";
import "./chunk-NKQEWZDW.js";
import "./chunk-JZQAVOZS.js";
import "./chunk-E2NJHK34.js";
import "./chunk-IFPCQ2RE.js";
import "./chunk-34TDFX6S.js";
import "./chunk-GRRFGR25.js";
import "./chunk-PZQZAEDH.js";
export {
  CALENDAR_VALUE_ACCESSOR,
  Calendar,
  CalendarModule
};
//# sourceMappingURL=primeng_calendar.js.map
