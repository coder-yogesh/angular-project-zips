import { AfterViewInit, Component, OnInit } from '@angular/core';
import * as L from 'leaflet';
import { Marker } from '../settings/markert';
import { HttpClient } from '@angular/common/http';

// import "@geoman-io/leaflet-geoman-free";
// import "@geoman-io/leaflet-geoman-free/dist/leaflet-geoman.css";

// import "leaflet-measure-path";

declare module 'leaflet' {
  namespace Control {
    class Draw extends L.Control {
      constructor(options?: any);
    }
  }

  namespace Draw {
    namespace Event {
      const CREATED: string;
      const EDITED: string;
      const DELETED: string;
    }
  }
}

const iconRetinaUrl =
  "../../../../../assets/marker-icon-2x.png";
const iconUrl = "../../../../../assets/marker-icon.png";
const shadowUrl = "../../../../../assets/marker-shadow.png";
const iconDefault = L.icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41]
});
L.Marker.prototype.options.icon = iconDefault;

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrl: './maps.component.scss'
})
export class MapsComponent implements OnInit {
  constructor(private http: HttpClient) {}
  private map!: L.Map;
  private markers:any = [];
  private _markers: any[] = []; 
  ngOnInit(): void {
    this.initializeMap();
  }
  initializeMap() {
    this.map = L.map('map2', {
      center: [51.505, -0.09], // Initial map center
      zoom: 13
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(this.map);
    this.searchLocation('AKRON, OH, USA')
  }
  searchLocation(address: string) {
    const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}`;

    console.log('ddd', geocodeUrl);
    this.http.get(geocodeUrl).subscribe((data: any) => {
      console.log('dafadfsa', data);
      if (data && data.length > 0) {
        const lat = parseFloat(data[0].lat);
        const lon = parseFloat(data[0].lon);
        console.log('dsafa', lat, lon);
        this.addMarker(lat, lon);
      }
    });
  }
  addMarker(lat: number, lon: number) {
    this._markers.push(new Marker(lat, lon));

    // L.marker([lat, lon]).addTo(this.map)
    //   .bindPopup("Nearest Location")
    //   .openPopup();

    // this.map.setView([lat, lon], 13);
    this.loadMarkers();
  }
  private loadMarkers() {
    // this.markersData.forEach((markerData) => {
    //   const marker: any = L.marker([markerData.lat, markerData.lng])
    //     .addTo(this.map)
    //     .bindPopup(markerData.popup);
    //   var zoom = 4;
    //   this.map.flyTo([marker.lat, marker.lon], zoom)
    //   this.map.addLayer(marker);
    //   this._markers.push(markerData);  // Add marker data to the _markers array
    // });
    // if (this.map == null) {
    //   console.error("no map given, cannot plot markers");
    //   return;
    // }

    for (let i = 0; i < this._markers.length; ++i) {
      const marker = this._markers[i];
      console.log('marp', marker, this._markers);
      const mapMarker = L.marker([marker.lat, marker.lng]);
      // this.markerClusterGroup.addLayer(mapMarker);
      this.map.addLayer(mapMarker);
      var zoom = 4;
      this.map.flyTo([marker.lat, marker.lng], zoom)
      // this.markerClusterGroup?.addLayer(mapMarker);
      // mapMarker.addTo(this.map);
      // this.map.addLayer(this.markerClusterGroup)
    }
  }
}
