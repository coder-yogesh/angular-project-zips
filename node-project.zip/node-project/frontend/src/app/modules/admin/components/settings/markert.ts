export class Marker {
    lat: Number;
    lng: Number;
  
    content?: MarkerPopupContent;
  
    constructor(lat: Number, lng: Number, content?: MarkerPopupContent) {
      this.lat = lat;
      this.lng = lng;
      this.content = content;
    }
  }
  
  export class MarkerPopupContent {
    title: String;
  
    content: String;
  
    constructor(title: String, content: String) {
      this.title = title;
      this.content = content;
    }
  }