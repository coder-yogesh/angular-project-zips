import { AfterViewInit, Component, OnInit } from '@angular/core';

import * as L from 'leaflet';
import 'leaflet.markercluster';
import 'leaflet-control-geocoder';
import { Marker } from './markert';

// declare let L: any;
const iconRetinaUrl =
  "../../../../../assets/marker-icon-2x.png";
const iconUrl = "../../../../../assets/marker-icon.png";
const shadowUrl = "../../../../../assets/marker-shadow.png";
const iconDefault = L.icon({
  iconRetinaUrl,
  iconUrl,
  shadowUrl,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41]
});
L.Marker.prototype.options.icon = iconDefault;
var southWest = new L.LatLng(46.0, 10.2),
  northEast = new L.LatLng(48.0, 17.0),
  bounds = new L.LatLngBounds(southWest, northEast);

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrl: './settings.component.scss'
})
export class SettingsComponent implements AfterViewInit, OnInit {
  items = Array.from({ length: 20 }, (_, i) => `Item ${i + 1}`);
  drawnItems: L.FeatureGroup = L.featureGroup();
  markersData: Array<{ lat: number, lng: number, popup: string }> = [];
  private map: L.Map;
  circle: L.Circle;
  private _markers: any[] = [];  // Store dynamically added markers
  insideMarkers: any[] = []; 
  private showMap() {
    this.map = L.map("map", {
      center: [0, 0],
      zoom: 3
    });

    // this.map.fitBounds(bounds);

    const tiles = L.tileLayer(
      "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      {
        maxZoom: 18,
        minZoom: 3,
        attribution:
          '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      }
    );
    // this.markerClusterGroup = L.markerClusterGroup({
    //   spiderfyShapePositions: function(count, centerPt) {
    //                 var distanceFromCenter = 35,
    //                     markerDistance = 45,
    //                     lineLength = markerDistance * (count - 1),
    //                     lineStart = centerPt.y - lineLength / 2,
    //                     res = [],
    //                     i;
    
    //                 res.length = count;
    
    //                 for (i = count - 1; i >= 0; i--) {
    //                     res[i] = new L.Point(centerPt.x + distanceFromCenter, lineStart + markerDistance * i);
    //                 }
    
    //                 return res;
    //             }
    // });
    tiles.addTo(this.map);

    // this.drawnItems = new L.FeatureGroup();
    this.map.addLayer(this.drawnItems);

    // this.map.on(L.Draw.Event.CREATED, (event: any) => {
    //   const layer = event.layer;

    //   if (layer instanceof L.Circle) {
    //     const circleCenter = layer.getLatLng();  // Get center of the circle
    //     const radius = layer.getRadius();  // Get the radius of the circle

    //     // Get markers inside the circle
    //     this.insideMarkers = this.getMarkersInsideCircle(circleCenter, radius);

    //     // Optionally, show the markers on the map with a popup
    //     this.insideMarkers.forEach((marker: any) => {
    //       const mapMarker = L.marker([marker.lat, marker.lon]).bindPopup(`Lat: ${marker.lat}, Lon: ${marker.lon}`);
    //       mapMarker.addTo(this.map);  // Add marker to the map
    //     });

    //     // Optionally, show the markers inside the circle in a popup attached to the circle
    //     const popupContent = this.insideMarkers.map((m: any) => `Lat: ${m.lat}, Lon: ${m.lon}`).join('<br>');
    //     layer.bindPopup(popupContent).openPopup();

    //     // Add the circle to drawnItems
    //     this.drawnItems.addLayer(layer);
    //   }
    // });
    
    // if (this._markers.length > 0) {
    //   this.loadMarkers();
    // }
    this.addMarkers();
    this.addDrawControl();
  }
   // Add drawing controls (only allow circle)
   addDrawControl(): void {
    const drawOptions = {
      position: 'topright',
      draw: {
        circle: {
          shapeOptions: {
            color: 'blue',
            fillColor: 'lightblue',
            fillOpacity: 0.3,
            weight: 3
          }
        },
        polygon: false,
        polyline: false,
        rectangle: false,
        marker: false
      },
      // edit: {
      //   featureGroup: this.drawnItems,
      //   remove: true
      // }
    };

    const drawControl = new L.Control.Draw(drawOptions);
    this.map.addControl(drawControl);

    // Event when a shape (circle) is drawn
    this.map.on('draw:created', (event: any) => {
      const layer = event.layer;
      this.drawnItems.addLayer(layer);  // Add the circle to drawnItems

      if (layer instanceof L.Circle) {
        console.log('Circle drawn at:', layer.getLatLng());
        console.log('Radius of the circle:', layer.getRadius());

        // Check markers inside the drawn circle
        this.getMarkersInsideCircle(layer);
      }
    });
  }
  // Function to check which markers are inside the circle
  getMarkersInsideCircle(circle: L.Circle): void {
    const circleCenter = circle.getLatLng();
    const circleRadius = circle.getRadius();
    this.insideMarkers = this._markers.filter((marker: any) => {
      console.log('get lat lng', marker);
      const markerLatLng = L.latLng(Number(marker.lat), Number(marker.lng));
      const distance = circleCenter.distanceTo(markerLatLng);
      return distance <= circleRadius;
    });

    console.log('Markers inside the circle:', this.insideMarkers);
  }
  // Add sample markers to the map
  addMarkers(): void {
    // this.markersData = [
    //   { lat: 51.505, lng: -0.09, popup: 'Marker 1' },
    //   { lat: 51.515, lng: -0.1, popup: 'Marker 2' },
    //   { lat: 51.525, lng: -0.11, popup: 'Marker 3' }
    // ];

    // this.markersData.forEach((markerData) => {
    //   const marker = L.marker([markerData.lat, markerData.lng])
    //     .addTo(this.map)
    //     .bindPopup(markerData.popup);
    //   this._markers.push(markerData);  // Add marker data to the _markers array
    // });
    
    // // Create a custom circle on the map
    // const circleOptions: L.CircleOptions = {
    //   color: 'red',
    //   fillColor: 'yellow',
    //   fillOpacity: 0.3,
    //   radius: 1000,
    //   weight: 3,
    //   opacity: 0.8,
    //   dashArray: '5, 5'
    // };

    // this.circle = L.circle([51.505, -0.09], circleOptions).addTo(this.map)
    //   .bindPopup('This is a custom circle.');
  }
  getRandomInRange(from: any, to: number, fixed: number) {
    return (Math.random() * (to - from) + from).toFixed(fixed) * 1;
  }
  addMarker() {
    this._markers.push(new Marker(this.getRandomInRange(47, 48, 4), this.getRandomInRange(11, 15, 4)));
    this.loadMarkers();
    console.log('daf', this._markers);
  }
  private loadMarkers() {
    // this.markersData.forEach((markerData) => {
    //   const marker: any = L.marker([markerData.lat, markerData.lng])
    //     .addTo(this.map)
    //     .bindPopup(markerData.popup);
    //   var zoom = 4;
    //   this.map.flyTo([marker.lat, marker.lon], zoom)
    //   this.map.addLayer(marker);
    //   this._markers.push(markerData);  // Add marker data to the _markers array
    // });
    // if (this.map == null) {
    //   console.error("no map given, cannot plot markers");
    //   return;
    // }

    for (let i = 0; i < this._markers.length; ++i) {
      const marker = this._markers[i];
      console.log('marp', marker, this._markers);
      const mapMarker = L.marker([marker.lat, marker.lng]);
      // this.markerClusterGroup.addLayer(mapMarker);
      this.map.addLayer(mapMarker);
      var zoom = 4;
      this.map.flyTo([marker.lat, marker.lng], zoom)
      // this.markerClusterGroup?.addLayer(mapMarker);
      // mapMarker.addTo(this.map);
      // this.map.addLayer(this.markerClusterGroup)
    }
  }
  ngOnInit() {
  }
  ngAfterViewInit(): void {
    this.showMap();
  }
}
