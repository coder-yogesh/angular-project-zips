import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimeUiModule } from './prime-ui/prime-ui.module';
import { HeaderComponent } from './components/header/header.component';
import { ComponentModule } from './components/components.module';



@NgModule({
  imports: [
    CommonModule
  ],
  exports: [PrimeUiModule, ComponentModule]
})
export class SharedModule { }
