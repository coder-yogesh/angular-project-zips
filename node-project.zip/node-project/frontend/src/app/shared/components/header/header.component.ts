import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuItem } from 'primeng/api/menuitem';
import { adminConfig, userConfig } from './menuConfig';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit {
  items: MenuItem[]|undefined;
  user: any;
  constructor (private router: Router) {}
  logOut() {
    localStorage.clear();
    this.router.navigate(['login']);
  }
  ngOnInit() {
    const user = localStorage.getItem('user');
    if (user) {
      this.user = JSON.parse(user);
      console.log('user', this.user);
      this.items = this.user.role === 'admin' ? adminConfig : adminConfig;
    }
  }
}
