export const adminConfig = [
    {
      label: 'Home',
      icon: 'pi pi-home',
      routerLink: 'admin/home'
    },
    {
      label: 'Users',
      icon: 'pi pi-user',
      routerLink: 'admin/page'
    },
    {
      label: 'Features',
      icon: 'pi pi-star',
      routerLink: 'admin/settings'
    },
];

export const userConfig = [
    {
      label: 'Home',
      icon: 'pi pi-home',
      routerLink: 'admin/home'
    },
    {
      label: 'Features',
      icon: 'pi pi-star',
      routerLink: 'admin/settings'
    },
]