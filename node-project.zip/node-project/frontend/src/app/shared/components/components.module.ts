import { NgModule } from "@angular/core";
import { HeaderComponent } from "./header/header.component";
import { PrimeUiModule } from "../prime-ui/prime-ui.module";

@NgModule({
    declarations: [
        HeaderComponent
    ],
    exports: [
        HeaderComponent
    ],
    imports: [PrimeUiModule]
})
export class ComponentModule {}