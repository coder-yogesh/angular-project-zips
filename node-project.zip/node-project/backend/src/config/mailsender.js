const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');
const readfile = promisify(fs.readFile);
const transport = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'yogisakalabhaktula@gmail.com',
        pass: 'schk gknm ojxs gstg',
    },
});

function injectData(html, data) {
    return html.replace(/{{(.*?)}}/g, (_, key) => data[key] || '');
  }

const sendmailToUser = async (data, content) => {
    let htmlTemplate = fs.readFileSync(path.join(__dirname, 'template.html'), 'utf-8');
    const emailData = {
        name: data.name,
    };
    htmlTemplate = injectData(htmlTemplate, emailData);

    const mailOptions = {
        from: '"Sender Name" <yogisakalabhaktula@gmail.com>',
        to: data.email,
        subject: 'Test Email',
        html: htmlTemplate,
        attachments: [
            {
                filename: 'fav.png',
                path: 'src/config/fav.png', // Update with the path to your image
                cid: 'logo@ourcompany.com', // same as in the `img src`
            },
        ],
    };
    transport.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log('Error occurred:', error.message);
            return;
        }
        console.log('Email sent successfully:', info.response);
    });
}

module.exports = sendmailToUser;