const express = require('express');
const userController = require('../controllers/userControllers');
const { authenticateToken } = require('../middleware/authenticateToken');
const multer = require('multer');

const router = express.Router();

const upload = multer({ storage: multer.memoryStorage() });

router.get('/userList', authenticateToken, userController.getusers);
router.post('/ping', upload.single('file'), authenticateToken, userController.createUser);
router.put('/updateUser', upload.single('file'), authenticateToken, userController.updateUser);
router.delete('/deleteUser/:id', authenticateToken, userController.deleteUser);
router.post('/login', userController.loginUser);

module.exports = router;