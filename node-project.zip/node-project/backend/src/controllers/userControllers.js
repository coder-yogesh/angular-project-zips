const { json } = require('express');
const userService = require('../services/userServices');
const { successResponse, errorResponse, createdResponse } = require('../utils/responseUtil');
const admin = require('firebase-admin');
const serviceAccount = require('../config/serviceAccountKey.json');
const cloudinary = require('cloudinary');
const streamifier = require('streamifier');
const sendmailToUser = require('../config/mailsender');


cloudinary.config({
    cloud_name: 'dfxsfrohs',
    api_key: '597979592554144',
    api_secret: 'gNMEj8PfwWODohk3zswQjexBB2k'
})

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  storageBucket: 'gs://backend-4cbd6.appspot.com',  // replace with your Firebase Storage bucket name
});

const bucket = admin.storage().bucket();



async function createFileUrl(files) {
  try {
    const destination = `node/${files.name}`
    const file = bucket.file(destination);
    await file.save(files.fileBuffer, {
        metadata: {
            contentType: files.mimeType,
            cacheControl: 'public, max-age=31536000'
        },
    })

    // Generate a signed URL for public access
    const [signedUrl] = await file.getSignedUrl({
      action: 'read',
      expires: '03-01-2500', // Far future expiration date
    });
    return signedUrl;
  } catch (error) {
    console.error('Error uploading file:', error);
  }
}

async function cloudinaryFileUrl(img) {
    return new Promise((resolve, reject) => {
        const upload = cloudinary.v2.uploader.upload_stream({
            use_filename: true,
            unique_filename: false,
            overwrite: true,
            transformation: [
                { width: 500, height: 500, crop: 'limit' }
            ]
        },
        (error, result) => {
            if (error) {
                console.error('Error during upload:', error);
                reject(error);
            } else {
                resolve(result.url);
            }
        }
    );
    streamifier.createReadStream(img).pipe(upload);
    })
}
// const imagePath = '../backend/src/uploads/ivanmagalhaes.png';
// cloudinaryFileUrl(imagePath)
//     .then((url) => console.log('image main', url))
//     .catch((error) => console.error('error', error));

// const content = 'Sharp account created successfully';
// const body = {
//     email: 'rajesh@yopmail.com',
//     name: 'rajesh'
// }
// sendmailToUser(body, content);

exports.loginUser = async (req, res) => {
    try {
        const user = await userService.login(req.body);
        if (!user) {
            return errorResponse(res, 'User not found');
        }
        return successResponse(res, 'Login Successfully', user);
    } catch (error) {
        return errorResponse(res, 'Error fetching users');
    }
}

exports.getusers = async (req, res) => {
    try {
        console.log('sdsd', req.query)
        const page = parseInt(req.query.pageIndex) || 1;
        const pageSize = parseInt(req.query.pageSize) || 10000;
        const users = await userService.getUsers(page, pageSize);
        const result = {
            page,
            pageSize,
            users: users,
        }
        return successResponse(res, 'Users List', result);
    } catch (error) {
        return errorResponse(res, 'Error fetching users');
    }
}

exports.createUser = async (req, res) => {
    try {
        const content = 'Sharp account created successfully';
        await sendmailToUser(req.body, content);
        if (req.file) {
            // const file = {
            //     fileBuffer: req.file.buffer,
            //     name: req.file.originalname,
            //     mimeType: req.file.mimeType
            // }
            const imageBuffer = req.file.buffer;
            cloudinaryFileUrl(imageBuffer)
            .then(async (url) => {
                const userPayload = {
                    ...req.body,
                    url: url
                }
                const user = await userService.createUser(userPayload);
                createdResponse(res, 'User Created', user);
            })
            .catch((error) => console.error(error, 'error from file'));
        } else {
            const userPayload = {
                ...req.body,
                url: ''
            }
            const user = await userService.createUser(userPayload);
            createdResponse(res, 'User Created', user);
        }
    } catch (error) {
        errorResponse(res, 'Error creating user');
    }
}

exports.updateUser = async (req, res) => {
    try {
        if (req.file) {
            // const file = {
            //     fileBuffer: req.file.buffer,
            //     name: req.file.originalname,
            //     mimeType: req.file.mimeType
            // }
            const imageBuffer = req.file.buffer;
            cloudinaryFileUrl(imageBuffer)
            .then(async (url) => {
                const userPayload = {
                    ...req.body,
                    url: url
                }
                const user = await userService.updateUser(userPayload);
                if (!user) {
                    return errorResponse(res, 'User not found');
                }
                return successResponse(res, 'Updated Successfully', user);
            })
            .catch((error) => console.error(error, 'error from file'));
        } else {
            const userPayload = {
                ...req.body,
                url: ''
            }
            const user = await userService.updateUser(userPayload);
            if (!user) {
                return errorResponse(res, 'User not found');
            }
            return successResponse(res, 'Updated Successfully', user);
        }
    } catch (error) {
        return errorResponse(res, 'Error updaing user');
    }
}

exports.deleteUser = async(req, res) => {
    try {
        const deleteUser = await userService.deleteUser(req.params.id);
        if (deleteUser) {
            return successResponse(res, `User deleted successfully`, deleteUser);
        } else {
            return errorResponse(res, `User with id ${req.params.id} not found.`, 404);
        }
    } catch (error) {
        return errorResponse(res, 'Error delete user');
    }
}